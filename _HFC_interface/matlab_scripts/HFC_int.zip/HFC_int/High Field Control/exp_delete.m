function h = exp_delete(h)
% This function deletes the experiment saved in the selected line of the
% list box of the Edit Input Panel.

if ~isempty(h.list_box(2).String)
    ind01 = h.list_box(2).Value;
    ind = split(h.list_box(2).String{ind01},filesep);
    ind = str2double(ind{1});
    ind02 = find(h.Experiment_Table.Index==ind);
    h.Experiment_Table(ind02,:)=[];
    h.list_box(2).String(ind01) = [];
    if ind01~=1
        h.list_box(2).Value = ind01-1;
    end
    for i = ind02:length(h.Experiment_Table.Index)
        h.Experiment_Table.Index(i) = h.Experiment_Table.Index(i)-1;
    end
    % 'Index\ExpNo\Solvent\Experiment\Parameters'
    for i = 2:size(h.Experiment_Table,1)
        if h.Experiment_Table.Delete(i)
            tag = [num2str(h.Experiment_Table.Index(i))...
                '\Delete holder°',num2str(h.Experiment_Table.Holder(i))];
        else
            tag = char(fullfile(num2str(h.Experiment_Table.Index(i)),...
                ['Exp°',num2str(h.Experiment_Table.ExpNo(i))],...
                h.Experiment_Table.Solvent(i),...
                h.Experiment_Table.Experiment(i),...
                h.Experiment_Table.Parameters(i)));
        end
        if i==2
            txt = {tag};
        else
            txt(end+1) = {tag};
        end
    end
    if exist('txt','var')
        if ~isempty(txt)
            h.list_box(2).String = txt;
        end
    end
end
end
