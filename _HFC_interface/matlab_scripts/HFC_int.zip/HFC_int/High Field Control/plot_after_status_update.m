function plt = plot_after_status_update(status,newExp2Plot,newExp2Plot_ind)
% This function displays the outcome spectrum of each experiment ordered.
% Once they are acquired, the dataset are transfered to this PC. If the
% dataset are not yet acquired, it waits until they are to display them.
%%
figure%(status.f(1))
axes%(status.ax(1))
plt = [];
if ~isa(status,'struct')
    st = status;
    clearvars status
    status.name = st;
end
for i = 1:length(newExp2Plot)
    filePath = ['/opt/nmrdata/user/nmr/Nour/' deblank(status.name(newExp2Plot_ind(i),:)) '/'...
        num2str(newExp2Plot(i)) '/'];
    fileName = 'fid';
    desiredPath = ['C:\Users\elsabbagh-n\Documents\DataSet\' ...
        deblank(status.name(newExp2Plot_ind(i),:)) '\' num2str(newExp2Plot(i)) '\'];
    parent_folder = ['C:\Users\elsabbagh-n\Documents\DataSet\' ...
        deblank(status.name(newExp2Plot_ind(i),:)) '\'];
    
    if ~isfolder(parent_folder)
        % create folders
        mkdir(parent_folder)
        mkdir(desiredPath)
        % transfer dataset
        Tr = transfer_from_spectro500(filePath,fileName,desiredPath);
    else
        if ~isfolder(desiredPath)
            % create folder
            mkdir(desiredPath)
            % transfer dataset
            Tr = transfer_from_spectro500(filePath,fileName,desiredPath);
        else
            Tr = 1;
        end
    end
    if Tr
        % DataSet plot
        A = rbnmr(desiredPath,1);
        p = plotbnmr(A);
        % p.DisplayName = status.table.Title{newExp2Plot_ind(i)};
        p.DisplayName = A.Title;
        if isfield(status,'uit')
            a = status.uit.Data.Experiment{newExp2Plot_ind(i),:};
        else
            a = [];
        end
        tt = string(['Exp n° ' num2str(newExp2Plot(i)) ' - ' a]);
        title(tt)
        legend
        xlim([min(p.XData) max(p.XData)])
        xlabel('ppm')
        grid minor
%         xlim0 = xlim;ylim0 = ylim;
%         xlim([min(min(p.XData),xlim0(1)) max(max(p.XData),xlim0(2))])
%         ylim([min(min(p.YData),ylim0(1)) max(max(p.YData),ylim0(2))])
%         drawnow
        plt{i,1} = p; %#ok<AGROW>
        plt{i,2} = gcf; %#ok<AGROW>
        plt{i,3} = datetime(A.Info.AcqDateTime,'Format','dd-MMM-yyyy HH:mm:ss')-hours; %#ok<AGROW>
    end
end
end