function go = check_user_for_new_experiments(varargin)
% Check if the user wants to continue sending experiments blocks
if isempty(varargin)
    count2 = 3;
else
    count2 = varargin{1};
    count2 = fix(count2);
end
drawnow
pause(0.1)
drawnow
message = {'OKAY to stop launching new experiments.';...
    'Otherwise, leave this message to disappear.';[num2str(count2) ' seconds to decide.']};
msg = msgbox(message);
drawnow
pause(0.1)
drawnow
for i = 0:count2-1
    if ishandle(msg)
        msg.Children(2).Children.String(3) = {[num2str(count2-i) ' seconds to decide.']};
    end
    drawnow
    if ~ishandle(msg)
        break
    else
        drawnow
        pause(1)
    end
end
drawnow
if ishandle(msg)
    go = 1;
    delete(msg)
else
    go = 0;
end
end
