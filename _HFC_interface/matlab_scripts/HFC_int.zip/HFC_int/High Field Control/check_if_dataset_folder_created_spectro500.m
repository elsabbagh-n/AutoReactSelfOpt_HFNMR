function [dataset_folder_ready,allFound] = check_if_dataset_folder_created_spectro500(FileName,datasetPath,...
    expList,waitCheck)
% This function checks if the request experiment dataset folder is created
% (dataset_folder_ready=1) or not (dataset_folder_ready=0). Hostname,
% Username and Password are set to the those of Spectro500.
%
% No file transfer !
%
% Input
% FileName                Name of the folder to be checked
% datasetPath             Path of folder to be checked on the remote PC
% expList                 List of experiments to be checked
% waitCheck               =1 to wait until updated, =0 check once
% Output
% dataset_folder_ready    Lis of experiment which dataset folder is created
% allFound                =1 if all experiments dataset folder is created

% FileName = h.Experiment_Table.Name;
% datasetPath = '/opt/nmrdata/user/nmr/Nour';
% expList = h.Experiment_Table.ExpNo(2:end);
% waitCheck = 1;
%% User Input

% Required information about the remote PC (spectro 500MHz)
Hostname = '172.16.77.57';
Hostname = 'RMN500-1525.ceisam.sciences.univ-nantes.prive';
Username = 'nmr';
Password = 'topspin';

%% Dataset folder creation check

% Check if the main dataset folder is created
command = ['cd ' datasetPath '; ls ;'];
command_output = ssh2_simple_command(Hostname, Username, Password,command);
if ~ismember(FileName,command_output)
    % Main dataset folder not created
    if waitCheck~=0
        % Check until dataset folder created
        created = 0;
        while(created==0)
            command_output = ssh2_simple_command(Hostname, Username, Password,command);
            if ismember(FileName,command_output)
                created = 1;
            end
        end
    else
        dataset_folder_ready = [];
        allFound = 0;
        return
    end
end
err = 1;
while(err)
    try
        % Check if the folder of each requested experiment is created
        command = ['cd ' datasetPath '/' FileName '; ls ;'];
        command_output = ssh2_simple_command(Hostname, Username, Password,command);
        expInFolder = zeros(length(command_output),1);
        for i = 1:length(command_output)
            expInFolder(i,1) = str2double(string(cell2mat(command_output(i))));
        end
        expInFolder = sort(expInFolder,'ascend');
        expFound = expList(ismember(expList,expInFolder));
        if ~isempty(expFound)
            if length(expFound)==length(expList)
                % Dataset folder created for all requested experiments
                dataset_folder_ready = expFound;
                allFound = 1;
            else
                % Not all experiment were added
                if waitCheck~=0
                    expStillWanted = expList(~ismember(expList,expInFolder)); % Exp not found yet
                    [dataset_folder_ready_round2,allFound] = check_if_dataset_folder_created_spectro500(FileName,datasetPath,...
                        expStillWanted,1);
                    dataset_folder_ready = [expFound dataset_folder_ready_round2];
                else
                    allFound = 0;
                    dataset_folder_ready = expFound;
                end
            end
            return
        else
            if waitCheck~=0
                [dataset_folder_ready,allFound] = check_if_dataset_folder_created_spectro500(FileName,datasetPath,...
                    expList,waitCheck);
            else
                dataset_folder_ready = [];
                allFound = 0;
            end
        end
    catch EX
        fprintf(EX.message)
        fprintf('\nBUT .... Repeat .... \n')
        continue
    end
    err = 0;
end
end


