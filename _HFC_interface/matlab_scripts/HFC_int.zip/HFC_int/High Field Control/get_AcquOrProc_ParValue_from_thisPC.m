function ParValues = get_AcquOrProc_ParValue_from_thisPC(FileName,datasetPath,...
    expNb,AcquOrProc,Parameter,varargin)
% This function returns the value of an acquisition or a processing
% parameter of an experiment in its dataset folder.
%
%
% Input
% FileName                Name of the folder to be checked
% datasetPath             Path of folder to be checked on the remote PC
% expNb                   Number of the experiment to be checked
% AcquOrProc              Type of the parameter, 'acqus' or 'procs'
% Parameter               Parameter label or cell of labels if multiple
% varargin                if AcquOrProc = 'procs', then varargin = PROCNO
% Output
% ParValues               Values of the parameter(s), if found/valid
%
% FileName = '221109_1';datasetPath = 'C:\Users\elsabbagh-n\Documents\DataSet';expList = 6;AcquOrProc = 'procs';Parameter = {'INTSCL','NC_proc'};varargin = [];

%% User Input

% Check if procno number needed
if isempty(varargin) && strcmp(AcquOrProc,'procs')
    ProcnoCheck = 1;
else
    ProcnoCheck = 0;
end

if nargin<5
    error('Some input parameter are missing.')
end
if length(expNb)>1
    error('This function only look for parameters of a single experiment.')
end
%% Make sure that the corresponding folder/files are valid

% Check if the main dataset folder is created
filename = fullfile(datasetPath,FileName);
if exist(filename, 'dir')==7
    expInFolder = zeros(length(dir(filename))-2,1);
    n = {dir(filename).name};
    n = n(3:end);
    for i = 1:length(n)
        expInFolder(i,1) = str2double(n{i});
    end
else
    error('File directory does not exist !')
end
expInFolder = sort(expInFolder,'ascend');
expFound = expNb(ismember(expNb,expInFolder));
if isempty(expFound)
    error('Experiment number not found.')
end
% Check if the file exists
if strcmp(AcquOrProc,'acqus')
    filename = fullfile(datasetPath,FileName,num2str(expFound));
    fileInFolder = {dir(filename).name};
    if isempty(find(contains(fileInFolder,AcquOrProc),1))
        error([AcquOrProc ' file not found.'])
    end
elseif strcmp(AcquOrProc,'procs')
    if ProcnoCheck % continue only if one procno is available anyway
        filename = fullfile(datasetPath,FileName,num2str(expFound),'/pdata');
        procnoInFolder = zeros(length(dir(filename))-2,1);
        n = {dir(filename).name};
        n = n(3:end);
        for i = 1:length(n)
            procnoInFolder(i,1) = str2double(n{i});
        end
        if length(procnoInFolder)~=1
            varargin{1} = procnoInFolder(1);
            % error('The parameter to check is supposed to be a processing one. Yet, no procno was inputed.')
        else
            varargin{1} = procnoInFolder;
        end
    end
    filename = fullfile(datasetPath,FileName,num2str(expFound),'/pdata',num2str(varargin{1}));
    fileInFolder = {dir(filename).name};
    if isempty(find(contains(fileInFolder,AcquOrProc),1))
        error([AcquOrProc ' file not found.'])
    end
end
%% Look for the parameter value

if isa(Parameter,'cell')
    if length(Parameter)==1
        Parameter = Parameter{1};
        listP = 0;
    else
        listP = 1;
    end
else
    listP = 0;
end
if listP % list of parameters to check
    if strcmp(AcquOrProc,'acqus')
        filename = fullfile(datasetPath,FileName,num2str(expFound),AcquOrProc);
        fileContent = regexp(fileread(filename),'\n','split')';
        for i = 1:length(Parameter)
            Parameter0 = Parameter{i};
            whichline = find(contains(fileContent,['##$' Parameter '=']),1);
            if ~isempty(whichline)
                ParValues = cell2mat(textscan(fileContent{whichline},['##$' Parameter0 '=%f']));
                if isempty(ParValues)
                    ParValues = textscan(fileContent{whichline},['##$' Parameter0 '=%s']);
                    ParValues = ParValues{1}{1};
                    if ParValues(1)=='('
                        if fileContent{whichline+1}(1)=='<'
                            ParValues = textscan(fileContent{whichline+1},'%s');
                            ParValues = ParValues{1}';
                            nextLine = whichline+2;
                            while(~(fileContent{nextLine}(1)=='#'))
                                ParValue0 = textscan(fileContent{nextLine},'%s');
                                ParValues = [ParValues ParValue0{1}']; %#ok<AGROW>
                                nextLine = nextLine+1;
                            end
                        else
                            ParValues = cell2mat(textscan(fileContent{whichline+1},'%f'))';
                            nextLine = whichline+2;
                            while(~(fileContent{nextLine}(1)=='#'))
                                ParValues = [ParValues cell2mat(textscan(fileContent{nextLine},'%f'))']; %#ok<AGROW>
                                nextLine = nextLine+1;
                            end
                        end
                    elseif ParValues(1)=='<'
                        if ParValues(end)=='>'
                            ParValues = ParValues(2:end-1);
                        else
                            while(~(ParValues(end)=='>'))
                                ParValue0 = textscan(fileContent{whichline},['##$' Parameter0 '= ' ParValues '%s']);
                                ParValues = [ParValues ' ' ParValue0{1}{1}]; %#ok<AGROW>
                            end
                            ParValues = ParValues(2:end-1);
                        end
                    end
                end
                ParValue0{i} = ParValues;
            else
                warning(['Parameter ' Parameter ' not found.'])
            end
        end
        ParValues = ParValue0;
    elseif strcmp(AcquOrProc,'procs')
        filename = fullfile(datasetPath,FileName,num2str(expFound),'/pdata',num2str(varargin{1}),AcquOrProc);
        fileContent = regexp(fileread(filename),'\n','split')';
        for i = 1:length(Parameter)
            Parameter0 = Parameter{i};
            whichline = find(contains(fileContent,['##$' Parameter0 '=']),1);
            if ~isempty(whichline)
                ParValues = cell2mat(textscan(fileContent{whichline},['##$' Parameter0 '=%f']));
                if isempty(ParValues)
                    ParValues = textscan(fileContent{whichline},['##$' Parameter0 '=%s']);
                    ParValues = ParValues{1}{1};
                    if ParValues(1)=='('
                        if fileContent{whichline+1}(1)=='<'
                            ParValues = textscan(fileContent{whichline+1},'%s');
                            ParValues = ParValues{1}';
                            nextLine = whichline+2;
                            while(~(fileContent{nextLine}(1)=='#'))
                                ParValue0 = textscan(fileContent{nextLine},'%s');
                                ParValues = [ParValues ParValue0{1}']; %#ok<AGROW>
                                nextLine = nextLine+1;
                            end
                        else
                            ParValues = cell2mat(textscan(fileContent{whichline+1},'%f'))';
                            nextLine = whichline+2;
                            while(~(fileContent{nextLine}(1)=='#'))
                                ParValues = [ParValues cell2mat(textscan(fileContent{nextLine},'%f'))']; %#ok<AGROW>
                                nextLine = nextLine+1;
                            end
                        end
                    elseif ParValues(1)=='<'
                        if ParValues(end)=='>'
                            ParValues = ParValues(2:end-1);
                        else
                            while(~(ParValues(end)=='>'))
                                ParValue0 = textscan(fileContent{whichline},['##$' Parameter0 '= ' ParValues '%s']);
                                ParValues = [ParValues ' ' ParValue0{1}{1}]; %#ok<AGROW>
                            end
                            ParValues = ParValues(2:end-1);
                        end
                    end
                end
                ParValue0{i} = ParValues;
            else
                warning(['Parameter ' Parameter0 ' not found.'])
            end
        end
        ParValues = ParValue0;
    end
else
    if strcmp(AcquOrProc,'acqus')
        filename = fullfile(datasetPath,FileName,num2str(expFound),AcquOrProc);
        fileContent = regexp(fileread(filename),'\n','split')';
        whichline = find(contains(fileContent,['##$' Parameter '=']),1);
        if ~isempty(whichline)
            ParValues = cell2mat(textscan(fileContent{whichline},['##$' Parameter '=%f']));
            if isempty(ParValues)
                ParValues = textscan(fileContent{whichline},['##$' Parameter '=%s']);
                ParValues = ParValues{1}{1};
                if ParValues(1)=='('
                    if fileContent{whichline+1}(1)=='<'
                        ParValues = textscan(fileContent{whichline+1},'%s');
                        ParValues = ParValues{1}';
                        nextLine = whichline+2;
                        while(~(fileContent{nextLine}(1)=='#'))
                            ParValue0 = textscan(fileContent{nextLine},'%s');
                            ParValues = [ParValues ParValue0{1}']; %#ok<AGROW>
                            nextLine = nextLine+1;
                        end
                    else
                        ParValues = cell2mat(textscan(fileContent{whichline+1},'%f'))';
                        nextLine = whichline+2;
                        while(~(fileContent{nextLine}(1)=='#'))
                            ParValues = [ParValues cell2mat(textscan(fileContent{nextLine},'%f'))']; %#ok<AGROW>
                            nextLine = nextLine+1;
                        end
                    end
                elseif ParValues(1)=='<'
                    if ParValues(end)=='>'
                        ParValues = ParValues(2:end-1);
                    else
                        while(~(ParValues(end)=='>'))
                            ParValue0 = textscan(fileContent{whichline},['##$' Parameter '= ' ParValues '%s']);
                            ParValues = [ParValues ' ' ParValue0{1}{1}]; %#ok<AGROW>
                        end
                        ParValues = ParValues(2:end-1);
                    end
                end
            end
        else
            error(['Parameter ' Parameter ' not found.'])
        end
    elseif strcmp(AcquOrProc,'procs')
        filename = fullfile(datasetPath,FileName,num2str(expFound),'/pdata',num2str(varargin{1}),AcquOrProc);
        fileContent = regexp(fileread(filename),'\n','split')';
        whichline = find(contains(fileContent,['##$' Parameter '=']),1);
        if ~isempty(whichline)
            ParValues = cell2mat(textscan(fileContent{whichline},['##$' Parameter '=%f']));
            if isempty(ParValues)
                ParValues = textscan(fileContent{whichline},['##$' Parameter '=%s']);
                ParValues = ParValues{1}{1};
                if ParValues(1)=='('
                    if fileContent{whichline+1}(1)=='<'
                        ParValues = textscan(fileContent{whichline+1},'%s');
                        ParValues = ParValues{1}';
                        nextLine = whichline+2;
                        while(~(fileContent{nextLine}(1)=='#'))
                            ParValue0 = textscan(fileContent{nextLine},'%s');
                            ParValues = [ParValues ParValue0{1}']; %#ok<AGROW>
                            nextLine = nextLine+1;
                        end
                    else
                        ParValues = cell2mat(textscan(fileContent{whichline+1},'%f'))';
                        nextLine = whichline+2;
                        while(~(fileContent{nextLine}(1)=='#'))
                            ParValues = [ParValues cell2mat(textscan(fileContent{nextLine},'%f'))']; %#ok<AGROW>
                            nextLine = nextLine+1;
                        end
                    end
                elseif ParValues(1)=='<'
                    if ParValues(end)=='>'
                        ParValues = ParValues(2:end-1);
                    else
                        while(~(ParValues(end)=='>'))
                            ParValue0 = textscan(fileContent{whichline},['##$' Parameter '= ' ParValues '%s']);
                            ParValues = [ParValues ' ' ParValue0{1}{1}]; %#ok<AGROW>
                        end
                        ParValues = ParValues(2:end-1);
                    end
                end
            end
        else
            error(['Parameter ' Parameter ' not found.'])
        end
    end
end
end


