function command_output = get_file_from_spectro500(filename,filepath)
% This function transfer text in files from a remonte PC to this PC. Hostname,
% Username and Password are set to the those of Spectro500. If
% the transfer is done successfully, it returns a value 1; if there were no
% transfer or the folderName didn't exist, it returns a nil value.
%
% Input
% filename  File name which content to be extracted from the remote PC
% filepath  Path of the file on the remote PC

%% User Input

% Required information about the remote PC (spectro 500MHz)
Hostname = '172.16.77.57';
Hostname = 'RMN500-1525.ceisam.sciences.univ-nantes.prive';
Username = 'nmr';
Password = 'topspin';

%% No transfer needed
command = ['cd ' filepath ' ;cat ' filename ' ;'];
command_output = ssh2_simple_command(Hostname, Username, Password,command);
fprintf(['\nThe file <' filename '> in ' filepath ' has been retrieved.'])
end







