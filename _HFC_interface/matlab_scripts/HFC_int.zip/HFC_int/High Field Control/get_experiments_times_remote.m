function [exp_no,exp_times] = get_experiments_times_remote(exp_nos,filename)
% Get experiments times of acquisition on remote computer
if isempty(exp_nos)
    return
end
if exp_nos==0
    return
end
% exp_times = cell(length(exp_nos),0);
% exp_no = cell(length(exp_nos),0);
for i = 1:length(exp_nos)
    exp_nb = exp_nos(i);
    FilePath = ['/opt/nmrdata/user/nmr/Nour/' filename '/' num2str(exp_nb) '/'];
    Fid = 'fid';
    % Get Date and Time of fid file on remote computer
    DateTime = get_date_time_file_spectro500(FilePath,Fid);
    % Output
%     exp_times(i,1) = {datetime(DateTime,'format','HH:mm:ss')};
%     exp_no(i,1) = {exp_nb};
    exp_times(i,1) = datetime(DateTime,'format','HH:mm:ss'); %#ok<AGROW>
    exp_no(i,1) = exp_nb; %#ok<AGROW>
    fprintf(['\nTime & Date of exp° ' num2str(exp_nb) '/' ...
        num2str(exp_nos(end)) ' (' filename ') have been retrieved.'])
end
end
