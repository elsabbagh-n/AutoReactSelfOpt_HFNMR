function plt = plot_for_area_selection(stt,newExp2Plot,newExp2Plot_ind,auto)
% function Tr = plot_after_status_update(status,newExp2Plot,newExp2Plot_ind)
% This function displays the outcome spectrum of each experiment ordered.
% Once they are acquired, the dataset are transfered to this PC. If the
% dataset are not yet acquired, it waits until they are to display them.

if auto==0
    figure(stt.f(1))
    axes(stt.ax(1))
    stt_table = stt.uit.Data;
else
    stt_table = stt;
end
plt = [];
for i = 1:length(newExp2Plot)
    filePath = ['/opt/nmrdata/user/nmr/Nour/' deblank(stt_table.Date{newExp2Plot_ind(i),:}) '/'...
        num2str(newExp2Plot(i)) '/'];
    fileName = 'fid';
    desiredPath = ['C:\Users\elsabbagh-n\Documents\DataSet\' ...
        deblank(stt_table.Date{newExp2Plot_ind(i),:}) '\' num2str(newExp2Plot(i)) '\'];
    parent_folder = ['C:\Users\elsabbagh-n\Documents\DataSet\' ...
        deblank(stt_table.Date{newExp2Plot_ind(i),:}) '\'];
    
    if ~isfolder(parent_folder)
        % create folders
        mkdir(parent_folder)
        mkdir(desiredPath)
        % transfer dataset
        Tr = transfer_from_spectro500(filePath,fileName,desiredPath);
    else
        if ~isfolder(desiredPath)
            % create folder
            mkdir(desiredPath)
            % transfer dataset
            Tr = transfer_from_spectro500(filePath,fileName,desiredPath);
        else
            Tr = 1;
        end
    end
    if Tr
        % DataSet plot
        A = rbnmr(desiredPath,1);
        if auto==0
            p = plotbnmr(A);
            p.DisplayName = stt_table.Title{newExp2Plot_ind(i)};
            a = stt_table.Experiment{newExp2Plot_ind(i),:};
            tt = string(['Exp n° ' num2str(newExp2Plot(i)) ' - ' a]);
            title(tt)
            legend
            xlim([min(p.XData) max(p.XData)])
            plt{i,1} = p; %#ok<AGROW>
            plt{i,2} = gcf; %#ok<AGROW>
        else
            plt{i,1} = A; %#ok<AGROW>
        end
    end
end
end