function [Area,Region,pathLatestExp] = ExtSet_GUI_function_new(varargin)
% varargin{3} = 'maxu-2';nargin = 3;varargout = [];nargout = 0;
% varargin{1} = 'list';nargin = 1;varargout = [];nargout = 0;
% nargin = 2;varargout = [];nargout = 3;
% varargin{1} = 'C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\Post_Doc_codes\Automation User Interface v5\autoModeHandles_1H_LoopTillPlateau.mat';
% varargin{2} = 0;varargin{3} = 'maxuc';
%% Introduction

% This function creates the interface allowing the user to input the
% required and some optional information to fill the required Extset
% text file for IconNMR, and transfer it to the spectrometer. A status
% table is displayed, with the option of area calculation.
%
%   Input :
%
% [...] = ExtSet_GUI_function;
%   Manual-mode (no input): calls the graphical interface for user input and
%   commands
%
% [...] = ExtSet_GUI_function(Filename,Continuous,AreaRegion,Message);
%   Auto-mode input:
%
%       Filename    path of the saved autoModeHandles.mat from a previous
%                   manual mode call
%
%       Continuous  0 for the beginning of the experiments flow, and 1
%                   otherwise
%
%       AreaRegion  region of interest in ppm for area calculation
%      (optional)   Only needed to be called at the beginning of the
%                   experiments flow (where Continuous=0), it is then
%                   stored in the autoModeHandles.mat for future calls.
%                   This will be the first numerical matrix inputted. If
%                   this areaRegion is not inserted, then the ones in the
%                   autoModeHandles.mat will be generated.
%
%       RefRegion   reference region in the spectrum, from which the
%      (optional)   relative areas are calculated. This will be the second
%                   numerical matrix inputted. If this areaRegion is not
%                   inserted, then the ones in the autoModeHandles.mat will
%                   be generated.
%
%                   /!\ DO NOT change it ALONE between flow iterations
%                   wihtout changing the AreaRegion.
%
%       Message     'last','start','stop','list' or 'maxi' if this 
%      (optional)   iteration is the last one (where Continuous=1), to 
%                   start or stop the automation, if theuser wants to save 
%                   the handles of the selected experiments or if the user 
%                   would like to repeat the same experiment(s) until 
%                   maximum area is reached respectively.
%                   'start','stop' and 'list' are called alone in varargin.
%                   New 'max?' option:
%                        'maxi'     no control of user, only 'maxi' condition stands
%                           'max10'     stop after 10% of max(diff(area))
%                           'max20'     stop after 20% of max(diff(area))
%                           'max35'     stop after 35% of max(diff(area))
%                               ...
%                           'max99'     stop after 99% of max(diff(area))
%                        'maxc'     user chooses when to stop, 'maxi' condition not priority
%                        'maxp'     user chooses when to stop after 'maxi' condition approved
%
%   Output:
%
%       Area        Area values of the acquired spectra. Area is a table
%                   wih the following form : [ExpNo Area RelativeArea]. In
%                   manual mode, if the reference bounds are not selected,
%                   no relative area will be calculated. However, in auto
%                   mode, reference bounds are always required.
%
%       Region      Selected region for the area calculation. Region is a
%                   matrix with the following form :
%                   [target_bound1 target_bound2 ref_bound1 ref_bounds]
%
%
%   IMPORTANT !!!
%   In manual-mode, when the user chooses a region for the area
%   calculation, this area remains the same for all spectra. If it is
%   changed during acquisition, the old area values will be updated
%   according to the new region.
%   In auto-mode, as the function is newly called at each iteration, there
%   are two types of Area output. Firstly, if the region was not changed
%   during the iterations, only the area values of the newly acquired
%   spectra is outputed. However, if the region was changed from the
%   previous iteration, the ouput area values correspond to all acquired
%   spectra from the beginning of the experiments flow.
%   Trick To Track the changes of region bounds: if the length of output
%   area is equal to the number of experiments in the Table of the saved
%   autoModeHandles (ExpNo=0 first line in the table not included), then no
%   region changes have been made, if it is larger, then area region was
%   changed.
%   /!\ However, the reference region should not be changed between
%   iteration if the target region for area calculation is not changed. If
%   the target region shall be changed between ietartion only, the
%   reference region remains the same, already in the saved handles.
%
% Examples:
%
% ExtSet_GUI_function(...);
%   -> call the function without any output.
%
% A = ExtSet_GUI_function(...);
%   -> call the function and output only area values.
%
% [A,R] = ExtSet_GUI_function(...);
%   -> call the function and output area values with the region used.
%
% [...] = ExtSet_GUI_function;
%   -> call manual-mode interface.
%
% [...] = ExtSet_GUI_function{'C:\Users\...\autoModeHandles.mat',0};
%   -> call auto-mode using the saved handles (autoModeHandles.mat) to
%   begin a new flow of experiments, where the region for area calculation
%   is the one logged in the loaded handles.
%   -> The automation on IconNMR will start.
%
% [...] = ExtSet_GUI_function{'C:\Users\...\autoModeHandles.mat',0,[2 3.5]};
%   -> call auto-mode using the saved handles (autoModeHandles.mat) to
%   begin a new flow of experiments, where the region for area calculation
%   is [2 3.5], that will be logged in the saved handles.
%   -> The automation on IconNMR will start.
%
% [...] = ExtSet_GUI_function{'C:\Users\...\autoModeHandles.mat',0,[2 3.5],[4.2,4.8]};
%   -> call auto-mode using the saved handles (autoModeHandles.mat) to
%   begin a new flow of experiments, where the region for area calculation
%   is [2 3.5], and the reference region is [4.2,4.8], that will be logged
%   in the saved handles. 
%   -> The automation on IconNMR will start.
%
% [...] = ExtSet_GUI_function{'C:\Users\...\autoModeHandles.mat',1};
%   -> call auto-mode using the saved handles (autoModeHandles.mat) to
%   continue the started flow of experiments, with the same region as
%   before for area calculation.
%   -> The automation on IconNMR is still running.
%
% [...] = ExtSet_GUI_function{'C:\Users\...\autoModeHandles.mat',1,[3.7 4.1]};
%   -> call auto-mode using the saved handles (autoModeHandles.mat) to
%   continue the strated flow of experiments, where the region for area
%   calculation is changes to [3.7 4.1], keeping the same reference region
%   from the saved handles, and the area is again calculated for all
%   previous experiments as well.
%   -> The automation on IconNMR is still running.
%
% [...] = ExtSet_GUI_function{'C:\Users\...\autoModeHandles.mat',1,[3.7 4.1],[4.2,4.8]};
%   -> call auto-mode using the saved handles (autoModeHandles.mat) to
%   continue the strated flow of experiments, where the region for area
%   calculation is changes to [3.7 4.1] and the reference region to
%   [4.2,4.8], and the area is again calculated for all previous
%   experiments as well. 
%   -> The automation on IconNMR is still running.
%
% [...] = ExtSet_GUI_function(...,'last');
%   -> call auto-mode using the saved handles (autoModeHandles.mat) to
%   start/continue the strated flow of experiments, where this call will be
%   the last one.
%   -> The automation on IconNMR is stopped at the end.
%
% ExtSet_GUI_function('start');
%   -> The automation on IconNMR is started immediately.
%
% ExtSet_GUI_function('stop');
%   -> The automation on IconNMR is stopped immediately.
%
% ExtSet_GUI_function('list');
%   -> The Interface is called only to select the experiments list.
%   The first output will be path of the saved handles.
%
% Nour EL SABBAGH - 2022

% clc,varargin = {'C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\Post_Doc_codes\Automation User Interface v5\autoModeHandles.mat',0};
% clc,varargin = {'C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\Post_Doc_codes\Automation User Interface v5\autoModeHandles.mat',1};
% clc,varargin = {'C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\Post_Doc_codes\Automation User Interface v5\autoModeHandles.mat',0,[1 3.5]};
% clc,varargin = {'C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\Post_Doc_codes\Automation User Interface v5\autoModeHandles.mat',1,[1 3.5]};
% clc,varargin = {'C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\Post_Doc_codes\Automation User Interface v5\autoModeHandles.mat',0,[1 3.5],'last'};
% clc,varargin = {'C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\Post_Doc_codes\Automation User Interface v5\autoModeHandles.mat',0,[3 4],[2 3],'last'};
% clc,varargin = {'C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\Post_Doc_codes\Automation User Interface v5\autoModeHandles.mat',0,[1.35 1.73],[3.8 4.2],'maxi'};nargin = 5;
% clc,varargin = {'stop'};
% clc,varargin = {'list'};
% clc,varargin = {};
%% Section Content

% Introduction
% Section Content
% Evaluate the input argument
% Check which mode is requested : manual of auto
% Check available screens : double
% Auto-mode
% Manual-mode
    % User Input
    % User choice to refresh some information gathered from IconNMR files
    % List of IconNMR users and their corresponding configuration
    % List of IconNMR Solvents
    % List of IconNMR Experiments
    % Get the default Parameters from pars files
    % Refresh Status dialog
    % Gather lists into interface parameters
    % Create The Interface Figure
    % Panels
    % Import Struct
    % Panel Fixed Input
    % Panel Experimental Input
    % Panel Parameters Input (Optional)
    % Panel Edit Input
    % Panel Display Extset Text File
    % Auto Insert
    % Experiment Save Log
    % Some Variable Preparation
    % Output
% Callbacks
    % Pre-Interface Callbacks
    % Interface General Callback
    % Fixed Input Callback
    % Experiment Input Panel Callbacks
    % Parameters Input Panel Callbacks
    % Edit Experiments List Panel Callbacks
    % Display Exset Text File Panel Callbacks
    % Status Table Callback

    clc
    clearvars -except varargin nargin varargout nargout
% close all

% % File path of this script
% addpath(genpath('C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\Post_Doc_codes\Automation User Interface v5'))
% % File path of the SCP functions
% addpath(genpath('C:\Users\elsabbagh-n\Documents\MATLAB\Freedman_ssh'))
%% Initialization
global h
h = struct;
h.test = 1; % if 1, then no "real" transfer
h.TSarea = 1; % if 1, get area from topspin
h.shimWhileSearchPlateau = 1; % if 1, shim after each experiment
h.ShimO1p = 0.8519;%1.0297;%0.9476;
if h.test==0 % "real" transfer
    if nargin==0
        % User's Choice :  real experiment?
        opts.Interpreter = 'tex';
        opts.Default = 'No';
        quest = {'Would you like to launch real experiments?'};
        
        % Dialog print
        fprintf('\n[ ? ] Real experiments?\n')
        
        answer0 = questdlg(quest,'Real experiments',...
            'Yes','No',opts);
        switch answer0
            case 'Yes'
                h.test = 0; % "real" transfer
                fprintf('The real-deal...\n')
            case 'No'
                h.test = 1; % no "real" transfer
                fprintf('Semi-simulation...\n')
        end
    end
    checkIconNMROpen = 1;
    if size(varargin,2)==3
        if strcmp(varargin{3},'exprun')
            checkIconNMROpen = 0;
        end
    end
    if checkIconNMROpen
        if ~(nargin==1 && strcmp(varargin{1},'list'))
            if h.test==0 % "real" transfer
                % Check the history file, and see if IconNMR Automation is open or not
                newestHist = 1;
                quickCheck = 1;
                timeline = 0;
                tracking = 1;
                while(tracking)
                    tracking = tracking+1;
                    histTrack = track_history(newestHist,quickCheck,timeline);
                    if isempty(histTrack.iconNMR_ON)
                        if tracking==3
                            fprintf('\n IconNMR is not open ! Make sure it is.\n')
                            err={'The required windows are not open...','The attempt was abandoned !'};
                            msgbox(err);
                            Area = [];Region = [];
                            return
                        elseif tracking==2
                            err={'IconNMR is not open !','Open it before closing this message !'};
                            nes_msgbox = msgbox(err);
                            nes_msgbox.Children(1).Enable = 'off';
                            pause(3)
                            nes_msgbox.Children(1).Enable = 'on';
                            waitfor(nes_msgbox)
                        end
                    elseif histTrack.iconNMR_ON{end}==0
                        if tracking==3
                            fprintf('\n IconNMR is not open ! Make sure it is.\n')
                            err={'The required windows are not open...','The attempt was abandoned !'};
                            msgbox(err);
                            Area = [];Region = [];
                            return
                        elseif tracking==2
                            err={'IconNMR is not open !','Open it before closing this message !'};
                            nes_msgbox = msgbox(err);
                            nes_msgbox.Children(1).Enable = 'off';
                            pause(3)
                            nes_msgbox.Children(1).Enable = 'on';
                            waitfor(nes_msgbox)
                        end
                    else
                        if tracking==2
                            tracking = 3;
                        end
                        if isempty(histTrack.automation_ON)
                            if tracking==4
                                fprintf('\n IconNMR Automation window is not open ! Make sure it is.\n')
                                err={'The required windows are not open...','The attempt was abandoned !'};
                                msgbox(err);
                                Area = [];Region = [];
                                return
                            elseif tracking==3
                                err={'IconNMR Automation window is not open !','Open it before closing this message !'};
                                nes_msgbox = msgbox(err);
                                nes_msgbox.Children(1).Enable = 'off';
                                pause(3)
                                nes_msgbox.Children(1).Enable = 'on';
                                waitfor(nes_msgbox)
                            end
                        elseif  histTrack.automation_ON{end}==0
                            if tracking==4
                                fprintf('\n IconNMR Automation window is not open ! Make sure it is.\n')
                                err={'The required windows are not open...','The attempt was abandoned !'};
                                msgbox(err);
                                Area = [];Region = [];
                                return
                            elseif tracking==3
                                err={'IconNMR Automation window is not open !','Open it before closing this message !'};
                                nes_msgbox = msgbox(err);
                                nes_msgbox.Children(1).Enable = 'off';
                                pause(3)
                                nes_msgbox.Children(1).Enable = 'on';
                                waitfor(nes_msgbox)
                            end
                        else
                            tracking = 0;
                            fprintf('\n Rock-on ! IconNMR Automation window is open !\n')
                        end
                    end
                end
            end
        end
    end
end
%% Evaluate the input argument
% if ~exist(varargin,'var')
%     varargin = [];
% end
h.userExpListSelection = 0; % 0 by default, and 1 to call only to select the list of experiments
h.userExpListSelection_plateau = 0; % 0 by default, and 1 to call only to select the 1 experiment to search for a plateau
if ~(size(varargin,2)==0)
    if length(varargin)==1 || length(varargin)<=5
        if length(varargin)==1
            if ischar(varargin{1})
                if strcmp(varargin{1},'stop')
                    % optimum reach at the previous iteration so stop the
                    % automation
                    if h.test==0 % 'real' experiments
                        % Check the history file, and see if automaton is running
                        newestHist = 1;
                        quickCheck = 1;
                        timeline = 0;
                        histTrack = track_history(newestHist,quickCheck,timeline);
                        if isempty(histTrack.automation_RUN)
                            fprintf('\nNo running automation to be stopped.\n\n')
                        elseif histTrack.automation_RUN{end}==0
                            fprintf('\nNo running automation to be stopped.\n\n')
                        else
                            h.autoMode = 1;
                            % Stop the automation (STOP button callback)
                            callback17(1)
                            fprintf('\nAutomation stopped after all iterations.\n')
                        end
                    else % no 'real' experiments
                        % Get saved value
                        load(['C:\Users\elsabbagh-n\Documents\MATLAB'...
                            '\NEScode\Post_Doc_codes\Automation User '...
                            'Interface v5\lastIteration.mat'],...
                            'lastIteration')
                        if lastIteration==1
                            fprintf('\nNo running automation to be stopped.\n\n')
                        else
                            lastIteration = 1;
                            save(['C:\Users\elsabbagh-n\Documents\MATLAB'...
                                '\NEScode\Post_Doc_codes\Automation User '...
                                'Interface v5\lastIteration.mat'],...
                                'lastIteration')
                            h.autoMode = 1;
                            % Stop the automation (STOP button callback)
                            callback17(1)
                            fprintf('\nAutomation stopped after all iterations.\n')
                        end
                    end
                    return
                elseif strcmp(varargin{1},'start')
                    % single request : start automation
                    if h.test==0 % 'real' experiments
                        % Check the history file, and see if automaton is running
                        newestHist = 1;
                        quickCheck = 1;
                        timeline = 0;
                        histTrack = track_history(newestHist,quickCheck,timeline);
                        if isempty(histTrack.automation_RUN)
                            h.autoMode = 1;
                            h.running = 0;
                            h.DontStartRunning = 0;
                            % Start the automation (START button callback)
                            callback18(1)
                            fprintf('\nAutomation started at the beginning of all iterations.\n')
                        elseif histTrack.automation_RUN{end}==0
                            h.autoMode = 1;
                            h.running = 0;
                            h.DontStartRunning = 0;
                            % Start the automation (START button callback)
                            callback18(1)
                            fprintf('\nAutomation started at the beginning of all iterations.\n')
                        else
                            fprintf('\nAutomation already ON.\n\n')
                        end
                    else % no 'real' experiments
                    end
                    return
                elseif strcmp(varargin{1},'list')
                    h.userExpListSelection = 1;
                elseif strcmp(varargin{1},'listplateau')
                    h.userExpListSelection = 1;
                    h.userExpListSelection_plateau = 1;
                else
                    fprintf('\n Single argument is not correct. Only ''stop'',''list'' or ''listplateau'' can be called in this case.\n')
                    Area = [];
                    Region = [];
                    return
                end
            else
                fprintf('\n Single argument is not correct. Only ''stop'' or ''list'' can be called in this case.\n')
                Area = [];
                Region = [];
                return
            end
        end
    else
        fprintf('\n At least one argument is missing.\n')
        Area = [];
        Region = [];
        return
    end
    if h.userExpListSelection==0
        % Check othe entries
        args = {'savedHandlepath','cont','AREA','AREAREF'};
        % Default parameters : 
        h.decreasing = 0;% The system looks for an increase of area values for 'max?' option by default
        lastIteration = 0;% Not the last call by default
        handlesCalled = 0;% Needed handles still missing by default
        untilAreaMax = 0;% Search for a plateau not called by default
        h.DontStartRunning = 0;% Dont start the automation as it is already on
        RenewExpNumb = 1;% 0 keep exp number as they are, even if new beginning
        j = 1;
        for i = 1:length(varargin)
            if ischar(varargin{i})
                if length(varargin{i})>=4
                    if strcmp(varargin{i}(end-3:end),'.mat')
                        eval([args{j} ' = varargin{i};'])
                        j = j+1;
                        handlesCalled = 1;
                    elseif strcmp(varargin{i},'last')
                        
                        lastIteration = 1;
                    elseif strcmp(varargin{i},'last0')
                        lastIteration = 1;
                        h.DontStartRunning = 1;
                        RenewExpNumb = 0;
                    elseif strcmp(varargin{i},'exprun')
                        lastIteration = 0;
                        h.DontStartRunning = 1;
                        RenewExpNumb = 0;
                    elseif strcmp(varargin{i},'last00')
                        lastIteration = 1;
                        h.DontStartRunning = 0;
                        RenewExpNumb = 0;
                    elseif strcmp(varargin{i}(1:3),'max')
                        untilAreaMax = 1;
                        lastIteration = 1;
                        if strcmp(varargin{i},'maxi') % auto and default prctg
                            h.Control = 0;% no control of user, only 'maxi' condition stands
                            h.prctg = 0.025;% default
                        elseif strcmp(varargin{i},'max-') % auto and default prctg but with decreasing area values
                            h.Control = 0;% no control of user, only 'maxi' condition stands
                            h.prctg = 0.025;% default
                            h.decreasing = 1; % decreasing values
                        elseif ~isempty(cell2mat(textscan(varargin{i},'max%f'))) % auto and prctg from user
                            h.Control = 0;% no control of user, only 'maxi' condition stands
                            h.prctg = cell2mat(textscan(varargin{i},'max%f'))/100; % auto and prctg from user
                            if h.prctg<=0 % prctg from user with decreasing area values
                                h.prctg = abs(h.prctg);
                                h.decreasing = 1; % decreasing values
                            end
                        elseif strcmp(varargin{i},'maxu') % auto and default prctg with area evolution detection
                            h.Control = 0;% no control of user, only 'maxi' condition stands
                            h.prctg = 0.025;% default
                            h.decreasing = 2; % increasing or decreasing values
                        elseif strcmp(varargin{i},'maxuc') % control with auto hidden and default prctg with area evolution detection
                            h.DontStartRunning = 1;
                            h.Control = 5;% control of user, with indication when 'maxi' condition reached
                            h.prctg = 0.002;% default
                            h.decreasing = 2; % increasing or decreasing values
                            lastIteration = 0;
                        elseif ~isempty(cell2mat(textscan(varargin{i},'maxu%f'))) % auto and prctg from user
                            h.Control = 0;% no control of user, only 'maxi' condition stands
                            h.prctg = abs(cell2mat(textscan(varargin{i},'maxu%f'))/100); % auto and prctg from user
                            h.decreasing = 2; % increasing or decreasing values
                        elseif strcmp(varargin{i},'maxc') % control
                            h.prctg = 0.025; % default
                            h.Control = 1;% user chooses when to stop, 'maxi' condition not priority
                            h.decreasing = 2; % increasing or decreasing values
                        elseif strcmp(varargin{i},'maxp') % auto -> control
                            h.prctg = 0.025;% default
                            h.Control = 2;% user chooses when to stop after 'maxi' condition approved
                            h.decreasing = 2; % increasing or decreasing values
                        elseif ~isempty(cell2mat(textscan(varargin{i},'maxp%f'))) % auto -> control and prctg from user
                            h.Control = 2;% user chooses when to stop after 'maxi' condition approved
                            h.prctg = cell2mat(textscan(varargin{i},'maxp%f'))/100; % auto and prctg from user
                            if h.prctg<=0 % prctg from user with decreasing area values
                                h.prctg = abs(h.prctg);
                                h.decreasing = 1; % decreasing values
                            end
                        else % auto and default prctg
                            h.Control = 0;% no control of user, only 'maxi' condition stands
                            h.prctg = 0.025;
                        end
                    elseif strcmp(varargin{i}(1:3),'til')
                        % conditions same as 'exprun'
                        untilAreaMax = 1;
                        lastIteration = 0;
                        h.DontStartRunning = 1;
                        h.Control = 6;% stop at certain time
                        h.StopTime = datetime(varargin{i}(6:end),'Format','HH_mm_ss');
                        h.StopTime.Format = 'HH:mm:ss';
                        h.prctg = 0.002;% default
                        h.decreasing = 2; % increasing or decreasing values
                    else
                        if handlesCalled==0
                            fprintf('The path for the saved handles is wrong or not inputted. The iteration is stopped.')
                            Area = [];
                            Region = [];
                            return
                        else
                            fprintf('The inputted message is wrong, but the iteration will continue without it.')
                        end
                    end
                else
                    if handlesCalled==0
                        fprintf('The path for the saved handles is wrong or not inputted. The iteration is stopped.')
                        Area = [];
                        Region = [];
                        return
                    else
                        fprintf('The inputted message is wrong, but the iteration will continue without it.')
                    end
                end
            else
                eval([args{j} ' = varargin{i};'])
                j = j+1;
            end
        end
    end
end
%% Check which mode is requested : manual of auto

if exist('savedHandlepath','var')
    % Auto mode
    h.autoMode = 1;
else
    % Manual mode
    h.autoMode = 0;
%     close all
end
%% Check available screens : double

if size(get(groot,'MonitorPositions'),1)==1
    % Nb of screens
    h.screen = 1;
else
    % Nb of screens
    h.screen = 2;
end
%% Auto-mode
if h.autoMode
    %% Get required experiment information from handles
    % Get saved handles
    load(savedHandlepath,'autoModeHandles')
    
    % Check if all fields are present
    MustFielnames = {'Table','area','archive','status','fileName'};
    [~,a] = ismember(MustFielnames,fieldnames(autoModeHandles));
    % if a field is missing, stop auto-mode and then call Manual mode to
    % save the handles correctly
    if find(~a)
        fprintf('\nSome fields are missing in the saved handles.')
        fprintf(['\nFor the list of desired experiments to be correctly'...
            ' saved, the regular manual interface will start in ...\n'])
        fprintf('\n 5 \n')
        pause(1)
        fprintf('\n 4 \n')
        pause(1)
        fprintf('\n 3 \n')
        pause(1)
        fprintf('\n 2 \n')
        pause(1)
        fprintf('\n 1 \n')
        pause(1)
        % Call the Manual-mode
        [Area,Region] = ExtSet_GUI_function;
        return
    end
    
    % See if the status figure is open, if not, open a new one
    FigureHandle = get(0, 'Children');
    if isempty(FigureHandle) % no open figure
        % Path where the handles are or will be saved
        saveHere = 'C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\Post_Doc_codes\Automation User Interface v5';
%         nameFig = ['autoModeHandles_fig_screen' num2str(h.screen) '.fig'];
        nameFig = ['autoModeHandles_fig_screen' num2str(h.screen) '_tab.fig'];
        if isfile([saveHere '\' nameFig])
            openfig([saveHere '\' nameFig]);
        else
            initialize_figures(2,h.screen,h.autoMode,saveHere); % with tabs
        end
        drawnow
    else % open figure(s)
        a = 0;
        for i = 1:length(FigureHandle)
            if strcmp(FigureHandle(i).Name,'Status')
               if a==0
                   a = i;
               else
                   % close the unnecessary open status figure (only one
                   % is needed)
                   close(FigureHandle(i))
               end
            end
        end
        if a==0 % no status figure between the open ones
            % open
            % Path where the handles are or will be saved
            saveHere = 'C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\Post_Doc_codes\Automation User Interface v5';
%             nameFig = ['autoModeHandles_fig_screen' num2str(h.screen) '.fig'];
            nameFig = ['autoModeHandles_fig_screen' num2str(h.screen) '_tab.fig'];
            if isfile([saveHere '\' nameFig])
                openfig([saveHere '\' nameFig]);
            else
                initialize_figures(2,h.screen,h.autoMode,saveHere); % with tabs
            end
            drawnow
        else
            if cont==1
                % Call the status figure (put on top) if already opened
                figure(FigureHandle(a))
            else
                if untilAreaMax==0
                    set(FigureHandle(a),'CloseRequestFcn','closereq'); % default function
                    close(FigureHandle(a))
                    % open
                    % Path where the handles are or will be saved
                    saveHere = 'C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\Post_Doc_codes\Automation User Interface v5';
                    nameFig = ['autoModeHandles_fig_screen' num2str(h.screen) '_tab.fig'];
                    if isfile([saveHere '\' nameFig])
                        openfig([saveHere '\' nameFig]);
                    else
                        initialize_figures(2,h.screen,h.autoMode,saveHere); % with tabs
                    end
                else
                    % Call the status figure (put on top) if already opened
                    figure(FigureHandle(a))
                end
            end
        end
    end
    
    % See if a new area region has been indicated by the user; if not, the
    % previously saved region autoModeHandles.mat will be used.
    regionChangedBetweenIterations = 0;
    if exist('AREA','var')
        % check if the bounds are correctly inserted
        if AREA(1)>AREA(2) %#ok<NODEF>
            % log the area in the (future) saved handles
            if (~isequal([AREA(2),AREA(1)],autoModeHandles.area)) && cont==1
                regionChangedBetweenIterations = 1;
                autoModeHandles.area = [AREA(2),AREA(1)];
            elseif (~isequal([AREA(2),AREA(1)],autoModeHandles.area))
                autoModeHandles.area = [AREA(2),AREA(1)];
            end
        elseif AREA(1)==AREA(2)
            ask = 1;
            % Dialog print
            fprintf('\nThe bounds are equal. Please choose another ones. (press ENTER key for a quick OK)\n')
            % Check variables
            l1 = 1;l2 = 1;
            while (ask)
                % User's Choice :  change this bound?
                quest = {'Lower bound','Larger bound'};
                % Default answers
                if l1
                    answrs{1} = '';
                    % Dialog print
                    fprintf('Input another low bound. (press ENTER key for a quick OK)\n')
                else
                    answrs{1} = num2str(answer(1));
                end
                if l2
                    answrs{2} = '';
                    % Dialog print
                    fprintf('Input another large bound. (press ENTER key for a quick OK)\n')
                else
                    answrs{2} = num2str(answer(2));
                end
                % Dialog window : Input bounds
                answer0 = inputdlg(quest,'Input bounds',[1 40],answrs);
                answer(1) = str2double(answer0{1});
                answer(2) = str2double(answer0{2});
                if ~isempty(answer(1))
                    % no need to ask the user to input again the lower bound
                    ask1 = 0;
                    l1 = 0;
                else
                    % ask the user to input again the lower bound
                    ask1 = 1;
                    l1 = 1;
                end
                if ~isempty(answer(1))
                    if ~(answer(2)<=answer(1))
                        % no need to ask the user to input again the larger bound
                        ask2 = 0;
                        l2 = 0;
                    else
                        % ask the user to input again the larger bound
                        ask2 = 1;
                        l2 = 1;
                    end
                else
                    % ask the user to input again the larger bound
                    ask2 = 1;
                    l2 = 1;
                end
                % ask(=1 or 2) or no(=0)?
                ask = ask1+ask2;
            end
            % log the area in the (future) saved handles
            if (~isequal([answer(1),answer(2)],autoModeHandles.area)) && cont==1
                regionChangedBetweenIterations = 1;
                autoModeHandles.area = [answer(1),answer(2)];
            elseif (~isequal([answer(1),answer(2)],autoModeHandles.area))
                autoModeHandles.area = [answer(1),answer(2)];
            end
        else
            % log the area in the (future) saved handles
            if (~isequal(AREA,autoModeHandles.area)) && cont==1
                regionChangedBetweenIterations = 1;
                autoModeHandles.area = AREA;
            elseif (~isequal(AREA,autoModeHandles.area))
                autoModeHandles.area = AREA;
            end
        end
    end
    % Get the area from the saved handles
    AREA = autoModeHandles.area; %#ok<NASGU>
    
    if exist('AREAREF','var')
        % check if the bounds are correctly inserted
        if AREAREF(1)>AREAREF(2) %#ok<NODEF>
            % log the area in the (future) saved handles
            if (~isequal([AREAREF(2),AREAREF(1)],autoModeHandles.areaRef)) && cont==1
                regionChangedBetweenIterations = 1;
                autoModeHandles.areaRef = [AREAREF(2),AREAREF(1)];
            elseif (~isequal([AREAREF(2),AREAREF(1)],autoModeHandles.areaRef))
                autoModeHandles.areaRef = [AREAREF(2),AREAREF(1)];
            end
        elseif AREAREF(1)==AREAREF(2)
            ask = 1;
            % Dialog print
            fprintf('\nThe bounds are equal. Please choose another ones. (press ENTER key for a quick OK)\n')
            % Check variables
            l1 = 1;l2 = 1;
            while (ask)
                % User's Choice :  change this bound?
                quest = {'Lower bound','Larger bound'};
                % Default answers
                if l1
                    answrs{1} = '';
                    % Dialog print
                    fprintf('Input another low bound. (press ENTER key for a quick OK)\n')
                else
                    answrs{1} = num2str(answer(1));
                end
                if l2
                    answrs{2} = '';
                    % Dialog print
                    fprintf('Input another large bound. (press ENTER key for a quick OK)\n')
                else
                    answrs{2} = num2str(answer(2));
                end
                % Dialog window : Input bounds
                answer0 = inputdlg(quest,'Input bounds',[1 40],answrs);
                answer(1) = str2double(answer0{1});
                answer(2) = str2double(answer0{2});
                if ~isempty(answer(1))
                    % no need to ask the user to input again the lower bound
                    ask1 = 0;
                    l1 = 0;
                else
                    % ask the user to input again the lower bound
                    ask1 = 1;
                    l1 = 1;
                end
                if ~isempty(answer(1))
                    if ~(answer(2)<=answer(1))
                        % no need to ask the user to input again the larger bound
                        ask2 = 0;
                        l2 = 0;
                    else
                        % ask the user to input again the larger bound
                        ask2 = 1;
                        l2 = 1;
                    end
                else
                    % ask the user to input again the larger bound
                    ask2 = 1;
                    l2 = 1;
                end
                % ask(=1 or 2) or no(=0)?
                ask = ask1+ask2;
            end
            % log the area in the (future) saved handles
            if (~isequal([answer(1),answer(2)],autoModeHandles.areaRef)) && cont==1
                regionChangedBetweenIterations = 1;
                autoModeHandles.areaRef = [answer(1),answer(2)];
            elseif (~isequal([answer(1),answer(2)],autoModeHandles.areaRef))
                autoModeHandles.areaRef = [answer(1),answer(2)];
            end
        else
            % log the area in the (future) saved handles
            if (~isequal(AREAREF,autoModeHandles.areaRef)) && cont==1
                regionChangedBetweenIterations = 1;
                autoModeHandles.areaRef = AREAREF;
            elseif (~isequal(AREAREF,autoModeHandles.areaRef))
                autoModeHandles.areaRef = AREAREF;
            end
        end
    end
    % Get the ref area from the saved handles
    AREAREF = autoModeHandles.areaRef; %#ok<NASGU>
    
    % Initialize variables
    if cont==0 % New beginning of the experiments flow (no continuous)
        if untilAreaMax==0
            if RenewExpNumb
                % Empty the experiment archive
                autoModeHandles.archive = [];
                % Give the list of experiments a number in the requested order
                autoModeHandles.Table.ExpNo(2:end) = (1:length(autoModeHandles.Table.ExpNo)-1)';
            end
        else
            % Get the saved handles
            h.status = autoModeHandles.status;
        end
    else % Continuing flow experiments
        % Get the saved handles
        h.status = autoModeHandles.status;
    end
    h.fileName = autoModeHandles.fileName; % name of the IconNMR status file
    h.Experiment_Table = autoModeHandles.Table; % table of the requested experiments list
    if untilAreaMax
        if size(h.Experiment_Table,1)==2
            h.untilAreaMax = 1;
        else
            h.untilAreaMax = 0;
            fprintf(['\n\nTo run experiments in a loop until maximum area'...
                ' is reached, only one experiment should be sent.'...
                '\nThe current list of desired experiments contains more '...
                'than one.\n\nNo loop to be applied.\n\n'])
        end
    else
        h.untilAreaMax = 0;
    end
    h.archive = autoModeHandles.archive; % get launched experiments archive (empty if beginning)
    if cont
        % Check if the automation is called before the continuous mode
        getuiTable = 0;
        FigureHandle = get(0, 'Children');
        FigureHandle = FigureHandle(1);
        c = class(FigureHandle.Children);
        c = split(c,'.'); c = c(end);
        if strcmpi(c{1},'tabgroup')
            if strcmpi(FigureHandle.Children(1).Children(1).Title(1:6),'status')
                FigureHandle = FigureHandle.Children(1).Children(1);
            else
                FigureHandle = FigureHandle.Children(1).Children(2);
            end
        end
        c = class(FigureHandle.Children);
        c = split(c,'.'); c = c(end);
        if ismember(lower(c),{'tabgroup'})
            % The status window contains tabs
            if strcmp(FigureHandle.Children.Children(1).Title,'Status table & Area setup')
                FigureHandle = FigureHandle.Children.Children(1);
            elseif strcmp(FigureHandle.Children.Children(2).Title,'Status table & Area setup')
                FigureHandle = FigureHandle.Children.Children(2);
            end
        end
        for i = 1:length(FigureHandle.Children)
            c = class(FigureHandle.Children(i));
            c = split(c,'.'); c = c(end);
            [~,a] = ismember(lower(c),'table');
            if a % children is a table
                getuiTable = FigureHandle.Children(i);
                continue
            end
        end
        c = class(getuiTable);c = split(c,'.'); c = c(end);
        if ismember(lower(c),'table')
            if isempty(getuiTable.Data) % no automation started
                fprintf(['\n No previous flow experiment launched, therefore '...
                    'continuous mode was ignored !\n A new flow experiment '...
                    'will be called with the same input.\n'])
                % Retrieve the input items
                l = length(varargin);
                if l>=1
                    collectedVarargin = 'savedHandlepath';
                    if l>=2
                        collectedVarargin = [collectedVarargin,',0'];
                        if l>=3
                            if exist('AREA','var')
                                collectedVarargin = [collectedVarargin,',AREA'];
                            end
                            if exist('AREAREF','var')
                                collectedVarargin = [collectedVarargin,',AREAREF'];
                            end
                            for i = 3:l
                                if ischar(varargin{i})
                                    collectedVarargin = [collectedVarargin,',''',varargin{i},'''']; %#ok<AGROW>
                                end
                            end
                        end
                    end
                else
                    collectedVarargin = '';
                end
                % Starting flow experiments with the same input and output.
                if nargout==0
                    fprintf(['\n\n  ==>  ExtSet_GUI_function(' collectedVarargin ')\n'])
                    pause(2)
                    eval(['ExtSet_GUI_function(' collectedVarargin ');'])
                elseif nargout==1
                    fprintf(['\n\n  ==>  Area = ExtSet_GUI_function(' collectedVarargin ')\n'])
                    pause(2)
                    eval(['Area = ExtSet_GUI_function(' collectedVarargin ');'])
                elseif nargout==2
                    fprintf(['\n\n  ==>  [Area,Region] = ExtSet_GUI_function(' collectedVarargin ')\n'])
                    pause(2)
                    eval(['[Area,Region] = ExtSet_GUI_function(' collectedVarargin ');'])
                elseif nargout==3
                    fprintf(['\n\n  ==>  [Area,Region,pathLatestExp] = ExtSet_GUI_function(' collectedVarargin ')\n'])
                    pause(2)
                    eval(['[Area,Region,pathLatestExp] = ExtSet_GUI_function(' collectedVarargin ');'])
                end
                return
            end
        else
            warning('Check the Status uifigure! It is missing the table !')
            return
        end
        
        % ELSE : Automation was already started. CONTINUE !
        
        % Adjust the number of the required list of experiments at each
        % iteration
        h = next_exps(h);
        %h.textfilename = autoModeHandles.textfilename;
    end
    h.area.AreaRegion = autoModeHandles.area; % region for area calculation
    h.area.regionInsert = 1; % fixed area for auto calculation
    h.area.AreaRegion2 = autoModeHandles.areaRef; % ref region for area calculation
    h.area.regionInsert2 = 1; % fixed area for auto calculation
    if isfield(autoModeHandles,'areaAdditionalList_Num')
        h.areaAdditionalList_Num = autoModeHandles.areaAdditionalList_Num;
    end
    h = extset_generate(h); % generate the extset file for transfer
    h.cont = cont; % variable needed for functions below (attached to a global variable)
    if h.cont
        if ~h.untilAreaMax
            h.running = 1; % automation already started
        else
            h.running = 0; % automation not started yet
        end
    else
        h.running = 0; % automation not started yet
    end
    
    % Get the labels' handles for the target and reference areas in the
    % status window to be filled
    FigureHandle = get(0, 'Children');
    for i = 1:length(FigureHandle)
        if strcmp(FigureHandle(i).Name,'Status')
            FigureHandle = FigureHandle(i);
            break
        end
    end
    FigureHandle.Position(1:2) = [0.0930    0.3736];
    typeChildren = {'label'};
    labelText = {'Target  ','Referenc'};
    textToBeInserted = {['Target       : [ ' ...
        num2str(round(h.area.AreaRegion(1),2)) ' ppm , ' ...
        num2str(round(h.area.AreaRegion(2),2)) ' ppm ]'],...
        ['Reference: [ '  num2str(round(h.area.AreaRegion2(1),2)) ' ppm , ' ...
        num2str(round(h.area.AreaRegion2(2),2)) ' ppm ]']};
    for i = 1:length(FigureHandle.Children)
        c = class(FigureHandle.Children(i));
        c = split(c,'.'); c = c(end);
        [~,a] = ismember(lower(c),typeChildren);
        if a==1 % children is a label
            t = {FigureHandle.Children(i).Text};
            [~,b] = ismember({t{1}{1}(1:8)},labelText);
            if b
                % Fill the labels with the area bounds
                FigureHandle.Children(i).Text = textToBeInserted(b);
            end
        end
    end
    
    if ~isempty(h.area.AreaRegion)
        % Generating the intrng text file
        h = intrng_generate(h);
        % Archive of experiments to those the intrng file was transferred
        h.intrngArchive = [];
        if h.test==0 % 'real' experiments
            % Transfer intrng file to the remote computer
            transfer_to_spectro500(...
                'C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\Post_Doc_codes',...
                'intrng0','/home/nmr/Documents/Nour','intrng')
        end
    end
    %% Callback funtions
    %% Transfer the extset file (Go callback)
    if h.test==0 % 'real' experiments
        if h.untilAreaMax
            if h.cont
                lastMaxiCallNbExp = size(h.status.table,1);
            else
                lastMaxiCallNbExp = 0;
            end
            h.untilAreaMax = 0;
            callback16
            h.untilAreaMax = 1;
        else
            callback16
        end
    end
%     pause(5)
    %% Start the automation (START callback)Status update & Area Calculation
    if h.test==0 % 'real' experiments
        callback18
    end
    %% Repeat transfer until condition if requested
    if h.untilAreaMax
        %% Prepare plot
        MaxIndexOldY = 1;
        count2max = 0;
        expcount = 1;
        % Search if the figure displaying area and darea results already
        % exists, if not, create one
        FigureHandle = get(0, 'Children');
        AreaEvolutionFig = 0;
        for i = 1:length(FigureHandle)
            if strcmp(FigureHandle(i).Name,'Area evolution')
                AreaEvolutionFig(end+1) = i; %#ok<AGROW>
            end
        end
        AreaEvolutionFig = AreaEvolutionFig(2:end);
        if AreaEvolutionFig
            h.figureToMax = FigureHandle(AreaEvolutionFig(1));
            delete(h.figureToMax.Children)
            if length(AreaEvolutionFig)>1
                for i = 2:length(AreaEvolutionFig)
                    close(FigureHandle(AreaEvolutionFig(i)))
                end
            end
        else
            h.figureToMax = figure('Name','Area evolution');%('Position',[4.3333 270.3333 314 288]);
        end
        figure(h.figureToMax)
        h.figureToMax.Position = [1 40 640 420];
        % Set axes for plot
        axe_figureToMax1 = subplot(1,10,1:9);
        % right for diff(Area) values
        yyaxis(axe_figureToMax1,'right');
        % Prepare both increasing or decreasing plot of dY
        p2 = plot(axe_figureToMax1,0,0,0,0,'LineStyle',':','Marker','o','DisplayName','dy');
        p2(2).DisplayName = '-dy';
        yline(axe_figureToMax1,h.prctg,':','HandleVisibility','off')
        if h.decreasing==1
            ylabel(axe_figureToMax1,'-(\partialArea) normalized')
        elseif h.decreasing==0
            ylabel(axe_figureToMax1,'\partialArea normalized')
        elseif h.decreasing==2
            ylabel(axe_figureToMax1,'\pm\partialArea normalized')
        end
        % left for Area values
        yyaxis(axe_figureToMax1,'left');
        hold on
        p1 = plot(axe_figureToMax1,0,'-o','DisplayName','y = Area');
        pref = plot(axe_figureToMax1,0,'--o','DisplayName','y = AreaRef');
        if isfield(h,'areaAdditionalList_Num')
            for i = 1:size(h.areaAdditionalList_Num,1)
                p1_addit(i) = plot(axe_figureToMax1,0,'Marker','o','DisplayName',...
                    ['y' num2str(i) '[' num2str(h.areaAdditionalList_Num(i,1))...
                    ',' num2str(h.areaAdditionalList_Num(i,2)) ']']); %#ok<AGROW>
            end
        end
        hold off
        ylabel(axe_figureToMax1,'Area')
%         ylabel(axe_figureToMax1,'Relative Area')
        xlabel(axe_figureToMax1,'Exp n�')
        if h.Control==5
            title(axe_figureToMax1,'No sign of changing state, yet ...');
        end
        legend(axe_figureToMax1,'Location','bestoutside')
        drawnow
        yyaxis(axe_figureToMax1,'right')
        axe_figureToMax2 = subplot(3,4,[8,12]);
        p3 = plot(axe_figureToMax2,0,0,0,0,'LineStyle',':','Marker','o','DisplayName','dy');
        p3(1).Color = p2(1).Color;
        p3(2).Color = p2(2).Color;
        yline(axe_figureToMax2,h.prctg,':','HandleVisibility','off','LineWidth',3)
        axe_figureToMax2.YColor = axe_figureToMax1.YColor;
        title(axe_figureToMax2,'Zoom on \partialArea normalized',...
            'Color',axe_figureToMax2.YColor,'FontWeight','normal','FontSize',7);
        xlabel(axe_figureToMax2,'Exp n�','FontSize',7)
        axe_figureToMax2.Color = [1,0.95,0.92];
        condition = 1;
        %% Wait for max
        ready_plateau = 0; % 1 if plateau is reached
        ready_halfway2plateau = 0; % 1 if middle of the rise is reached
        InformChangingState = 0; % 1 to change the title
        simuArea = [[9 8.9 9.1 9.2 9 8.9 9.1 9.2 9.3 9.4 9.5 9.6 9.8 10 11 14 18 20]...
            [22 23 24 25 25 25 25 25 25 25 25]];
        while(condition)
            %% TopShim at first experiment and save shim
            if expcount==1
                % SHIM at the first experiment
                maxNbShim = 1; % repeat shim if necessary
                OptB0stdDev = 0.25; % B0 optimal standard deviation
                msg = {'Automatic shim has started on the first experiment !'};
                for i = 2:3*maxNbShim+3
                    msg{i} = '';
                end
                nes_msgbox = msgbox(msg);
                nes_msgbox.Children(1).Enable = 'off';
                nes_msgbox.CloseRequestFcn = [];
                drawnow
                % ASK TOPSPIN to read this experiment
                cmd = ['re ' char(h.Experiment_Table.Name(2)) ' '...
                    num2str(h.Experiment_Table.ExpNo(2)) ' 1 '...
                    '/opt/nmrdata/user/nmr/',...
                    char(h.Experiment_Table.User(2))];
                sendCommand2Topspin(cmd,0)
                % REQUEST topshim on TOPSPIN
                l = 2;
                for i = 1:maxNbShim
                    % o1p=3.3211 / 2.0978 / 1.038
                    cmd = ['topshim lockoff 1h o1p=' num2str(h.ShimO1p) ' selwid=0.5 convcomp'];
                    sendCommand2Topspin(cmd,1)
                    report = read_shim_report_TOPSPIN;
                    l = l+1;
                    nes_msgbox.Children(2).Children.String{l} = ...
                        ['topshim n�' num2str(i) ' : B0 stdDev initial ' num2str(report.Initial_stdDev) ...
                        'Hz , final ' num2str(report.Final_stdDev) 'Hz'];
                    drawnow
                    l = l+1;
                    if report.Final_stdDev>OptB0stdDev
                        if i~=maxNbShim
                            nes_msgbox.Children(2).Children.String{l} = 'Trying to do better ... repeating topshim';
                        else
                            nes_msgbox.Children(2).Children.String{l} = 'Shim not so good... but no more tries...';
                        end
                    else
                        nes_msgbox.Children(2).Children.String{l} = 'Good shim';
                        break
                    end
                    l = l+1;
                    drawnow
                end
                % DELETE OLD SHIM file if exists
                ShimName = 'ShimPlateauNES';
                filePath = '/opt/topspin3.6.2/exp/stan/nmr/lists/bsms';
                delete_file_on_spectro500(filePath,ShimName);
                % ASK TOPSPIN to save shim values
                cmd = ['wsh ' ShimName ' y'];
                sendCommand2Topspin(cmd,0)
                nes_msgbox.Children(2).Children.String{end} = ...
                    'The shim on the first experiment is done.';
                drawnow
                pause(0.25)
                delete(nes_msgbox);clearvars nes_msgbox
            end
            expcount = expcount+1;
            %% Adjust the number of the required list of experiments at each iteration
            h = next_exps(h);
            %% Generate the extset file for transfer
            h = extset_generate(h);
            h.area.AreaRegion = autoModeHandles.area; % region for area calculation
            h.area.regionInsert = 1; % fixed area for auto calculation
            h.area.AreaRegion2 = autoModeHandles.areaRef; % ref region for area calculation
            h.area.regionInsert2 = 1; % fixed area for auto calculation
            %% TopShim before experiment
            if h.shimWhileSearchPlateau && mod(expcount,4)==0
                nes_msgbox = msgbox('Automatic shim has started !');
                nes_msgbox.Children(1).Enable = 'off';
                nes_msgbox.CloseRequestFcn = [];
                drawnow
                % ASK TOPSPIN to read the latest experiment
                if h.Experiment_Table.ExpNo(2)==1
                    cmd = ['re ' char(h.Experiment_Table.Name(2)) ' '...
                        num2str(h.Experiment_Table.ExpNo(2)) ' 1 '...
                        '/opt/nmrdata/user/nmr/',...
                        char(h.Experiment_Table.User(2))];
                else
                    cmd = ['re ' char(h.Experiment_Table.Name(2)) ' '...
                        num2str(h.Experiment_Table.ExpNo(2)-1) ' 1 '...
                        '/opt/nmrdata/user/nmr/',...
                        char(h.Experiment_Table.User(2))];
                end
                sendCommand2Topspin(cmd,0)
                % ASK TOPSPIN to read the shim done at the first experiment
                cmd = ['rsh ' ShimName];
                sendCommand2Topspin(cmd,0)
                % REQUEST topshim on TOPSPIN, ex:
                % 'topshim z6off optsolvent coil=1H tuneb tuneaxyz convcomp'
                % 'topshim tuneb tunebxyz convcomp'
                cmd = ['topshim lockoff 1h o1p=' num2str(h.ShimO1p) ' selwid=0.5 convcomp'];
                sendCommand2Topspin(cmd,1)
                nes_msgbox.Children(2).Children.String = {'The shim is done.',''};
                drawnow
                pause(0.25)
                delete(nes_msgbox);clearvars nes_msgbox
            end
            %% Transfer the extset file (Go button callback)
            if h.test==0 % 'real' experiments
                callback16
            end
            %% Find max area index
            if h.test==0 % 'real' experiments
                Areas_TillNow = cell2mat(h.status.table.Area(lastMaxiCallNbExp+1:end,1));
                RelativeAreas_TillNow = cell2mat(h.status.table.RelativeArea(lastMaxiCallNbExp+1:end,1));
                AreasRef_TillNow = Areas_TillNow./RelativeAreas_TillNow;
%                 Areas_TillNow = cell2mat(h.status.table.RelativeArea(lastMaxiCallNbExp+1:end));
                if isfield(h,'areaAdditionalList_Num')
                    Areas_TillNow_addit = cell2mat(h.status.table.AdditionalArea(lastMaxiCallNbExp+1:end,:));
%                     Areas_TillNow_addit = cell2mat(h.status.table.RelativeAdditionalArea(lastMaxiCallNbExp+1:end,:));
                end
            else
                Areas_TillNow = simuArea(1:expcount)';
            end
            % relativeAreas_TillNow = cell2mat(h.status.table.RelativeArea);
            Y = Areas_TillNow;
            Yref = AreasRef_TillNow;
            MaxIndexNewY = find(Y==max(Y),1);
            if h.decreasing==0
                dY = diff(Y);
            elseif h.decreasing==1
                dY = -diff(Y);
            elseif h.decreasing==2
                dY = [diff(Y),-diff(Y)];
            end
            dYmax = max(dY);
            if sum(dYmax>=1)
                if h.decreasing==2
                    % Checking if it is an increase or a decrease
                    [~,indM] = max(dYmax);
                    yyaxis(axe_figureToMax1,'right')
                    if indM==1
                        h.decreasing = 0;
                        dY = diff(Y);
                        ylabel(axe_figureToMax1,'\partialArea normalized')
                    elseif indM==2
                        h.decreasing = 1;
                        dY = -diff(Y);
                        ylabel(axe_figureToMax1,'-(\partialArea) normalized')
                    end
                    dYmax = max(dY);
                end
                dY = dY/dYmax;
                dYmax = max(dY);
            end
            MaxIndexNewdY = find(dY==dYmax,1);
            % Plot
            yyaxis(axe_figureToMax1,'left')
            p1.YData = Y;p1.XData = 1:length(Y);
            pref.YData = Yref;pref.XData = 1:length(Yref);
            if isfield(h,'areaAdditionalList_Num')
                for i = 1:size(h.areaAdditionalList_Num,1)
                    p1_addit(i).YData = Areas_TillNow_addit(:,i);p1.XData = 1:length(Y);
                end
            end
            % ylim(axe_figureToMax1,[min(0,min(Y)) max(Y)+2])
            ylim(axe_figureToMax1,'auto')
            if ~isempty(MaxIndexNewdY)
                if h.decreasing==2
                    % Plot both increasing or decreasing dY
                    p2(1).YData = dY(:,1);p2(1).XData = 2:length(dY(:,1))+1;
                    p2(2).YData = dY(:,2);p2(2).XData = 2:length(dY(:,2))+1;
                    if length(p2(1).YData)<3
                        p3(1).YData = p2(1).YData;p3(1).XData = p2(1).XData;
                        p3(2).YData = p2(2).YData;p3(2).XData = p2(2).XData;
                    else
                        p3(1).YData = p2(1).YData(end-2:end);p3(1).XData = p2(1).XData(end-2:end);
                        p3(2).YData = p2(2).YData(end-2:end);p3(2).XData = p2(2).XData(end-2:end);
                    end
                else
                    if length(p2)==2
                        delete(p2(2))
                        delete(p3(2))
                        p2 = p2(1);
                        p2.LineStyle = '-';
                        p3 = p3(1);
                        p3.LineStyle = '-';
                    end
                    p2.YData = dY;p2.XData = 2:length(dY)+1;
                    if length(p2.YData)<3
                        p3.YData = p2.YData;p3.XData = p2.XData;
                    else
                        p3.YData = p2.YData(end-2:end);p3.XData = p2.XData(end-2:end);
                    end
                end
%                 yyaxis(axe_figureToMax1,'right')
%                 pos = [axe_figureToMax2.XLim(1)
%                     axe_figureToMax2.YLim(1)
%                     axe_figureToMax2.XLim(2)-axe_figureToMax2.XLim(1)
%                     axe_figureToMax2.YLim(2)-axe_figureToMax2.YLim(1)];
%                 r.Position = pos;
            end
            drawnow
            %% Sending another block of experiments or not
            if h.Control==1
                drawnow
                pause(0.1)
                go = check_user_for_new_experiments(2);
                condition = go;
                continue
            elseif h.Control==5
                if ready_plateau==0
                    if isempty(MaxIndexNewdY)
                        % continue
                    elseif MaxIndexNewdY==1
                        % continue
                    elseif length(Y)<3
                        % continue
                    elseif dYmax<1
                        % continue
                    else
                        % Check for YOYO effect on the Y data
                        last3_Y = Y(end-2:end);
                        condYOYO = false;
                        [~,indx] = sort(last3_Y,'ascend');
                        if h.decreasing==0
                            condYOYO = ~isequal(indx',[1 2 3]);
                        elseif h.decreasing==1
                            condYOYO = ~isequal(indx',[3 2 1]);
                        end
                        if condYOYO
                            % YOYO effect detected on the Y data
                            % Check for YOYO effect on the dY data
                            if length(dY)>3
                                last3_dY = dY(end-2:end);
                                [~,inddx] = sort(last3_dY,'ascend');
                                if ~isequal(inddx',[3 2 1])
                                    % YOYO effect detected on the dY data
                                    % continue
                                else
                                    count2max = count2max+1;
                                    ready_halfway2plateau = 1;
                                end
                            else
                                % continue
                            end
                        elseif isequal(MaxIndexNewY,MaxIndexOldY)
                            count2max = count2max+1;
                            ready_halfway2plateau = 1;
                        else
                            MaxIndexOldY = MaxIndexNewY;
                            count2max = 0;
                        end
                    end
                    if ready_halfway2plateau
                        if dY(end)<=h.prctg
                            ready_plateau = 1;
                            InformChangingState = 1; % signal of a changing state now
                        end
                    end
                elseif ready_plateau%found dY(end)<=h.prctg
                    InformChangingState = 2; % changing state was already signaled, no need more signal
                end
                if InformChangingState==1
                    title(axe_figureToMax1,'Changing state detected !','Color',[0.6353,0.0784,0.1843])
                    xline(axe_figureToMax1,length(Y),':','HandleVisibility','off',...
                        'Label','Plateau is reached','Color','r','LineWidth',1,...
                        'LabelHorizontalAlignment','center',...
                        'LabelVerticalAlignment','middle')
                end
                drawnow
                pause(0.1)
                go = check_user_for_new_experiments(2);
                condition = go;
                continue
            elseif h.Control==6
                TimeNow = datetime('now');
                TimeNow.Format = 'HH:mm:ss';
                go = h.StopTime>TimeNow;
                condition = go;
                continue
            end
            if ready_plateau==0
                if isempty(MaxIndexNewdY)
                    continue
                elseif MaxIndexNewdY==1
                    continue
                elseif length(Y)<3
                    continue
                elseif dYmax<1
                    continue
                else
                    % Check for YOYO effect on the Y data
                    last3_Y = Y(end-2:end);
                    condYOYO = false;
                    [~,indx] = sort(last3_Y,'ascend');
                    if h.decreasing==0
                        condYOYO = ~isequal(indx',[1 2 3]);
                    elseif h.decreasing==1
                        condYOYO = ~isequal(indx',[3 2 1]);
                    end
                    if condYOYO
                        % YOYO effect detected on the Y data
                        % Check for YOYO effect on the dY data
                        if length(dY)>3
                            last3_dY = dY(end-2:end);
                            [~,inddx] = sort(last3_dY,'ascend');
                            if ~isequal(inddx',[3 2 1])
                                % YOYO effect detected on the dY data
                                continue
                            else
                                count2max = count2max+1;
                            end
                        else
                            continue
                        end
                    elseif isequal(MaxIndexNewY,MaxIndexOldY)
                        count2max = count2max+1;
                    else
                        MaxIndexOldY = MaxIndexNewY;
                        count2max = 0;
                    end
                end
                if dY(end)<=h.prctg
                    ready_plateau = 1;
                    if h.Control==2
                        go = check_user_for_new_experiments(2);
                        condition = go;
                    else
                        % if multi evolution (increase and decrease)
                        if h.decreasing>=2
                            if h.decreasing==2 % increasing values
                                go = check_user_for_decreasing_experiments(2);
                                if ~go
                                    h.decreasing = 3;
                                end
                            elseif h.decreasing==3 % decreasing values
                                go = check_user_for_increasing_experiments(2);
                                if ~go
                                    h.decreasing = 2;
                                end
                            end
                        else
                            break
                        end
                    end
                end
            elseif ready_plateau%found dY(end)<=h.prctg
                if h.Control==2
                    go = check_user_for_new_experiments(2);
                    condition = go;
                else
                    % if multi evolution (increase and decrease)
                    if h.decreasing>=2
                        if h.decreasing==2 % increasing values
                            go = check_user_for_decreasing_experiments(2);
                            if ~go
                                h.decreasing = 3;
                            end
                        elseif h.decreasing==3 % decreasing values
                            go = check_user_for_increasing_experiments(2);
                            if ~go
                                h.decreasing = 2;
                            end
                        end
                    else
                        break
                    end
                end
            end
        end
    end
    %% Stop the automation (STOP callback) ('stop','max?' or 'last' inputed)
    if lastIteration
        callback17
    end
    %% Ending : log important information to handles
    if h.test==0 % 'real' experiments
        if cont==0
            % Update the area region in the saved handles
            autoModeHandles.area = h.AreaRegion;
            autoModeHandles.areaRef = h.AreaRegion2;
            autoModeHandles.fileName = h.fileName;
        end
        autoModeHandles.Table = h.Experiment_Table;
        autoModeHandles.archive = h.archive;
        autoModeHandles.status = h.status;
    end
    %% Report
    if h.test==0 % 'real' experiments
        writeFinishingReport
%         if ~h.DontStartRunning
%             autoModeHandles.textfilename = h.textfilename;
%         else
%             autoModeHandles.textfilename = [];
%         end
    else
        if h.untilAreaMax
            ExpNo = (1:length(Areas_TillNow))';
            Area = Areas_TillNow;
            RelativeArea = Areas_TillNow;
        else
            ExpNo = 1;
            Area = 23;
            RelativeArea = 0.5;
        end
        h.AreaResults = table(ExpNo,Area,RelativeArea);
    end
    %% Output
    if nargout>=1
        if regionChangedBetweenIterations==0
            if ~h.untilAreaMax
                %  Output only area of the new experiment of this iteration
                if h.test==0 % 'real' experiments
                    expInQuestion = h.Experiment_Table.ExpNo(2:end);
                    [~,a] = ismember(expInQuestion,double(cell2mat(h.AreaResults.ExpNo)));
                    Area = h.AreaResults(a,:);
                else
                    Area = h.AreaResults;
                end
            else
                % Output everything
                if h.test==0 % 'real' experiments
                    % expInQuestion = double(cell2mat(h.status.uit.Data.ExpNo));
                    expInQuestion = h.Experiment_Table.ExpNo(2:end);
                    [~,a] = ismember(expInQuestion,double(cell2mat(h.AreaResults.ExpNo)));
                    Area = h.AreaResults(a-expcount+1:a,:);
                else
                    Area = h.AreaResults;
                end
            end
        else
            % Output area of the all experiments
            Area = h.AreaResults;
        end
        if nargout>=2
            if h.test==0 % 'real' experiments
                Region = [h.AreaRegion,h.AreaRegion2];
                if nargout>=3
                    pathLatestExp = fullfile('/opt/nmrdata/user/nmr/',...
                        char(h.Experiment_Table.User(2)),...
                        char(h.Experiment_Table.Name(2)),...
                        num2str(h.Experiment_Table.ExpNo(2)));
                    pathLatestExp(pathLatestExp=='\') = '/';
                end
            else
                Region = [autoModeHandles.area,autoModeHandles.areaRef];
                if nargout>=3
                    pathLatestExp = '/opt/nmrdata/user/nmr/Nour/expSimu';
                    pathLatestExp(pathLatestExp=='\') = '/';
                end
            end
        end
    end
    %% Remove figure handles from the saved struct for simpler saving
    if h.test==0 % 'real' experiments
        autoModeHandles.status = rmfield(autoModeHandles.status,'f');
    end
    if isfield(autoModeHandles.status,'F')
        % The status window contains tabs
        autoModeHandles.status = rmfield(autoModeHandles.status,'F');
    end
    % Save handles
    save(savedHandlepath,'autoModeHandles')
    if lastIteration
        fprintf('\nAutomation stopped at this iteration.\n')
    else
        fprintf('\nAutomation still running.\n')
    end
    save(['C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\Post_Doc_codes'...
        '\Automation User Interface v5\lastIteration.mat'],...
        'lastIteration')
    return
end
%% Manual-mode
%% User Input

global hh List default_param_text pathname user_choice Dialog figDialog exps userchange expchange
hh = struct;
List = struct;
h.status = [];
dontAsk = 0;

% File path of this script
pathname = 'C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\Post_Doc_codes\Automation User Interface v5';
% addpath(genpath(pathname))

% Fixed Input for the same Holder
% h.RequiredParameters = {'Holder','User','Solvent','StartRun','StopRun',...
%     'SubmitHolder','NoSubmit','Delete'};
% h.RequiredParameters = {'Holder','User','Solvent','Delete','ReferencePeak','AreaCalculation'};
h.RequiredParameters = {'Holder','User','Solvent','Delete'};

h.AreaParameters = {'ReferencePeak','AreaCalculation'};

% Experimental Input for each experiment
% h.ExperimentalInput = {'Title','Name','ExpNo','Experiment','Imported',...
%     'Priority','StartTime','Night','Delete','Parameters'}';
h.ExperimentalInput = {'Title','Name','ExpNo','Experiment',...
    'Priority','Parameters','ShimProgram'}';%

% Parameters with several options
h.ParametersMulti = {'User','Experiment','Solvent'};

% List of options
% h.ParametersMulti(2:4,1) = {'...','Nour','nmr'}'; % User
% h.ParametersMulti(2:6,2) = {'...','PROTON_NOUR_1','PROTON_NOUR_2','PROTON_Nour','PROTON'}'; % Experiment
% h.ParametersMulti(2:3,3) = {'...','D2O'}'; % Solvent

% List of editable parameters
% h.ParametersInputList = {'D1 [s]','NS ','DS ','SW_H [Hz]','P1 [us]','TD ','O1 [ppm]'}';
h.ParametersInputList = {'D1 [s]','NS ','DS ','SW [ppm]','P1 [us]','TD ','O1 [ppm]','P11 [us]'}';
%% User choice to refresh some information gathered from IconNMR files

if ~isfolder([pathname '\user_config'])
    % create folder
    cd(pathname)
    mkdir  'user_config'
end
if ~isfolder([pathname '\acqu'])
    % create folder
    cd(pathname)
    mkdir  'acqu'
end

% 0 not mandatory
% 1 mandatory

user_config = dir([pathname '\user_config']);
[~,a] = ismember({'IconNMR_Config.mat','Solvent.mat','List.mat'},{user_config.name});
if a(1)==0
    refresh_userConfig = 1; % it is mandatory to refresh user Config
else
    refresh_userConfig = 0; % it is not mandatory to refresh user Config
end
if a(2)==0
    refresh_solv_list = 1; % it is mandatory to refresh solvent list
else
    refresh_solv_list = 0; % it is not mandatory to refresh solvent list
end
if a(3)==0 || ~(length(user_config)>(2+length(find(a))))
    refresh_user_list = 1; % it is mandatory to refresh user list
else
    refresh_user_list = 0; % it is not mandatory to refresh user list
end

user_acqu = dir([pathname '\acqu']);
if refresh_user_list
    refresh_exp_list = 1; % it is mandatory to refresh experiment list
else
    if ~(length(user_acqu)>2)
        refresh_exp_list = 1; % it is mandatory to refresh experiment list
    else
        if refresh_userConfig
            refresh_exp_list = 1; % it is mandatory to refresh experiment list
        else
            refresh_exp_list = 0; % it is not mandatory to refresh experiment list
        end
    end
end

if (h.screen==1)
    figDialog = figure('units','normalized','position',[0.0104 0.0565 0.3484 0.3380],...
        'Name','File Refresh','Visible','off','KeyPressFcn', @EnterKeyPress); % 1 screen
else
    figDialog = figure('units','normalized','position',[-1 0.0370 0.2198 0.2213],...
        'Name','File Refresh','Visible','off','KeyPressFcn', @EnterKeyPress); % 2 screens
end
movegui(gcf,'center');

% Static Texts
Dialog.static_text_field_1 = uicontrol('style','text','units','normalized',...
    'string','Refresh User List : ','FontName','Arial','FontSize',14,...
    'BackgroundColor',[0.94,0.94,0.94],'Parent',figDialog,...
    'Position',[0.05 0.8 0.6 0.09]);
Dialog.static_text_field_2 = uicontrol('style','text','units','normalized',...
    'string','Refresh User Configuration : ','FontName','Arial','FontSize',14,...
    'BackgroundColor',[0.94,0.94,0.94],'Parent',figDialog,...
    'Position',[0.05 0.64 0.6 0.09]);
Dialog.static_text_field_3 = uicontrol('style','text','units','normalized',...
    'string','Refresh Experiment List : ','FontName','Arial','FontSize',14,...
    'BackgroundColor',[0.94,0.94,0.94],'Parent',figDialog,...
    'Position',[0.05 0.48 0.6 0.09]);
Dialog.static_text_field_4 = uicontrol('style','text','units','normalized',...
    'string','Refresh Solvent List : ','FontName','Arial','FontSize',14,...
    'BackgroundColor',[0.94,0.94,0.94],'Parent',figDialog,...
    'Position',[0.05 0.32 0.6 0.09]);

% Push Buttons
Dialog.push_button_1 = uicontrol('style','pushbutton','units','normalized',...
    'BackgroundColor',[0.94,0.94,0.94],'string','DONE','FontName','Arial',...
    'Parent',figDialog,'callback',@callback01,'Position',...
    [0.1 0.1 0.8 0.15],'Value',0,'FontSize',15,...
    'ForegroundColor',[0.05,0.65,0.12]);

% Radio Buttons Groups
bg1 = uibuttongroup('Visible','on','units','normalized','Position',[0.65 0.8 0.3 0.09],'Parent',figDialog);
bg2 = uibuttongroup('Visible','on','units','normalized','Position',[0.65 0.64 0.3 0.09],'Parent',figDialog);
bg3 = uibuttongroup('Visible','on','units','normalized','Position',[0.65 0.48 0.3 0.09],'Parent',figDialog);
bg4 = uibuttongroup('Visible','on','units','normalized','Position',[0.65 0.32 0.3 0.09],'Parent',figDialog);

% Radio Buttons
Dialog.radio_button_1 = uicontrol(bg1,'style','radiobutton','units','normalized',...
    'string','Yes','FontName','Arial','FontSize',10,...
    'BackgroundColor',[0.94,0.94,0.94],'Position',[0.1 0.2 0.5 0.8]);
Dialog.radio_button_2 = uicontrol(bg1,'style','radiobutton','units','normalized',...
    'string','No','FontName','Arial','FontSize',10,...
    'BackgroundColor',[0.94,0.94,0.94],'Position',[0.6 0.2 0.5 0.8]);
Dialog.radio_button_3 = uicontrol(bg2,'style','radiobutton','units','normalized',...
    'string','Yes','FontName','Arial','FontSize',10,...
    'BackgroundColor',[0.94,0.94,0.94],'Position',[0.1 0.2 0.5 0.8]);
Dialog.radio_button_4 = uicontrol(bg2,'style','radiobutton','units','normalized',...
    'string','No','FontName','Arial','FontSize',10,...
    'BackgroundColor',[0.94,0.94,0.94],'Position',[0.6 0.2 0.5 0.8]);
Dialog.radio_button_5 = uicontrol(bg3,'style','radiobutton','units','normalized',...
    'string','Yes','FontName','Arial','FontSize',10,...
    'BackgroundColor',[0.94,0.94,0.94],'Position',[0.1 0.2 0.5 0.8]);
Dialog.radio_button_6 = uicontrol(bg3,'style','radiobutton','units','normalized',...
    'string','No','FontName','Arial','FontSize',10,...
    'BackgroundColor',[0.94,0.94,0.94],'Position',[0.6 0.2 0.5 0.8]);
Dialog.radio_button_7 = uicontrol(bg4,'style','radiobutton','units','normalized',...
    'string','Yes','FontName','Arial','FontSize',10,...
    'BackgroundColor',[0.94,0.94,0.94],'Position',[0.1 0.2 0.5 0.8]);
Dialog.radio_button_8 = uicontrol(bg4,'style','radiobutton','units','normalized',...
    'string','No','FontName','Arial','FontSize',10,...
    'BackgroundColor',[0.94,0.94,0.94],'Position',[0.6 0.2 0.5 0.8]);

% Disable options found mandatory
if refresh_user_list
    set(Dialog.radio_button_1,'Value',1);
    children = get(bg1,'Children');
    set(children,'Enable','off');
else
    set(Dialog.radio_button_2,'Value',1);
    children = get(bg1,'Children');
    set(children,'Enable','on');
end
if refresh_userConfig
    set(Dialog.radio_button_3,'Value',1);
    children = get(bg2,'Children');
    set(children,'Enable','off');
else
    set(Dialog.radio_button_4,'Value',1);
    children = get(bg2,'Children');
    set(children,'Enable','on');
end
if refresh_exp_list
    set(Dialog.radio_button_5,'Value',1);
    children = get(bg3,'Children');
    set(children,'Enable','off');
else
    set(Dialog.radio_button_6,'Value',1);
    children = get(bg3,'Children');
    set(children,'Enable','on');
end
if refresh_solv_list
    set(Dialog.radio_button_7,'Value',1);
    children = get(bg4,'Children');
    set(children,'Enable','off');
else
    set(Dialog.radio_button_8,'Value',1);
    children = get(bg4,'Children');
    set(children,'Enable','on');
end

if sum([refresh_user_list,refresh_userConfig,refresh_exp_list,refresh_solv_list])~=4 && ~dontAsk
    figDialog.Visible = 'on';
    
    % Dialog print
    fprintf('User choice to refresh some information gathered from IconNMR files. (press ENTER key for a quick response)\n')

    uiwait(figDialog)
    refresh_user_list = user_choice(1);
    refresh_userConfig = user_choice(2);
    refresh_exp_list = user_choice(3);
    refresh_solv_list = user_choice(4);
    if ~refresh_user_list
        Tr = 1;
    end
    if ~refresh_solv_list
        Trr = 1;
    end
else
    close(figDialog)
end
%% List of IconNMR users and their corresponding configuration

desiredPath = [pathname '\user_config'];
if refresh_user_list
    % Get the configuration files for each IconNMR user
    userConfigPath = '/opt/topspin3.6.2/conf/instr/spect/inmrusers/';
    if ~isfolder(desiredPath)
        % create folder
        cd(pathname)
        mkdir  'user_config'
    end
    Tr = get_userConfig_from_spectro500(userConfigPath,desiredPath);
    if Tr
        % Get the list of experiment for each IconNMR user
        user_config = dir([pathname '\user_config']);
        List.allExperiment = [];
        List.IconNMR_Config = struct;
        List.ShimProgram = [];
        [~,a] = ismember({'IconNMR_Config.mat','.','..','Solvent.mat','List.mat'},{user_config.name});
        b = find(~ismember(1:length(user_config),a));
        for i = 1:length(user_config)-length(find(a))
            List.IconNMR_Config(i).User = user_config(b(i)).name;
            configFile = regexp(fileread([desiredPath '\' List.IconNMR_Config(i).User]),'\n','split')';
            whichline1 = find(contains(configFile,'Primitive experiments:'),1);
            whichline2 = find(contains(configFile,'Permissions:'),1);
            if (whichline2-1)~=whichline1
                list = whichline1+1:whichline2-1;
                for ll = 1:length(list)
                    exp = textscan(configFile{list(ll)},'%1s %s -%*[^-]{%*[^{}]}');
                    List.IconNMR_Config(i).Experiments{ll,1} = [exp{1}{1} ' - ' exp{2}{1}];
                    %                     List.IconNMR_Config(i).Experiments{ll,1} = exp{2}{1};
                    %                     List.IconNMR_Config(i).Experiments{ll,2} = exp{1}{1};
                end
                %                 List.IconNMR_Config(i).Experiments = configFile(list);
                List.allExperiment = [List.allExperiment;List.IconNMR_Config(i).Experiments];
            end
        end
        % Remove duplicated experiment but keeping the same order
        [~,ia,~] = unique(List.allExperiment(:,1),'stable');
        %         List.allExperiment = unique(List.allExperiment,'stable');
        List.allExperiment = List.allExperiment(ia,:);
        List.check = zeros(size(List.allExperiment,1),1);
        save([pathname '\user_config\List.mat'],'List')
    end
else
    load([pathname '\user_config\List.mat'],'List')
end
%% List of IconNMR Solvents

if refresh_solv_list
    % Get the configuration files for each IconNMR user
    userConfigPath = '/opt/topspin3.6.2/conf/instr/topshim/solvents/';
    if ~isfolder(desiredPath)
        % create folder
        cd(pathname)
        mkdir  'user_config'
    end
    [Trr,Solvent] = get_solvent_from_spectro500(userConfigPath);
    if Trr
        save([pathname '\user_config\Solvent.mat'],'Solvent')
    end
end
%% List of IconNMR Experiments

if ~refresh_userConfig && ~refresh_exp_list && ~dontAsk
    load([pathname '\user_config\IconNMR_Config.mat'],'IconNMR_Config')
    h.IconNMR_Config = IconNMR_Config;
    l = {h.IconNMR_Config.InterfacePackage}; % List of experiment previously chosen
    if ~isempty(l)
        cmmd = '[l{1}';
        for i = 2:length(l)
            cmmd = [cmmd ';l{' num2str(i) '}']; %#ok<AGROW>
        end
        cmmd = [cmmd ']'];
        eval(['l = unique(' cmmd ');'])
    end
    
    % Display the list of experiment previsouly chosen
    if(h.screen==1)
        % figExp = figure('units','normalized','position',[0.0104 0.0565 0.9891 0.8324],...
        %     'Name','Experiment Package'); % 1 screen
        figExp = uifigure('units','normalized','position',[0.0104 0.0565 0.9891 0.8324],...
            'Name','Experiment Package'); % 1 screen
    else
        % figExp = figure('units','normalized','position',[-1 0.0370 0.6667 0.5583],...
        %     'Name','Experiment Package'); % 2 screens
        figExp = uifigure('units','normalized','position',[-1 0.3556 0.6667 0.5583],...
            'Name','Experiment Package'); % 2 screens
    end
    % uicontrol('style','text','units','normalized',...
    %     'string','Interface Experiment Package','FontName','Arial','FontSize',14,...
    %     'BackgroundColor',[0.94,0.94,0.94],'Parent',figExp,...
    %     'Position',[0.05 0.9 0.9 0.05]);
    % uicontrol('style','listbox','units','normalized',...
    %     'Parent',figExp,'Visible','on','FontSize',11,...
    %     'Position',[0.05 0.1 0.9 0.8],'String',l,...
    %     'FontName','Arial');
    uilabel(figExp,'Position',[500 550 500 50],'FontSize',20,'Text','Interface Experiment Package','FontWeight','bold');
    uilistbox(figExp,'Position',[130 70 1000 450],'FontSize',15,'Items',l);

    % User's Choice :  change this list?
    opts.Interpreter = 'tex';
    opts.Default = 'No';
    quest = 'Would you like to empty and fill again the experiment package?';

    % Dialog print
    fprintf('User choice to fill the experiment package. (press ENTER key for a quick response)\n')

    % Dialog window
    answer0 = questdlg(quest,'Experiment Package',...
        'Yes','No',opts);
%     answer0 = MFquestdlg([-0.79 0.3],quest,'Experiment Package',...
%         'Yes','No',opts);
    switch answer0
        case 'Yes'
            refresh_exp_list = 1;
        case 'No'
            refresh_exp_list = 0;
    end
    close(figExp)
end
if refresh_exp_list
    % Interface for creating a package of experiments the user wants to see in the interface
    if(h.screen==1)
        List.figExp = figure('units','normalized','position',[0.0104 0.0565 0.9891 0.8324],...
            'Name','Experiment Package'); % 1 screen
    else
        List.figExp = figure('units','normalized','position',[-1 0.0370 0.6667 0.5583],...
            'Name','Experiment Package'); % 2 screens
    end
    
    % Static Text
    List.static_text_field_1 = uicontrol('style','text','units','normalized',...
        'string','IconNMR Available Experiments','FontName','Arial','FontSize',14,...
        'BackgroundColor',[0.94,0.94,0.94],'Parent',List.figExp,...
        'Position',[0.05 0.9 0.4 0.05]);
    List.static_text_field_2 = uicontrol('style','text','units','normalized',...
        'string','Interface Experiment Package','FontName','Arial','FontSize',14,...
        'BackgroundColor',[0.94,0.94,0.94],'Parent',List.figExp,...
        'Position',[0.55 0.9 0.4 0.05]);
    
    % List Boxes
    %     List.ListString = []; % to mention if the experiment is normal or composite
    %     for i = 1:size(List.allExperiment,1)
    %         List.ListString{i,1} = [List.allExperiment{i,2} ' - ' List.allExperiment{i,1}];
    %     end
    %     ai = find(List.check);
    List.list_box_1 = uicontrol('style','listbox','units','normalized',...
        'Parent',List.figExp,'Visible','on','FontSize',11,...
        'Position',[0.05 0.1 0.4 0.8],'String',List.allExperiment,...
        'FontName','Arial');
    List.list_box_2 = uicontrol('style','listbox','units','normalized',...
        'Parent',List.figExp,'Visible','on','FontSize',11,...
        'Position',[0.55 0.1 0.4 0.8],'String',List.allExperiment(find(List.check)),...
        'FontName','Arial');
    
    % Push Buttons
    List.push_button_1 = uicontrol('style','pushbutton','units','normalized',...
        'BackgroundColor',[0.94,0.94,0.94],'string','+','FontName','Arial',...
        'Parent',List.figExp,'callback',@callback02,'Position',...
        [0.475 0.6 0.05 0.1],'Value',0,'FontSize',50,...
        'ForegroundColor',[0.05,0.65,0.12]);
    List.push_button_2 = uicontrol('style','pushbutton','units','normalized',...
        'BackgroundColor',[0.94,0.94,0.94],'string','-','FontName','Arial',...
        'Parent',List.figExp,'callback',@callback03,'Position',...
        [0.475 0.4 0.05 0.1],'Value',0,'FontSize',50,...
        'ForegroundColor',[0.78,0.22,0.32]);
    List.push_button_3 = uicontrol('style','pushbutton','units','normalized',...
        'BackgroundColor',[0.94,0.94,0.94],'string','Empty','FontName','Arial',...
        'Parent',List.figExp,'callback',@callback04,'Position',...
        [0.55 0.04 0.4 0.05],'Value',0,'FontSize',15);
    List.push_button_4 = uicontrol('style','pushbutton','units','normalized',...
        'BackgroundColor',[0.94,0.94,0.94],'string','Done','FontName','Arial',...
        'Parent',List.figExp,'callback',@callback05,'Position',...
        [0.475 0.2 0.05 0.1],'Value',0,'FontSize',15,'ForegroundColor',[0.05,0.65,0.12]);
    
    % wait until the user has chosen the list of experiments
    uiwait(List.figExp)
    
    % Find the exact name of the chosen experiments used in IconNMR
    desiredPath = [pathname '\acqu'];
    l = {h.IconNMR_Config.InterfacePackage}; % List of experiment previously chosen
    if ~isempty(l)
        cmmd = '[l{1}';
        for i = 2:length(l)
            cmmd = [cmmd ';l{' num2str(i) '}']; %#ok<AGROW>
        end
        cmmd = [cmmd ']'];
        eval(['l = ' cmmd ';'])
        [~,ia,~] = unique(l(:,1),'stable');
        l = l(ia,:);
    end
    for i = 1:size(l,1)
        %         expp = textscan(l{i},'%*s %s -%*[^-]');
        expp = textscan(l{i},'%*s - %[^-]');
        if ~isempty(expp{1})
            exps{i,1} = expp{1}{1};
        else
            if i==1
                exps = l(:,1);
                break
            else
                warning('something wrong here')
                return
            end
        end
    end
    
    % Get the pars files for the chosen experiments
    expPath = '/opt/topspin3.6.2/exp/stan/nmr/par/';
    Trrr = zeros(length(exps),1);
    for i = 1:length(exps)
        folderName = exps{i};
        % NES: The next if line is commented so that the pars files get
        % transferred to update the existing files
%         if ~isfile([desiredPath '\acqu_' folderName])
            Trrr(i,1) = get_acqus_from_spectro500(expPath,folderName,desiredPath,1,0);
            if Trrr(i,1)==0
                fprintf(['Experiment ' folderName ' not found !'])
            end
%         end
    end
end
%% Get the default Parameters from pars files

desiredPath = [pathname '\acqu'];
if ~refresh_exp_list
    user_acqu = dir([pathname '\acqu']);
    exps = [];
    for i = 1:length(user_acqu)-2
        exp = (textscan(user_acqu(i+2).name,'acqu_%s'));
        exps{i,1} = exp{1}{1}; %#ok<AGROW>
    end
    load([pathname '\user_config\IconNMR_Config.mat'],'IconNMR_Config')
    h.IconNMR_Config = IconNMR_Config;
    
    % List of experiment previously chosen
    l = {h.IconNMR_Config.InterfacePackage};
    if ~isempty(l)
        cmmd = '[l{1}';
        for i = 2:length(l)
            cmmd = [cmmd ';l{' num2str(i) '}']; %#ok<AGROW>
        end
        cmmd = [cmmd ']'];
        eval(['l = ' cmmd ';'])
        [~,ia,~] = unique(l(:,1),'stable');
        l = l(ia,:);
    end
    for i = 1:size(l,1)
        %         expp = textscan(l{i},'%*s %s -%*[^-]');
        %         exps2(i,1) = expp{1}; %#ok<SAGROW>
        exps2(i,1) = {l{i}(5:end)};  %#ok<AGROW> % List of experiment previously chosen
    end
    [~,a] = ismember(exps2,exps);
    b = find(a==0);
    for i = 1:length(b)
        % Get the pars files for the chosen experiments
        expPath = '/opt/topspin3.6.2/exp/stan/nmr/par/';
        Trrr = zeros(length(b),1);
        folderName = exps2{b(i)}(5:end);
        Trrr(i,1) = get_acqus_from_spectro500(expPath,folderName,desiredPath,1,0);
        if Trrr(i,1)==0
            fprintf(['Experiment ' folderName ' not found !'])
        end
    end
    user_acqu = dir([pathname '\acqu']);
    exps = [];
    for i = 1:length(user_acqu)-2
        exp = (textscan(user_acqu(i+2).name,'acqu_%s'));
        exps{i,1} = exp{1}{1};  %#ok<AGROW>
    end
end

% Find the values of parameters list chosed by the user
acqu = [];
param = split(h.ParametersInputList,' '); param = param (:,1);
for i = 1:size(exps,1)
    acquFile = regexp(fileread([desiredPath '\acqu_' exps{i,1}]),'\n','split')';
    for j = 1:length(param)
        whichline = find(contains(lower(acquFile),['##$' lower(param{j}) '=']),1);
        if whichline
            if ~ismember(lower(param(j)),{'o1'})
                acqu(i,j) = cell2mat(textscan(lower(acquFile{whichline}),...
                    ['##$' lower(param{j}) '=%f']));  %#ok<AGROW>
            else
                O1_Hz = cell2mat(textscan(acquFile{whichline},'##$O1= %f'));
                whichline1 = find(contains(acquFile,'##$SFO1='),1);
                SFO1_MHz = cell2mat(textscan(acquFile{whichline1},'##$SFO1= %f'));
                acqu(i,j) = O1_Hz/SFO1_MHz; %#ok<AGROW> %ppm
            end
        else
            whichline = find(contains(lower(acquFile),['##$' lower(param{j}(1:end-1)) '=']),1);
            if whichline
                l0 = 1;
                l = str2num(acquFile{whichline+l0}); %#ok<ST2NM>
                list = l;
                while ~isempty(l)
                    l0 = l0+1;
                    l = str2num(acquFile{whichline+l0}); %#ok<ST2NM>
                    list = [list l]; %#ok<AGROW>
                end
                eval(['acqu(i,j) = list(' param{j}(end) '+1);'])
            else
                whichline = find(contains(lower(acquFile),['##$' lower(param{j}(1:end-2)) '=']),1);
                if whichline
                    l0 = 1;
                    l = str2num(acquFile{whichline+l0}); %#ok<ST2NM>
                    list = l;
                    while ~isempty(l)
                        l0 = l0+1;
                        l = str2num(acquFile{whichline+l0}); %#ok<ST2NM>
                        list = [list l]; %#ok<AGROW>
                    end
                    eval(['acqu(i,j) = list(' param{j}(end-1:end) '+1);'])
                else
                    fprintf(['\nParameter ' param{j} ' not found!\n'])
                end
            end
        end
    end
end

h.Fixed_Parameter = h.ParametersInputList;
h.Fixed_Parameter(:,2) = cell(size(h.Fixed_Parameter));
default = h.Fixed_Parameter;
for i =1:length(exps)
    default(:,1+i) = num2cell(acqu(i,:)');
end
default_param_text = cell(length(exps),size(acqu,2));
for i = 1:length(exps)
    for j = 1:size(acqu,2)
        default_param_text(i,j) = {[default{j,1} ' = ' num2str(default{j,1+i})]};
    end
end
%% Refresh Status dialog print

if dontAsk==1
elseif Tr && Trr
    fprintf('\nThe list of IconNMR users and their corresponding configuration are ready to be used.\n\n')
else
    fprintf('\nUser and/or solvent list is/are missing! No experiment can be launched.')
    return
end
%% Gather lists into interface parameters

% load User list and assign it to the list of option
user_config = dir([pathname '\user_config']);
[~,a] = ismember({'IconNMR_Config.mat','.','..','Solvent.mat','List.mat'},{user_config.name});
b = find(~ismember(1:length(user_config),a));
for i = 1:length(user_config)-length(find(a))
    h.ParametersMulti(1+i,1) = {user_config(b(i)).name}; % User
end
h.ParametersMulti(find(strcmp(h.ParametersMulti(:,1),'sophie')),1)={[]};
h.ParametersMulti(9,1) = {'sophie'};

% load Solvent list and assign it to the list of option
load([pathname '\user_config\Solvent.mat'],'Solvent')
h.ParametersMulti(2:length(Solvent)+1,3) = Solvent; % Solvent

% load Experiment list and assign it to the list of option
load([pathname '\user_config\IconNMR_Config.mat'],'IconNMR_Config')
h.IconNMR_Config = IconNMR_Config;
emptyCells = cellfun(@isempty,h.ParametersMulti(:,1));
[~,a] = ismember({h.IconNMR_Config.User},h.ParametersMulti(~emptyCells,1));
b = find(a);
for i = 1:length(b)
    %     h.IconNMR_Config(i).User
    ind = find(~emptyCells,a(b(i)));
    %     h.ParametersMulti(ind(end),1)
    if ~isempty(h.IconNMR_Config(i).InterfacePackage)
        h.ParametersMulti{ind(end),2} = h.IconNMR_Config(i).InterfacePackage; % Experiment for each user
    else
        h.ParametersMulti{ind(end),1} = [];
    end
end

% Remove Users with no experiment in their list
newC = h.ParametersMulti(:,1:2);
newC = newC(~cellfun(@isempty, newC));
h.ParametersMulti(:,1:2) = {[]};
h.ParametersMulti(1:length(newC)/2,1:2) = reshape(newC,[length(newC)/2 2]);

% Dialog print
fprintf('The parameters lists have been gathered.\n')
%% Create The Interface Figure

if(h.screen==1)
    h.f(1) = figure('units','normalized','position',[0.0104 0.0565 0.9891 0.8324],...
        'Name','Automation Control','Visible','off'); % 1 screen
else
    h.f(1) = figure('units','normalized','position',[-1 0.3556 0.6667 0.5583],...
        'Name','Automation Control','Visible','off'); % 2 screens
end
% set(h.f(1),'CloseRequestFcn','closereq'); % default function
set(h.f(1),'CloseRequestFcn',@closeWarning);
h.f(1).Visible = 'on';
%% Panels

h.panel(1) = uipanel('Title','Fixed Input','FontSize',15,...
    'BackgroundColor',[0.94,0.94,0.94],'BorderWidth',2,'ShadowColor'...
    ,'white','FontName','Arial','FontWeight','Bold','Position',...
    [0.02 0.6303 0.3 0.3197]);
h.panel(2) = uipanel('Title','Experimental Input','FontSize',15,...
    'BackgroundColor',[0.94,0.94,0.94],'BorderWidth',2,'ShadowColor'...
    ,'white','FontName','Arial','FontWeight','Bold','Position',...
    [0.35 0.45 0.3 0.5]);
h.panel(2).Position = [0.35 0.62 0.3 0.33];
h.panel(3) = uipanel('Title','Parameters Input','FontSize',15,...
    'BackgroundColor',[0.94,0.94,0.94],'BorderWidth',2,'ShadowColor'...
    ,'white','FontName','Arial','FontWeight','Bold','Position',...
    [0.02 0.045 0.3 0.5403]); %0.63 => 0.3
h.panel(4) = uipanel('Title','Edit Experiments List','FontSize',15,...
    'BackgroundColor',[0.94,0.94,0.94],'BorderWidth',2,'ShadowColor'...
    ,'white','FontName','Arial','FontWeight','Bold','Position',...
    [0.35 0.045 0.3 0.36]);
h.panel(4).Position = [0.35 0.045 0.3 0.32];
h.panel(5) = uipanel('Title','Display Extset Text File','FontSize',15,...
    'BackgroundColor',[0.94,0.94,0.94],'BorderWidth',2,'ShadowColor'...
    ,'white','FontName','Arial','FontWeight','Bold','Position',...
    [0.68 0.045 0.3 0.907]);
h.panel(6) = uipanel('Title','Peak Area Indication','FontSize',15,...
    'BackgroundColor',[0.94,0.94,0.94],'BorderWidth',2,'ShadowColor'...
    ,'white','FontName','Arial','FontWeight','Bold','Position',...
    [0.35 0.41 0.3 0.165]);
%% Import Struct

% Extset text file to be generated
h.extset = '';

% ExtSet_Input is a struct containing parameters name
h.in(1) = ExtSet_Input;

h.ParametersList = properties(h.in(1));
for p = 1:length(h.ParametersList)
    eval(['h.ParametersList{p,2} = {class(h.in(1).' h.ParametersList{p} ')};'])
end
h.LogicalParameters = {};
for p = 1:length(h.ParametersList)
    c = h.ParametersList{p,2}{1}; c = c(1);
    if (c=='l')
        h.LogicalParameters{end+1,1} = char(h.ParametersList{p,1});
    end
end
%% Panel Fixed Input

% For equaly distanced boxes
W  = 0.425;
x  = [0.05,0.1+W];
y_first = 0.8436;
y_last  = 0.2;
numberOfCases = 2*length(h.RequiredParameters) - ...
    length(find(ismember(h.RequiredParameters,h.LogicalParameters)));
numberOflines = round(numberOfCases/2);
L = 0.1095;
dy = ((y_first-y_last)-(numberOflines-1)*L)/(numberOflines-1);

h.checkList = {'Property','Static Text','Editable Text','Popup Menu',...
    'Check Box'};

p = 1;
for i = 1:length(h.ParametersList)
    if ismember(h.ParametersList{i},h.RequiredParameters)
        if ~ismember(h.ParametersList{i},h.LogicalParameters)
            n_checkList = size(h.checkList,1);
            if mod(p,2)
                % Static text fields
                h.static_text_field(i,1) = uicontrol('style','text','units','normalized',...
                    'string',h.ParametersList{i},'FontName','Arial','FontSize',14,...
                    'BackgroundColor',[0.94,0.94,0.94],'Parent',h.panel(1),...
                    'Position',[x(1) y_first-(p-1)*(dy+L) W L]);
                [~,b] = ismember(h.ParametersList{i},h.ParametersMulti(1,:));
                if ~b
                    % Editable text fields
                    h.editable_text_field(i,1)= uicontrol('style','edit','units','normalized',...
                        'string','','Parent',h.panel(1),'FontName','Arial','FontSize',12,...
                        'Position',[x(1) y_first-(p)*(dy+L) W L+0.0141],'callback',@callback1);
                    h.checkList(n_checkList+1,:) = {h.ParametersList{i},i,i,0,0};
                else
                    % String List for this Popup Menu
                    l = h.ParametersMulti(2:end,b);
                    emptyCells = cellfun(@isempty,l);
                    l(emptyCells) = [];
                    % Popup Menus
                    h.popup_menu(i,1) = uicontrol('style','popupmenu','units','normalized',...
                        'Parent',h.panel(1),'Visible','on','FontSize',11,...
                        'Position',[x(1) y_first-(p)*(dy+L) W L+0.0141],'callback',@callback1,...
                        'String',l,'FontName','Arial','HorizontalAlignment','center');
                    h.checkList(n_checkList+1,:) = {h.ParametersList{i},i,0,i,0};
                end
            else
                % Static text fields
                h.static_text_field(i,1) = uicontrol('style','text','units','normalized',...
                    'string',h.ParametersList{i},'FontName','Arial','FontSize',14,...
                    'BackgroundColor',[0.94,0.94,0.94],'Parent',h.panel(1),...
                    'Position',[x(2) y_first-(p-2)*(dy+L) W L]);
                [~,b] = ismember(h.ParametersList{i},h.ParametersMulti(1,:));
                if ~b
                    % Editable text fields
                    h.editable_text_field(i,1)= uicontrol('style','edit','units','normalized',...
                        'string','','Parent',h.panel(1),'FontName','Arial','FontSize',12,...
                        'Position',[x(2) y_first-(p-1)*(dy+L) W L+0.0141],'callback',@callback1);
                    h.checkList(n_checkList+1,:) = {h.ParametersList{i},i,i,0,0};
                else
                    % String List for this Popup Menu
                    l = h.ParametersMulti(2:end,b);
                    emptyCells = cellfun(@isempty,l);
                    l(emptyCells) = [];
                    % Popup Menus
                    h.popup_menu(i,1) = uicontrol('style','popupmenu','units','normalized',...
                        'Parent',h.panel(1),'Visible','on','FontSize',11,...
                        'Position',[x(2) y_first-(p-1)*(dy+L) W L+0.0141],'callback',@callback1,...
                        'String',l,'FontName','Arial','HorizontalAlignment','center');
                    h.checkList(n_checkList+1,:) = {h.ParametersList{i},i,0,i,0};
                end
            end
            p  = p+1;
        end
    end
end
i = 1;
if ~(mod(p,2))
    for j = 1:length(h.ParametersList)
        if ismember(h.ParametersList{j},h.RequiredParameters)
            if ismember(h.ParametersList{j},h.LogicalParameters)
                n_checkList = size(h.checkList,1);
                if ismember(lower(h.ParametersList{j}),{'delete'})
                    FontColor = [1,0,0];
                else
                    FontColor = [0,0.45,0.74];
                end
                if ~(i>=3)
                    % Check boxes
                    h.check_box(j,1) = uicontrol('style','checkbox','units',...
                        'normalized','string',h.ParametersList{j},'Parent',...
                        h.panel(1),'FontName','Arial','FontSize',14,'Position',...
                        [x(2) y_first-((p-2)+i-1)*(dy+L) W L],...
                        'ForegroundColor',FontColor,'callback',@callback1);
                    h.checkList(n_checkList+1,:) = {h.ParametersList{j},0,0,0,j};
                    i = i+1;
                else
                    if (mod(i,2))
                        % Check boxes
                        h.check_box(j,1) = uicontrol('style','checkbox','units',...
                            'normalized','string',h.ParametersList{j},'Parent',...
                            h.panel(1),'FontName','Arial','FontSize',14,'Position',...
                            [x(1) y_first-(p)*(dy+L) W L],...
                            'ForegroundColor',FontColor,'callback',@callback1);
                        h.checkList(n_checkList+1,:) = {h.ParametersList{j},0,0,0,j};
                        i = i+1;
                    else
                        % Check boxes
                        h.check_box(j,1) = uicontrol('style','checkbox','units',...
                            'normalized','string',h.ParametersList{j},'Parent',...
                            h.panel(1),'FontName','Arial','FontSize',14,'Position',...
                            [x(2) y_first-(p)*(dy+L) W L],...
                            'ForegroundColor',FontColor,'callback',@callback1);
                        h.checkList(n_checkList+1,:) = {h.ParametersList{j},0,0,0,j};
                        p = p+1;
                        i = i+1;
                    end
                end
            end
        end
    end
else
    for j = 1:length(h.ParametersList)
        if ismember(h.ParametersList{j},h.RequiredParameters)
            if ismember(h.ParametersList{j},h.LogicalParameters)
                n_checkList = size(h.checkList,1);
                FontColor = [0.00,0.45,0.74];
                if (mod(i,2))
                    % Check boxes
                    h.check_box(j,1) = uicontrol('style','checkbox','units',...
                        'normalized','string',h.ParametersList{j},'Parent',...
                        h.panel(1),'FontName','Arial','FontSize',14,'Position',...
                        [x(1) y_first-(p-1)*(dy+L) W L],...
                        'ForegroundColor',FontColor,'callback',@callback1);
                    h.checkList(n_checkList+1,:) = {h.ParametersList{j},0,0,0,j};
                    i = i+1;
                else
                    % Check boxes
                    h.check_box(j,1) = uicontrol('style','checkbox','units',...
                        'normalized','string',h.ParametersList{j},'Parent',...
                        h.panel(1),'FontName','Arial','FontSize',14,'Position',...
                        [x(2) y_first-(p-1)*(dy+L) W L],...
                        'ForegroundColor',FontColor,'callback',@callback1);
                    h.checkList(n_checkList+1,:) = {h.ParametersList{j},0,0,0,j};
                    p = p+1;
                    i = i+1;
                end
            end
        end
    end
end
%% Panel Experimental Input
% For equaly distanced boxes
W  = 0.425;
x  = [0.05,0.1+W];
y_first = 0.9;
y_last  = 0.1;
numberOfCases = 2*length(h.ExperimentalInput) - ...
    length(find(ismember(h.ExperimentalInput,h.LogicalParameters)));
numberOflines = round(numberOfCases/2);
L = 0.12;%L = 0.07;
dy = ((y_first-y_last)-(numberOflines-1)*L)/(numberOflines-1);

p = 1;
for i = 1:length(h.ParametersList)
    if ~ismember(h.ParametersList{i},h.RequiredParameters) && ...
            ~ismember(h.ParametersList{i},{'Parameters'}) && ...
            ~ismember(h.ParametersList{i},h.LogicalParameters)
        n_checkList = size(h.checkList,1);
        if ismember(h.ParametersList{i},{'Name'})
            str = char(datetime('now','Format','yyMMdd'));
        elseif ismember(h.ParametersList{i},{'ShimProgram'})
            str = 'TOPSPIN lockoff 1h o1p=3.36 selwid=0.5 convcomp';
        else
            str = '';
        end
        if mod(p,2)
            % Static text fields
            h.static_text_field(i,1) = uicontrol('style','text','units','normalized',...
                'string',h.ParametersList{i},'FontName','Arial','FontSize',14,...
                'BackgroundColor',[0.94,0.94,0.94],'Parent',h.panel(2),...
                'Position',[x(1) y_first-(p-1)*(dy+L) W L]);
            [~,b] = ismember(h.ParametersList{i},h.ParametersMulti(1,:));
            if ~b
                if ~ismember(lower(h.ParametersList{i}),{'expno'})
                    % Editable text fields
                    h.editable_text_field(i,1)= uicontrol('style','edit','units','normalized',...
                        'string',str,'Parent',h.panel(2),'FontName','Arial','FontSize',12,...
                        'Position',[x(1) y_first-(p)*(dy+L) W L+0.022],'callback',@callback1);
                    h.checkList(n_checkList+1,:) = {h.ParametersList{i},i,i,0,0};
                else
                    % Editable text fields
                    h.editable_text_field(i,1)= uicontrol('style','edit','units','normalized',...
                        'string',str,'Parent',h.panel(2),'FontName','Arial','FontSize',12,...
                        'Position',[x(1) y_first-(p)*(dy+L) W L+0.022],'callback',@callback2);
                    h.checkList(n_checkList+1,:) = {h.ParametersList{i},i,i,0,0};
                end
            else
                % String List for this Popup Menu
                l = h.ParametersMulti(2:end,b);
                emptyCells = cellfun(@isempty,l);
                l(emptyCells) = [];
                % Popup Menus
                h.popup_menu(i,1) = uicontrol('style','popupmenu','units','normalized',...
                    'Parent',h.panel(2),'Visible','on','FontSize',11,...
                    'Position',[x(1) y_first-(p)*(dy+L) W L+0.022],'callback',@callback1,...
                    'String',l,'FontName','Arial','HorizontalAlignment','center');
                h.checkList(n_checkList+1,:) = {h.ParametersList{i},i,0,i,0};
            end
            
        else
            % Static text fields
            h.static_text_field(i,1) = uicontrol('style','text','units','normalized',...
                'string',h.ParametersList{i},'FontName','Arial','FontSize',14,...
                'BackgroundColor',[0.94,0.94,0.94],'Parent',h.panel(2),...
                'Position',[x(2) y_first-(p-2)*(dy+L) W L]);
            [~,b] = ismember(h.ParametersList{i},h.ParametersMulti(1,:));
            if ~b
                if ~ismember(lower(h.ParametersList{i}),{'expno'})
                    % Editable text fields
                    h.editable_text_field(i,1)= uicontrol('style','edit','units','normalized',...
                        'string',str,'Parent',h.panel(2),'FontName','Arial','FontSize',12,...
                        'Position',[x(2) y_first-(p-1)*(dy+L) W L+0.022],'callback',@callback1);
                    h.checkList(n_checkList+1,:) = {h.ParametersList{i},i,i,0,0};
                else
                    % Editable text fields
                    h.editable_text_field(i,1)= uicontrol('style','edit','units','normalized',...
                        'string',str,'Parent',h.panel(2),'FontName','Arial','FontSize',12,...
                        'Position',[x(2) y_first-(p-1)*(dy+L) W L+0.022],'callback',@callback2);
                    h.checkList(n_checkList+1,:) = {h.ParametersList{i},i,i,0,0};
                end
            else
                % String List for this Popup Menu
                [~,a] = ismember({'User'},h.checkList(:,1));
                u = h.popup_menu(h.checkList{a,4}).String(h.popup_menu(h.checkList{a,4}).Value);
                [~,a] = ismember(u,h.ParametersMulti(~cellfun(@isempty,h.ParametersMulti(:,1)),1));
                l = h.ParametersMulti{a,2};
                % Popup Menus
                h.popup_menu(i,1) = uicontrol('style','popupmenu','units','normalized',...
                    'Parent',h.panel(2),'Visible','on','FontSize',11,...
                    'Position',[x(2) y_first-(p-1)*(dy+L) W L+0.022],'callback',@callback1,...
                    'String',l,'FontName','Arial','HorizontalAlignment','center');
                h.checkList(n_checkList+1,:) = {h.ParametersList{i},i,0,i,0};
            end
        end
        p  = p+1;
    end
end

if ~(mod(p,2))
    p = p + 1;
end
i = 1;
for j = 1:length(h.ParametersList)
    if ismember(h.ParametersList{j},h.ExperimentalInput) && ...
            ismember(h.ParametersList{j},h.LogicalParameters)
        n_checkList = size(h.checkList,1);
        FontColor = [0,0,0];
        if (mod(i,2))
            % Check boxes
            h.check_box(j,1) = uicontrol('style','checkbox','units',...
                'normalized','string',h.ParametersList{j},'Parent',...
                h.panel(2),'FontName','Arial','FontSize',14,'Position',...
                [x(1) y_first-(p-1)*(dy+L) W L],...
                'ForegroundColor',FontColor);
            h.checkList(n_checkList+1,:) = {h.ParametersList{j},0,0,0,j};
            i = i+1;
        else
            % Check boxes
            h.check_box(j,1) = uicontrol('style','checkbox','units',...
                'normalized','string',h.ParametersList{j},'Parent',...
                h.panel(2),'FontName','Arial','FontSize',14,'Position',...
                [x(2) y_first-(p-1)*(dy+L) W L],...
                'ForegroundColor',FontColor);
            h.checkList(n_checkList+1,:) = {h.ParametersList{j},0,0,0,j};
            p = p+1;
            i = i+1;
        end
        if ismember(lower(h.ParametersList{j}),{'starttime'})
            % Check boxes
            h.check_box(j,1).Callback = @callback4;
            % Push Buttons
            h.calendar.push_button(1) = uicontrol('style','pushbutton','units','normalized',...
                'BackgroundColor',[0.82,0.82,0.82],'string','Change','FontName','Arial'...
                ,'Parent',h.panel(2),'callback',@callback5,'Visible','on','Position'...
                ,[x(2) y_first-(p-1)*(dy+L) W/2 L+0.02],'Value',0,'FontSize',14,'FontWeight','normal',...
                'Visible','off');
            h.calendar.push_button(2) = uicontrol('style','pushbutton','units','normalized',...
                'BackgroundColor',[0.82,0.82,0.82],'string','Set','FontName','Arial'...
                ,'Parent',h.panel(2),'callback',@callback6,'Visible','on','Position'...
                ,[x(2)+W/2 y_first-(p-1)*(dy+L) W/2 L+0.02],'Value',0,'FontSize',14,'FontWeight','normal',...
                'Visible','off');
            
            % Calendar
            %%% Time
            if(h.screen==1)
                hh.calendar.f(2) = figure('Name','Time Picker','Units',...
                    'normalized','Position',[0.6536 0.6167 0.1917 0.1139],...
                    'Visible','off','CloseRequestFcn',[]);
            else
                hh.calendar.f(2) = figure('Name','Time Picker','Position',[-1084 478 279 94.4],...
                    'Visible','off','CloseRequestFcn',[]);
            end
            
            % Static text fields
            h.calendar.static_text_field(2) = uicontrol('style','text','units','normalized',...
                'string',' Hr','FontName','Arial','FontSize',12,...
                'BackgroundColor',[0.94,0.94,0.94],'Parent',hh.calendar.f(2),'ForegroundColor',[0,0,0],...
                'Position',[0.04 0.5 0.2 0.2],'HorizontalAlignment','left');
            h.calendar.static_text_field(3) = uicontrol('style','text','units','normalized',...
                'string','Min','FontName','Arial','FontSize',12,...
                'BackgroundColor',[0.94,0.94,0.94],'Parent',hh.calendar.f(2),'ForegroundColor',[0,0,0],...
                'Position',[0.26 0.5 0.2 0.2],'HorizontalAlignment','left');
            h.calendar.static_text_field(4) = uicontrol('style','text','units','normalized',...
                'string','Sec','FontName','Arial','FontSize',12,...
                'BackgroundColor',[0.94,0.94,0.94],'Parent',hh.calendar.f(2),'ForegroundColor',[0,0,0],...
                'Position',[0.48 0.5 0.2 0.2],'HorizontalAlignment','left');
            
            %%% Time
            str = char(datetime('now','Format','HHmmss'));
            hours_list = num2str((0:23)'); hours_list(hours_list==' ')='0';
            min_list = num2str((0:59)'); min_list(min_list==' ')='0';
            sec_list = num2str((0:59)'); sec_list(sec_list==' ')='0';
            
            % Editable text fields
            h.calendar.t(1) = uicontrol('style','popupmenu','units','normalized',...
                'Parent',hh.calendar.f(2),'Visible','on','FontSize',12,...
                'Position',[0.04 0.4 0.2 0.1],'String',hours_list,...
                'FontName','Arial','HorizontalAlignment','center',...
                'Value',str2double(str(1:2))+1);
            h.calendar.t(2) = uicontrol('style','popupmenu','units','normalized',...
                'Parent',hh.calendar.f(2),'Visible','on','FontSize',12,...
                'Position',[0.26 0.4 0.2 0.1],'String',min_list,...
                'FontName','Arial','HorizontalAlignment','center',...
                'Value',str2double(str(3:4))+1);
            h.calendar.t(3) = uicontrol('style','popupmenu','units','normalized',...
                'Parent',hh.calendar.f(2),'Visible','on','FontSize',12,...
                'Position',[0.48 0.4 0.2 0.1],'String',sec_list,...
                'FontName','Arial','HorizontalAlignment','center',...
                'Value',str2double(str(5:6))+1);
            %%% Date
            if(h.screen==1)
                hh.calendar.f(1) = uifigure('Name','Date Picker','Position',[837 157 317 251],...
                    'Visible','off','WindowStyle','alwaysontop','HandleVisibility', 'on','CloseRequestFcn',[]);
            else
                hh.calendar.f(1) = uifigure('Name','Date Picker','Position',[-1084 203 314 236],...
                    'Visible','off','WindowStyle','alwaysontop','HandleVisibility', 'on','CloseRequestFcn',[]);
            end
            h.calendar.d(1) = uidatepicker(hh.calendar.f(1),'Position',[150 210 150 22],...
                'Limits',[datetime('now'),datetime(2024,1,1)],'Value',datetime('now'));
            
            %%% Time & Date
            ttime = num2str([h.calendar.t(1).String(h.calendar.t(1).Value,1:2),...
                h.calendar.t(2).String(h.calendar.t(2).Value,1:2),...
                h.calendar.t(3).String(h.calendar.t(3).Value,1:2)]);
            dday = char(h.calendar.d(1).Value);
            day_time = datetime([dday,' ',ttime],'Format','dd-MMM-yyyy HHmmss');
            day_time.Format = 'dd-MMM-yyyy HH:mm:ss';
            
            % Static text fields
            if (mod(i,2))
                h.calendar.static_text_field(1) = uicontrol('style','text','units','normalized',...
                    'string',char(day_time),'FontName','Arial','FontSize',13,...
                    'BackgroundColor',[0.94,0.94,0.94],'Parent',h.panel(2),'ForegroundColor',[0.00,0.45,0.74],...
                    'Position',[x(1) y_first-(p-1)*(dy+L) W+0.0143 L],'Visible','off','HorizontalAlignment','left');
            else
                h.calendar.static_text_field(1) = uicontrol('style','text','units','normalized',...
                    'string',char(day_time),'FontName','Arial','FontSize',13,...
                    'BackgroundColor',[0.94,0.94,0.94],'Parent',h.panel(2),'ForegroundColor',[0.00,0.45,0.74],...
                    'Position',[x(1) y_first-(p)*(dy+L) W+0.0143 L],'Visible','off','HorizontalAlignment','left');
            end
            
            % Check boxes
            %             h.calendar.check_box(1) = uicontrol('style','checkbox','units','normalized',...
            %                 'string',char(day_time),'FontName','Arial','FontSize',13,...
            %                 'BackgroundColor',[0.94,0.94,0.94],'Parent',h.panel(2),'ForegroundColor',[0.00,0.45,0.74],...
            %                 'Position',[x(2) y_first-(p)*(dy+L) W+0.0143 L],'Visible','off','HorizontalAlignment','left');
            %             % Check boxes
            %             h.check_box(j,1) = uicontrol('style','checkbox','units',...
            %                 'normalized','string',h.ParametersList{j},'Parent',...
            %                 h.panel(2),'FontName','Arial','FontSize',14,'Position',...
            %                 [x(2) y_first-(p-1)*(dy+L) W L],...
            %                 'ForegroundColor',FontColor);
            h.checkList(n_checkList+1,:) = {h.ParametersList{j},0,0,0,j};
            
            p = p+1;
            i = i+4;
        end
    end
end
%% Panel Parameters Input (Optional)

% Push Buttons
h.push_button(1) = uicontrol('style','pushbutton','units','normalized',...
    'BackgroundColor',[0.82,0.82,0.82],'string','Insert','FontName','Arial'...
    ,'Parent',h.panel(3),'callback',@callback7,'Visible','on','Position'...
    ,[0.68 0.75 0.28 0.1],'Value',0,'FontSize',14,'FontWeight','normal');
%     'KeyPressFcn',@keyPress);
h.push_button(2) = uicontrol('style','pushbutton','units','normalized',...
    'BackgroundColor',[0.82,0.82,0.82],'string','Remove','FontName','Arial'...
    ,'Parent',h.panel(3),'callback',@callback8,'Visible','on','Position'...
    ,[0.6 0.05 0.28 0.1],'Value',0,'FontSize',14,'FontWeight','normal');

% Check Box
h.check_box(end+1,1) = uicontrol('style','checkbox','units',...
    'normalized','string','Default','Parent',...
    h.panel(3),'FontName','Arial','FontSize',12,'Position',...
    [0.68 0.89 0.28 0.1],'ForegroundColor',FontColor,'callback',@callback1);

% Static text fields
h.static_text_field(end+1,1) = uicontrol('style','text','units','normalized',...% n�10
    'string','Parameter','FontName','Arial','FontSize',14,...
    'BackgroundColor',[0.94,0.94,0.94],'Parent',h.panel(3),...
    'Position',[0.04 0.87 0.28 0.075]);
h.static_text_field(end+1,1) = uicontrol('style','text','units','normalized',...% n�11
    'string','Value','FontName','Arial','FontSize',14,...
    'BackgroundColor',[0.94,0.94,0.94],'Parent',h.panel(3),...
    'Position',[0.36 0.87 0.28 0.075]);

% Popup Menu
h.popup_menu(end+1,1) = uicontrol('style','popupmenu','units','normalized',...%n�10
    'Parent',h.panel(3),'Visible','on','FontSize',12,...
    'Position',[0.04 0.75 0.28 0.095],'String',h.ParametersInputList,...
    'FontName','Arial','HorizontalAlignment','center');

% Editable text field
h.editable_text_field(end+1,1)= uicontrol('style','edit','units','normalized',...n�6
    'string','','Parent',h.panel(3),'FontName','Arial','FontSize',12,...
    'Position',[0.36 0.75 0.28 0.095],'Callback',@anyKeyPress);
h.key = 1;

% List Box
h.list_box(1) = uicontrol('style','listbox','units','normalized',...
    'Parent',h.panel(3),'Visible','on','FontSize',11,...
    'Position',[0.52 0.19 0.44 0.5],'String','',...
    'FontName','Arial');

% Default Parameter static text
h.static_text_field(end+1,1) = uicontrol('style','text','units','normalized',...% n�10
    'string','DEFAULT','FontName','Arial','FontSize',11,...
    'BackgroundColor',[0.94,0.94,0.94],'Parent',h.panel(3),...
    'Position',[0.04 0.05 0.44 0.64],'HorizontalAlignment','left',...
    'ForegroundColor',[0 0 0]);
%% Panel Edit Input

% Push Buttons
h.push_button(3) = uicontrol('style','pushbutton','units','normalized',...
    'BackgroundColor',[0.94,0.94,0.94],'ForegroundColor',[0.05,0.65,0.12],...
    'string','Add','callback',@callback9,'Visible','on','Value',0,...
    'FontSize',14,'FontName','Arial','FontWeight','normal','Position',...
    [0.04 0.67 0.25 0.2],'Parent',h.panel(4));
h.push_button(4) = uicontrol('style','pushbutton','units','normalized',...
    'BackgroundColor',[0.94,0.94,0.94],'ForegroundColor',[0.78,0.22,0.32],...
    'string','Delete','callback',@callback10,'Visible','on','Value',0,...
    'FontSize',14,'FontName','Arial','FontWeight','normal','Position',...
    [0.04 0.42 0.25 0.2],'Parent',h.panel(4));
h.push_button(5) = uicontrol('style','pushbutton','units','normalized',...
    'BackgroundColor',[0.94,0.94,0.94],'ForegroundColor',[0,0,0],...
    'string','Duplicate','callback',@callback11,'Visible','on','Value',0,...
    'FontSize',14,'FontName','Arial','FontWeight','normal','Position',...
    [0.04 0.17 0.25 0.2],'Parent',h.panel(4));
% selections = [char(8592), char(8593), char(8594), char(8595),...
% char(8598), char(8599), char(8600), char(8601)]; % arrow characters
h.push_button(6) = uicontrol('style','pushbutton','units','normalized',...
    'BackgroundColor',[0.94,0.94,0.94],'ForegroundColor',[0,0,0],...
    'string',char(8593),'callback',@callback12,'Visible','on','Value',0,...
    'FontSize',25,'FontName','Arial','FontWeight','bold','Position',...
    [0.868 0.53 0.1 0.15],'Parent',h.panel(4));
h.push_button(7) = uicontrol('style','pushbutton','units','normalized',...
    'BackgroundColor',[0.94,0.94,0.94],'ForegroundColor',[0,0,0],...
    'string',char(8595),'callback',@callback13,'Visible','on','Value',0,...
    'FontSize',18,'FontName','Arial','FontWeight','bold','Position',...
    [0.868 0.36 0.1 0.15],'Parent',h.panel(4));

% Toggle Buttons
h.toggle_button(1) = uicontrol('style','togglebutton','units','normalized',...
    'BackgroundColor',[1,1,1],'ForegroundColor',[1,0.07,0.65],...
    'string',char(8596),'callback',@callback15,'Visible','on','Value',0,...
    'FontSize',18,'FontName','Arial','FontWeight','bold','Position',...
    [0.868 0.7 0.1 0.15],'Parent',h.panel(4),'Value',0);
h.modification = 0;

% List Box
h.list_box(2) = uicontrol('style','listbox','units','normalized',...
    'Parent',h.panel(4),'Visible','on','FontSize',11,'callback',@callback14,...
    'Position',[0.31 0.17 0.54 0.7],'FontName','Arial');

% Static text fields
h.static_text_field(end+1,1) = uicontrol('style','text','units','normalized',...
    'String','Index\ExpNo\Solvent\Experiment\Parameters','FontName','Arial','FontSize',...
    11,'BackgroundColor',[0.94,0.94,0.94],'Parent',h.panel(4),...
    'Position',[0.19 0.88 0.77 0.1],'HorizontalAlignment','left');
% h.static_text_field(end+1,1) = uicontrol('style','text','units','normalized',...
%     'string','Current : ','FontName','Arial','FontSize',12,...
%     'BackgroundColor',[0.94,0.94,0.94],'Parent',h.panel(4),...
%     'Position',[0.04 0.044 0.3 0.1]);
% h.static_text_field(end+1,1) = uicontrol('style','text','units','normalized',...
%     'String','','FontName','Arial','FontSize',12,...
%     'BackgroundColor',[0.94,0.94,0.94],'Parent',h.panel(4),...
%     'Position',[0.31 0.044 0.54 0.1],'HorizontalAlignment','left',...
%     'ForegroundColor',[0.50,0.50,0.50]);
%% Panel Display Extset Text File

% List Boxes
h.list_box(3) = uicontrol('style','listbox','units','normalized',...
    'Parent',h.panel(5),'Visible','on','FontSize',11,...
    'Position',[0.04 0.4 0.92 0.59],'FontName','Arial');
h.QExpList = {'Launched Experiments : ','Experiments in Queue : '};
h.list_box(4) = uicontrol('style','listbox','units','normalized',...
    'Parent',h.panel(5),'Visible','on','FontSize',11,'Enable','on',...
    'Position',[0.04 0.157 0.92 0.1],'FontName','Arial','String',h.QExpList);

% Push Buttons
h.push_button(8) = uicontrol('style','pushbutton','units','normalized',...
    'BackgroundColor',[0.3,0.75,0.93],'ForegroundColor',[1,1,1],...
    'string','GO','callback',@callback16,'Visible','on','Value',0,...
    'FontSize',20,'FontName','Arial','FontWeight','bold','Position',...
    [0.04 0.02 0.3 0.1],'Parent',h.panel(5));
% push_button(9,10,13) are disabled because START_RUN and STOP_RUN command
% are not available anymore. The button START and STOP are used instead
% h.push_button(9) = uicontrol('style','pushbutton','units','normalized',...%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     'BackgroundColor',[0.00,0.45,0.74],'ForegroundColor',[1,1,1],...
%     'string',char(8593),'callback',@callback19,'Visible','on','Value',0,...
%     'FontSize',25,'FontName','Arial','FontWeight','bold','Position',...
%     [0.868 0.53 0.1 0.1],'Parent',h.panel(5));
% h.push_button(10) = uicontrol('style','pushbutton','units','normalized',...%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     'BackgroundColor',[0.00,0.45,0.74],'ForegroundColor',[1,1,1],...
%     'string',char(8595),'callback',@callback20,'Visible','on','Value',0,...
%     'FontSize',18,'FontName','Arial','FontWeight','bold','Position',...
%     [0.868 0.41 0.1 0.1],'Parent',h.panel(5));
h.push_button(11) = uicontrol('style','pushbutton','units','normalized',...
    'BackgroundColor',[1,0.41,0.16],'ForegroundColor',[1,1,1],...
    'string','STOP','callback',@callback17,'Visible','on','Value',0,...
    'FontSize',20,'FontName','Arial','FontWeight','bold','Position',...
    [0.66 0.02 0.3 0.1],'Parent',h.panel(5));
h.push_button(12) = uicontrol('style','pushbutton','units','normalized',...
    'BackgroundColor',[0.47,0.8,0.04],'ForegroundColor',[1,1,1],...
    'string','START','callback',@callback18,'Visible','on','Value',0,...
    'FontSize',20,'FontName','Arial','FontWeight','bold','Position',...
    [0.35 0.02 0.3 0.1],'Parent',h.panel(5));
% h.push_button(13) = uicontrol('style','pushbutton','units','normalized',...%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     'BackgroundColor',[0.00,0.45,0.74],'ForegroundColor',[0.64,0.08,0.18],...
%     'string','X','callback',@callback21,'Visible','on','Value',0,...
%     'FontSize',20,'FontName','Arial','FontWeight','bold','Position',...
%     [0.868 0.65 0.1 0.1],'Parent',h.panel(5));
h.push_button(14) = uicontrol('style','pushbutton','units','normalized',...
    'BackgroundColor',[0.00,0.45,0.74],'ForegroundColor',[1 1 1],...
    'string','Save this list for auto-mode','callback',@saveH,'Visible','on','Value',0,...
    'FontSize',12,'FontName','Arial','FontWeight','bold','Position',...
    [0.04 0.28 0.92 0.1],'Parent',h.panel(5));

% Dialog print
fprintf('The user interface has been created.\n')
%% Panel Peak Area Indication

% For equaly distanced boxes
W  = 0.425;
x  = [0.05,0.1+W];
y_first = 0.6;
y_last  = 0.2;
numberOfCases = 2*length(h.AreaParameters);
numberOflines = round(numberOfCases/2);
L = 0.3;
dy = ((y_first-y_last)-(numberOflines-1)*L)/(numberOflines-1);

p = 1;
for i = 1:length(h.ParametersList)
    if ismember(h.ParametersList{i},h.AreaParameters)
%         return
        if mod(p,2)
            if ismember(lower(h.ParametersList{i}),{'referencepeak'})
                % Static text fields
                h.static_text_field(i,1) = uicontrol('style','text','units','normalized',...
                    'string','Reference Peak','FontName','Arial','FontSize',14,...
                    'BackgroundColor',[0.94,0.94,0.94],'Parent',h.panel(6),...
                    'Position',[x(1) y_first-(p-1)*(dy+L) W L],'HorizontalAlignment','left');
                % Static text fields
                h.area.static_text_field(2) = uicontrol('style','text',...
                    'units','normalized','String',...
                    '[              ,              ]ppm','FontName',...
                    'Arial','FontSize',10,'BackgroundColor',...
                    [0.94,0.94,0.94],'Parent',h.panel(6),'Position',...
                    [x(1) y_first-(p)*(dy+L) W L+0.0141],'Visible','on');
                % Editable text fields
                h.area.editable_text_field(3,1)= uicontrol('style','edit','units','normalized',...
                    'String','','Parent',h.panel(6),'FontName','Arial','FontSize',10,...
                    'Position',[x(1)+0.025 y_first-(p)*(dy+L)+0.055 W/3 L+0.0141],...
                    'Visible','on','Callback',@AreaRegionInsert2,'Enable','off');
                h.area.editable_text_field(4,1)= uicontrol('style','edit','units','normalized',...
                    'String','','Parent',h.panel(6),'FontName','Arial','FontSize',10,...
                    'Position',[x(1)+0.19 y_first-(p)*(dy+L)+0.055 W/3 L+0.0141],...
                    'Visible','on','Callback',@AreaRegionInsert2,'Enable','off');
            elseif ismember(lower(h.ParametersList{i}),{'areacalculation'})
                % Static text fields
                h.static_text_field(i,1) = uicontrol('style','text','units','normalized',...
                    'string','Target Peak','FontName','Arial','FontSize',14,...
                    'BackgroundColor',[0.94,0.94,0.94],'Parent',h.panel(6),...
                    'Position',[x(1) y_first-(p-1)*(dy+L) W L],'HorizontalAlignment','left');
                % Static text fields
                h.area.static_text_field(1) = uicontrol('style','text',...
                    'units','normalized','String',...
                    '[              ,              ]ppm','FontName',...
                    'Arial','FontSize',10,'BackgroundColor',...
                    [0.94,0.94,0.94],'Parent',h.panel(6),'Position',...
                    [x(1) y_first-(p)*(dy+L) W L+0.0141],'Visible','on');
                % Editable text fields
                h.area.editable_text_field(1,1)= uicontrol('style','edit','units','normalized',...
                    'String','','Parent',h.panel(6),'FontName','Arial','FontSize',10,...
                    'Position',[x(1)+0.025 y_first-(p)*(dy+L)+0.055 W/3 L+0.0141],...
                    'Visible','on','Callback',@AreaRegionInsert,'Enable','off');
                h.area.editable_text_field(2,1)= uicontrol('style','edit','units','normalized',...
                    'String','','Parent',h.panel(6),'FontName','Arial','FontSize',10,...
                    'Position',[x(1)+0.19 y_first-(p)*(dy+L)+0.055 W/3 L+0.0141],...
                    'Visible','on','Callback',@AreaRegionInsert,'Enable','off');
            end
        else
            if ismember(lower(h.ParametersList{i}),{'referencepeak'})
                % Static text fields
                h.static_text_field(i,1) = uicontrol('style','text','units','normalized',...
                    'string','Reference Peak','FontName','Arial','FontSize',14,...
                    'BackgroundColor',[0.94,0.94,0.94],'Parent',h.panel(6),...
                    'Position',[x(2) y_first-(p-2)*(dy+L) W L],'HorizontalAlignment','left');
                % Static text fields
                h.area.static_text_field(2) = uicontrol('style','text',...
                    'units','normalized','String',...
                    '[              ,              ]ppm','FontName',...
                    'Arial','FontSize',10,'BackgroundColor',...
                    [0.94,0.94,0.94],'Parent',h.panel(6),'Position',...
                    [x(2) y_first-(p-1)*(dy+L) W L+0.0141],'Visible','on');
                % Editable text fields
                h.area.editable_text_field(3,1)= uicontrol('style','edit','units','normalized',...
                    'String','','Parent',h.panel(6),'FontName','Arial','FontSize',10,...
                    'Position',[x(2)+0.025 y_first-(p-1)*(dy+L)+0.055 W/3 L+0.0141],...
                    'Visible','on','Callback',@AreaRegionInsert2,'Enable','off');
                h.area.editable_text_field(4,1)= uicontrol('style','edit','units','normalized',...
                    'String','','Parent',h.panel(6),'FontName','Arial','FontSize',10,...
                    'Position',[x(2)+0.19 y_first-(p-1)*(dy+L)+0.055 W/3 L+0.0141],...
                    'Visible','on','Callback',@AreaRegionInsert2,'Enable','off');
            elseif ismember(lower(h.ParametersList{i}),{'areacalculation'})
                % Static text fields
                h.static_text_field(i,1) = uicontrol('style','text','units','normalized',...
                    'string','Target Peak','FontName','Arial','FontSize',14,...
                    'BackgroundColor',[0.94,0.94,0.94],'Parent',h.panel(6),...
                    'Position',[x(2) y_first-(p-2)*(dy+L) W L],'HorizontalAlignment','left');
                % Static text fields
                h.area.static_text_field(1) = uicontrol('style','text',...
                    'units','normalized','String',...
                    '[              ,              ]ppm','FontName',...
                    'Arial','FontSize',10,'BackgroundColor',...
                    [0.94,0.94,0.94],'Parent',h.panel(6),'Position',...
                    [x(2) y_first-(p-1)*(dy+L) W L+0.0141],'Visible','on');
                % Editable text fields
                h.area.editable_text_field(1,1)= uicontrol('style','edit','units','normalized',...
                    'String','','Parent',h.panel(6),'FontName','Arial','FontSize',10,...
                    'Position',[x(2)+0.025 y_first-(p-1)*(dy+L)+0.055 W/3 L+0.0141],...
                    'Visible','on','Callback',@AreaRegionInsert,'Enable','off');
                h.area.editable_text_field(2,1)= uicontrol('style','edit','units','normalized',...
                    'String','','Parent',h.panel(6),'FontName','Arial','FontSize',10,...
                    'Position',[x(2)+0.19 y_first-(p-1)*(dy+L)+0.055 W/3 L+0.0141],...
                    'Visible','on','Callback',@AreaRegionInsert,'Enable','off');
            end
        end
        p  = p+1;
    end
end
for i = 1:2
    posi = h.area.static_text_field(i).Position;
    h.area.missing(i) = uicontrol('style','text',...
        'units','normalized','String','','FontName',...
        'Arial','FontSize',10,'BackgroundColor',...
        [1 0 0],'Parent',h.panel(6),'Position',...
        [posi(1)+posi(3) posi(2)+0.055 0.04 posi(4)],'Visible','off');
end
% Push Buttons
h.area.push_button(1) = uicontrol('style','pushbutton','units','normalized',...
    'BackgroundColor',[0.94,0.94,0.94],'ForegroundColor',[0,0,0],...
    'string','+','FontSize',20,'FontName','Arial','FontWeight','bold',...
    'Position',[0.9065 0.6238 0.0977 0.3945],'Parent',h.panel(6),...
    'Callback',@AreaRegionAddExtra,'Enable','off');
if h.userExpListSelection
    % Enabling all children for area panel
    panelChildren = h.panel(6).Children;
    for i = 1:length(panelChildren)
        if strcmp(panelChildren(i).Style,'edit')
            panelChildren(i).Enable = 'on';
        end
    end
    h.area.push_button(1).Enable = 'on';
    %h.push_button(15).Enable = 'off';
end
%% Auto Insert

% save([pathname '\ExtSet_GUI_AutoFill.mat'],'auto')
load([pathname '\ExtSet_GUI_AutoFill.mat'],'auto')
h.auto(1) = auto;
h.auto(1).Name = char(datetime('now','Format','yyMMdd'));
% Plateau
if h.userExpListSelection_plateau==1
    h.auto(1).Name = [h.auto(1).Name,'_Plateau'];
    h.auto(1).Title = 'Experiment loop to rearch a plateau';
    h.auto(1).ShimProgram = '';
end
h.in(1) = h.auto(1);
for i = 1:length(h.ParametersList)
    if ismember(h.ParametersList{i},properties(h.auto))
        [~,b]=ismember(h.ParametersList{i},h.checkList(:,1));
        if b
            check = cell2mat(h.checkList(b,2:end));
            if check(4)==0
                if check(3)==0 %it is an insert text
                    eval(['h.editable_text_field(i,1).String ='...
                        'char(string(h.auto.' h.checkList{b,1} '));'])
                else %it is a popup menu
                    popup_menu_list = h.popup_menu(i,1).String; %#ok<NASGU>
                    eval(['[~,c]=ismember(lower(popup_menu_list),lower({h.auto.'...
                        h.checkList{b,1} '}));'])
                    c = find(c,1);
                    if c
                        h.popup_menu(i,1).Value = c;
                    else
                        h.popup_menu(i,1).Value = 1;
                    end
                end
            else %it is a check box then
                eval(['h.check_box(i,1).Value = '...
                    'h.auto.' h.checkList{b,1} ';'])
            end
        end
    end
end
if ~isempty(h.auto(1).Parameters)
    param = textscan(char(h.auto(1).Parameters),...
        '%q %f','Delimiter',',');
    popup_menu_list = h.popup_menu(end,1).String;
    txt = popup_menu_list(contains(lower(popup_menu_list),...
        param{1}{1}));
    h.list_box(1).String = {[char(txt) ' = '...
        char(string(param{2}(1)))]};
    for j = 2:size(param{1},1)
        txt = popup_menu_list(contains(lower(popup_menu_list),...
            param{1}{j}));
        h.list_box(1).String(j,1) = {[char(txt) ' = '...
            char(string(param{2}(j)))]};
    end
end

% String List for the available experiment Popup Menu
[~,a] = ismember({'User'},h.checkList(:,1));
u = h.popup_menu(h.checkList{a,4}).String(h.popup_menu(h.checkList{a,4}).Value);
[~,a] = ismember(u,h.ParametersMulti(~cellfun(@isempty,h.ParametersMulti(:,1)),1));
l = h.ParametersMulti{a,2};
[~,a] = ismember({'Experiment'},h.checkList(:,1));
h.popup_menu(h.checkList{a,4}).String = l;
if h.userExpListSelection_plateau==1
    ind = find(contains(lower(l),'proton'));
    if ind
        h.popup_menu(h.checkList{a,4}).Value = ind;
    else
        ind = find(contains(lower(l),'1H'));
        if ind
            h.popup_menu(h.checkList{a,4}).Value = ind;
        else
            h.popup_menu(h.checkList{a,4}).Value = 1;
        end
    end
end

% Default values of the chosen parameters for the selected experiment
[~,a] = ismember({'Experiment'},h.checkList(:,1));
u = h.popup_menu(h.checkList{a,4}).String(h.popup_menu(h.checkList{a,4}).Value);% selected experiment
% expp = textscan(u{1},'%*s %s -%*[^-]');
expp = u{1};
% 'exps' is the list of all chosen experiment in the acqu matlab folder
[~,ind] = ismember({expp(5:end)},exps);
h.static_text_field(end-6).String = [{'DEFAULT :'} {''} default_param_text(ind,:)];

% Current Experiment Tag : Index\ExpNo\Solvent\Experiment\Parameters
% tag = fullfile('#',['Exp�',num2str(h.in(1).ExpNo)],h.in(1).Solvent,...
%     h.in(1).Experiment,h.in(1).Parameters);
% h.static_text_field(end,1).String = tag;

% Dialog print
fprintf('The automatic filling has been done.\n')
%% Experiment Save Log

% All desired experiments are collected in a table for later use
for i = 1:size(h.ParametersList,1)
    if ismember(h.ParametersList{i,2},{'char'})
        eval(['h.out.' h.ParametersList{i,1} ' = string(h.auto(1).' h.ParametersList{i,1} ');'])
    else
        eval(['h.out.' h.ParametersList{i,1} ' = h.auto(1).' h.ParametersList{i,1} ';'])
    end
end
t = char(join(string(h.ParametersList(:,1)'),' , h.out.'));
t = join({'h.out.',t},'');
h.out.ReferencePeak = 0;
eval(['h.Experiment_Table = table(' ['0 , ' t{1}] ' , "");'])
h.Experiment_Table.Properties.VariableNames =  [{'Index'} h.ParametersList(:,1)' {'Date'}];
h.Experiment_Table.Parameters(:,1) = missing;
h.Experiment_Table.ExpNo(1) = 0;
h.Auto_Experiment_Table = h.Experiment_Table;

% Dialog print
fprintf('The experiments saving log has been created.\n')
%% Some Variable Preparation

% Dialog print
fprintf('\n. . .\n')

% Check if automation is running on IconNMR
h.running = 0;
% Check if automation is running on IconNMR for the first time of the day
h.firstRun = 0;
% Check if automation is running again after being stopped
h.runStopped = 0;
% Already created experiments
h.archive = [];
% Check if Start can be pressed or should wait for an extset file to be
% transferred
h.WaitForGo = 1;
%Check if the selected experiment is actually an order to delete an
%experiment
h.delete = 0;
% Check if the windows to set or change the Date and Time of the experiment
% are visibile or not
hh.v = 0;
% Current user choice, to catch changes of user in order to change its
% available list of experiments
userchange = {h.auto.User};
% Current experiment choice, to catch changes of experiment in order to
% change the default values for its parameters
expchange = {h.auto.Experiment};

% First callback run to check some of the above status
callback1

h.area.AreaRegion = [];
h.area.AreaRegion2 = [];
h.area.regionInsert = 0;
h.area.regionInsert2 = 0;
h.area.FixIt = 0;
h.AreaRegion = [];
h.AreaRegion2 = [];
h.AreaValue = [];
h.AreaValue2 = [];
h.regionInsert = 0;
h.regionInsert2 = 0;
h.autoModeSAve = 0;
drawnow

h.f(1).Visible = 'on';
% Dialog print
fprintf('\nThe application is ready to be used.\n')
if h.userExpListSelection
    fprintf('\nOnly experiment selection is authorized.\n')
end
%% Output

if h.userExpListSelection
    waitfor(h.f(1))
    % Dialog print
    fprintf('The application is closed.\n')
end
if nargout==1
    if h.userExpListSelection
%         Area = [pathname '\autoModeHandles.mat']; % path of the saved auto handles
        Area = h.autoModeHandlesPathName; % path of the saved auto handles
    else
        Area = h.AreaResults;
    end
elseif nargout>=2
    Area = h.AreaResults;
    Region = [h.AreaRegion,h.AreaRegion2];
end
end

%% Pre-Interface Callbacks
% User choices for lists refreshing
function callback01(varargin)
global user_choice
global Dialog
global figDialog
refresh_user_list = Dialog.radio_button_1.Value;
refresh_userConfig = Dialog.radio_button_3.Value;
refresh_exp_list = Dialog.radio_button_5.Value;
refresh_solv_list = Dialog.radio_button_7.Value;
user_choice = [refresh_user_list;refresh_userConfig;refresh_exp_list;refresh_solv_list];
close(figDialog)
end
% function EnterKeyPress(hobj, EventData, handles)
function EnterKeyPress(~, EventData, ~)
% display(EventData.Key)
if strcmp(EventData.Key, 'return')
    callback01
end
end

% Add an experiment to the interface package
function callback02(varargin)
global List
ind = List.list_box_1.Value;
if ind
    if ~List.check(ind)
        List.check(ind) = 1;
        List.list_box_2.String = List.allExperiment(find(List.check));
    end
end
l = find(~List.check);
List.list_box_1.Value = l(find(l>ind,1));
end
% Remove an experiment from the interface package
function callback03(varargin)
global List
if ~isempty(List.list_box_2.String)
    ind = List.list_box_2.Value;
    if ind
        exp = List.list_box_2.String(ind);
        [~,a] = ismember(exp,List.allExperiment);
        if a
            List.check(a) = 0;
            List.list_box_2.String = List.allExperiment(find(List.check));
            if ind~=1
                List.list_box_2.Value = ind-1;
            end
        end
    end
end
end
% Empty the list of chosen experiments
function callback04(varargin)
global List
List.check = zeros(size(List.check));
List.list_box_2.String = List.allExperiment(find(List.check));
end
% Validate the list of chosen experiments
function callback05(varargin)
global List h pathname
if ~isempty(List.list_box_2.String)
    for i = 1:size(List.IconNMR_Config,2)
        [~,a] = ismember(List.allExperiment(find(List.check)),List.IconNMR_Config(i).Experiments(:,1));
        if ~isempty(find(a,1))
            List.IconNMR_Config(i).InterfacePackage = List.IconNMR_Config(i).Experiments(a(~~a),:);
        else
            List.IconNMR_Config(i).InterfacePackage = [];
        end
    end
    h.IconNMR_Config = List.IconNMR_Config;
    IconNMR_Config = List.IconNMR_Config;
    save([pathname '\user_config\IconNMR_Config.mat'],'IconNMR_Config')
    close(List.figExp)
    % clearvars List
else
    warning('Experiment list is empty. Add at least one experiment.')
end
end

%% Interface General Callback
% Parameters table auto update
function callback1(varargin)
global h hh default_param_text exps userchange
if h.userExpListSelection
    h.push_button(8).Enable = 'off';
end
if h.WaitForGo
    h.push_button(12).Enable = 'off'; %START
    h.push_button(11).Enable = 'off'; %STOP
else
    if h.running==1
        h.push_button(12).Enable = 'off'; %START
        h.push_button(11).Enable = 'on'; %STOP
    else
        h.push_button(12).Enable = 'on'; %START
        h.push_button(11).Enable = 'off'; %STOP
    end
end
if ~isempty(h.list_box(2).String)
    ind = split(h.list_box(2).String{h.list_box(2).Value},filesep);
    ind = str2double(ind{1});
    n_table = find(h.Experiment_Table.Index==ind,1);
    delete_status_before = h.Experiment_Table.Delete(n_table);
    [~,d] = ismember({'delete'},lower(h.checkList(:,1)));
    if d
        if ~h.check_box(h.checkList{d,5}).Value...
                && delete_status_before
            h = exp_nb_update(h);
        else
            if ~h.check_box(h.checkList{d,5}).Value
                [~,a] = ismember({'expno'},lower(h.checkList(:,1)));
                if a
                    h.editable_text_field(h.checkList{a,3}).String =...
                        num2str(h.Experiment_Table.ExpNo(n_table));
                end
            end
        end
        if h.check_box(h.checkList{d,5}).Value
            [~,a] = ismember({'expno'},lower(h.checkList(:,1)));
            if a
                h.editable_text_field(h.checkList{a,3}).String = '0';
            end
        end
    end
end

if ~h.modification
    h = exp_nb_update(h);
else
    [~,d] = ismember({'expno'},lower(h.checkList(:,1)));
    if d
        h.editable_text_field(h.checkList{d,3},1).Enable = 'off';
    end
end
% h = tag_update(h);
[~,a] = ismember({'User'},h.checkList(:,1));
u = h.popup_menu(h.checkList{a,4}).String(h.popup_menu(h.checkList{a,4}).Value);
if ~ismember(userchange,u)
    userchange = u;
    % String List for the available experiment Popup Menu
    [~,a] = ismember(u,h.ParametersMulti(~cellfun(@isempty,h.ParametersMulti(:,1)),1));
    l = h.ParametersMulti{a,2};
    [~,a] = ismember({'Experiment'},h.checkList(:,1));
    h.popup_menu(h.checkList{a,4}).String = l;
    h.popup_menu(h.checkList{a,4}).Value = 1;
end
% Default values of the chosen parameters for the selected experiment
[~,a] = ismember({'Experiment'},h.checkList(:,1));
e = h.popup_menu(h.checkList{a,4}).String(h.popup_menu(h.checkList{a,4}).Value);% selected experiment
% expp = textscan(e{1},'%*s %s -%*[^-]');
expp = e{1};
% 'exps' is the list of all chosen experiment in the acqu matlab folder
[~,ind] = ismember({expp(5:end)},exps);
h.static_text_field(end-6).String = [{'DEFAULT :'} {''} default_param_text(ind,:)];

% [~,d] = ismember({'experiment'},lower(h.checkList(:,1)));
% if d
%     ind = h.popup_menu(h.checkList{d,4},1).Value;
%     h.static_text_field(end-7).String = [{'DEFAULT :'} {''} default_param_text(ind-1,:)];
% end

[~,d] = ismember({'delete'},lower(h.checkList(:,1)));
if d
    if h.check_box(h.checkList{d,5},1).Value
        [h,hh] = disable_entries(h,hh,0);
        h.delete = 1;
        [~,a] = ismember({'expno'},lower(h.checkList(:,1)));
        if a
            h.editable_text_field(h.checkList{a,3}).String = '0';
        end
    else
        [h,hh] = enable_entries(h,hh);
        h.delete = 0;
        [~,d] = ismember({'expno'},lower(h.checkList(:,1)));
        if d && h.modification
            h.editable_text_field(h.checkList{d,3},1).Enable = 'off';
        end
    end
end
if h.check_box(end).Value
    h.list_box(1).String = '';
else
    l2 = h.Fixed_Parameter;
    emptyCells2 = cellfun(@isempty,h.Fixed_Parameter(:,2));
    full_p2 = find(~emptyCells2);
    text_ParametersInput2 = cell(1,length(full_p2));
    for i = 1:length(full_p2)
        text_ParametersInput2(1,i) = {[l2{full_p2(i),1},' = ',...
            num2str(l2{full_p2(i),2})]};
    end
    h.list_box(1).String = text_ParametersInput2;
    h.editable_text_field(end).String = '';
end
[~,d] = ismember({'starttime'},lower(h.checkList(:,1)));
if d
    if h.check_box(h.checkList{d,5},1).Value && ~h.delete && hh.v
        hh.calendar.f(1).Visible = 'on';
        hh.calendar.f(2).Visible = 'on';
        figure(hh.calendar.f(2))
    else
        hh.calendar.f(1).Visible = 'off';
        hh.calendar.f(2).Visible = 'off';
        hh.v = 0;
    end
end
end

%% Fixed Input Callback

%% Experiment Input Panel Callbacks
% Experiment number update
function callback2(varargin)
global h
h = exp_nb_update(h);
end
% Priority Option
function callback3(varargin)
global h
h = prioriry_update(h);
end
% Make it possible to set the date
function callback4(varargin)
global h
[~,d] = ismember({'starttime'},lower(h.checkList(:,1)));
check = cell2mat(h.checkList(d,end));
if h.check_box(check).Value
    h.calendar.push_button(1).Visible = 'on';
    h.calendar.push_button(2).Visible = 'on';
    h.calendar.static_text_field(1).Visible = 'on';
else
    h.calendar.push_button(1).Visible = 'off';
    h.calendar.push_button(2).Visible = 'off';
    h.calendar.static_text_field(1).Visible = 'off';
end
end
% Change the date and time
function callback5(varargin)
% global h
global hh
hh.calendar.f(1).Visible = 'on';
hh.calendar.f(2).Visible = 'on';
hh.v = 1;
figure(hh.calendar.f(2))
end
% Set the date and time
function callback6(varargin)
global h
global hh
hr = h.calendar.t(1).Value-1;
mins = h.calendar.t(2).Value-1;
secs = h.calendar.t(3).Value-1;
ttime = num2str([hr,mins,secs]);
dday = char(h.calendar.d(1).Value);
day_time = datetime([dday,' ',ttime],'Format','dd-MMM-yyyy HH  mm  ss');
day_time.Format = 'dd-MMM-yyyy HH:mm:ss';
now_time = datetime('now','Format','dd-MMM-yyyy HH:mm:ss');
if day_time<now_time
    h.calendar.t(1).Value = now_time.Hour+1;
    h.calendar.t(2).Value = now_time.Minute+1;
    h.calendar.t(3).Value = fix(now_time.Second)+1;
    h.calendar.static_text_field(1).String = char(now_time);
    h.calendar.static_text_field(1).ForegroundColor = [1 0 0];
    if hh.calendar.f(2).Visible
        figure(hh.calendar.f(2))
    end
else
    h.calendar.static_text_field(1).String = char(day_time);
    h.calendar.static_text_field(1).ForegroundColor = [0 0.45 0.74];
    hh.calendar.f(1).Visible = 'off';
    hh.calendar.f(2).Visible = 'off';
    hh.v = 0;
end
end

%% Parameters Input Panel Callbacks
% Fixing a value to a parameter
function callback7(varargin)
global h
h.check_box(end).Value = 0;
if ~h.modification
    h = exp_nb_update(h);
end
h = param_insert(h);
end
function anyKeyPress(varargin)
global h
if ~isempty(h.editable_text_field(end).String)
    callback7
end
end
% Removing the value of a parameter
function callback8(varargin)
global h
if ~h.modification
    h = exp_nb_update(h);
end
h = param_remove(h);
end

%% Edit Experiments List Panel Callbacks
% Add or update the experiment with the inserted paramters
function callback9(varargin)
global h
global hh
if ~h.modification
    h = exp_create(h);
    h = extset_generate(h);
    % List Box
    h.list_box(3).String = sprintf(h.extset);
    h = exp_nb_update(h);
    [~,d] = ismember({'delete'},lower(h.checkList(:,1)));
    if d
        if h.check_box(h.checkList{d,5},1).Value
            h.check_box(h.checkList{d,5},1).Value = 0;
            [h,hh] = enable_entries(h,hh);
            h.delete = 0;
        end
    end
else
    h = modify_entries(h);
    h = info_display(h);
    h = extset_generate(h);
    % List Box
    h.list_box(3).String = sprintf(h.extset);
end
end
% Deleting the selected experiment
function callback10(varargin)
global h
if ~h.modification
    h.list_box(3).Value = 1;
    h = exp_delete(h);
    h = extset_generate(h);
    % List Box
    h.list_box(3).String = sprintf(h.extset);
    h = exp_nb_update(h,1);
end
end
% Duplicating the selected experiment
function callback11(varargin)
global h
if ~h.modification
    h = exp_duplicate(h);
    h = extset_generate(h);
    % List Box
    h.list_box(3).String = sprintf(h.extset);
end
end
% Uplift the selected experiment
function callback12(varargin)
global h
if ~h.modification
    h = exp_lift(h,0);
    h = extset_generate(h);
    % List Box
    h.list_box(3).String = sprintf(h.extset);
end
end
% Downlift the selected experiment
function callback13(varargin)
global h
if ~h.modification
    h = exp_drop(h);
    h = extset_generate(h);
    % List Box
    h.list_box(3).String = sprintf(h.extset);
end
end
% Experiment display
function callback14(varargin)
global h
global hh
if ~h.modification
    h = info_display(h);
    [~,d] = ismember({'delete'},lower(h.checkList(:,1)));
    if d
        if h.check_box(h.checkList{d,5},1).Value
            [h,hh] = disable_entries(h,hh,0);
            h.delete = 1;
        else
            [h,hh] = enable_entries(h,hh);
            h.delete = 0;
            [~,d] = ismember({'expno'},lower(h.checkList(:,1)));
            if d && h.modification
                h.editable_text_field(h.checkList{d,3},1).Enable = 'off';
            end
        end
    end
end
end
% Modify
function callback15(varargin)
global h
if ~isempty(h.list_box(2).String)
    h = info_display(h);
    if h.toggle_button(1).Value
        h.toggle_button(1).BackgroundColor = [1 0.07 0.65];
        h.toggle_button(1).ForegroundColor = [1 1 1];
        h = modification(h,1);
        h.modification = 1;
        [~,d] = ismember({'expno'},lower(h.checkList(:,1)));
        if d
            h.editable_text_field(h.checkList{d,3},1).Enable = 'off';
        end
        h.push_button(3).String = 'Update';
        h.push_button(3).ForegroundColor = [1 0.07 0.65];
    else
        h.toggle_button(1).BackgroundColor = [1 1 1];
        h.toggle_button(1).ForegroundColor = [1 0.07 0.65];
        h = modification(h,0);
        h.modification = 0;
        [~,d] = ismember({'expno'},lower(h.checkList(:,1)));
        if d
            h.editable_text_field(h.checkList{d,3},1).Enable = 'on';
            h = exp_nb_update(h);
        end
        h.push_button(3).String = 'Add';
        h.push_button(3).ForegroundColor = [0.05,0.65,0.12];
    end
else
    h.toggle_button(1).Value = 0;
    h.modification = 0;
    h.push_button(3).String = 'Add';
    h.push_button(3).ForegroundColor = [0.05,0.65,0.12];
end
end

%% Peak Area Indication Callback
% Area region insert for target peak
function AreaRegionInsert(varargin)
global h
% bound1 = str2double(h.area.editable_text_field(1,1).String);
% bound2 = str2double(h.area.editable_text_field(2,1).String);
bound1 = str2double(h.area.editable_text_field(1).String);
bound2 = str2double(h.area.editable_text_field(2).String);
if ~isempty(bound1) && ~isempty(bound2)
    if isnan(bound1) || isnan(bound2)
%         h.area.regionInsert = 0;
        h.area.AreaRegion = [];
        if isnan(bound1)
            h.area.editable_text_field(1,1).String = '';
        end
        if isnan(bound2)
            h.area.editable_text_field(2,1).String = '';
        end
        h.area.missing(1).Visible = 'on';
        h.area.missing(1).BackgroundColor = [1 0 0];
    else
        if (bound1==bound2)
%             h.area.regionInsert = 0;
            h.area.AreaRegion = [];
            h.area.editable_text_field(2,1).String = '';
            h.area.missing(1).Visible = 'on';
            h.area.missing(1).BackgroundColor = [1 0 0];
        else
            if(bound1>bound2)
%                 h.area.regionInsert = 0;
                h.area.AreaRegion = [];
                h.area.editable_text_field(2,1).String = '';
                h.area.missing(1).Visible = 'on';
                h.area.missing(1).BackgroundColor = [1 0 0];
            else
                h.area.regionInsert = 1;
                h.area.AreaRegion = [bound1,bound2];
                h.area.missing(1).Visible = 'on';
                h.area.missing(1).BackgroundColor = [0 1 0];
            end
        end
    end
else
    h.area.AreaRegion = [];
    h.area.regionInsert = 0;
end
end
% Area region insert for reference peak
function AreaRegionInsert2(varargin)
global h
% bound1 = str2double(h.area.editable_text_field(3,1).String);
% bound2 = str2double(h.area.editable_text_field(4,1).String);
bound1 = str2double(h.area.editable_text_field(3).String);
bound2 = str2double(h.area.editable_text_field(4).String);
if ~isempty(bound1) && ~isempty(bound2)
    if isnan(bound1) || isnan(bound2)
        %         h.area.regionInsert = 0;
        h.area.AreaRegion2 = [];
        if isnan(bound1)
            h.area.editable_text_field(3,1).String = '';
        end
        if isnan(bound2)
            h.area.editable_text_field(4,1).String = '';
        end
        h.area.missing(2).Visible = 'on';
        h.area.missing(2).BackgroundColor = [1 0 0];
    else
        if (bound1==bound2)
            %             h.area.regionInsert = 0;
            h.area.AreaRegion2 = [];
            h.area.editable_text_field(4,1).String = '';
            h.area.missing(2).Visible = 'on';
            h.area.missing(2).BackgroundColor = [1 0 0];
        else
            if(bound1>bound2)
                %                 h.area.regionInsert = 0;
                h.area.AreaRegion2 = [];
                h.area.editable_text_field(4,1).String = '';
                h.area.missing(2).Visible = 'on';
                h.area.missing(2).BackgroundColor = [1 0 0];
            else
                h.area.regionInsert2 = 1;
                h.area.AreaRegion2 = [bound1,bound2];
                h.area.missing(2).Visible = 'on';
                h.area.missing(2).BackgroundColor = [0 1 0];
            end
        end
    end
else
    h.area.AreaRegion2 = [];
    h.area.regionInsert2 = 0;
end
end
% Add new peaks to be investigates
function AreaRegionAddExtra(varargin)
global h
% f = figure('Name','Add multiple target peaks','Position',[859 235 418 162]);
h.areaAdditional.f = figure('Name','Add other peaks regions','Position',[432 227 418 162]);
% Static text fields
uicontrol('style','text','units','normalized',...
    'string','Insert limits :','FontName','Arial','FontSize',10,...
    'BackgroundColor',[0.94,0.94,0.94],'Parent',h.areaAdditional.f,'HorizontalAlignment','left',...
    'Position',[0.0574 0.7901 0.2998 0.1070]);
uicontrol('style','text',...
    'units','normalized','HorizontalAlignment','left','String',...
    '[              ,              ]ppm','FontName',...
    'Arial','FontSize',10,'BackgroundColor',[0.94,0.94,0.94],'Parent',h.areaAdditional.f,...
    'Position',[0.0574 0.6543 0.3732 0.1264]);
uicontrol('style','text','units','normalized',...
    'string','Additional requested regions','FontName','Arial','FontSize',11,...
    'BackgroundColor',[0.94,0.94,0.94],'Parent',h.areaAdditional.f,'HorizontalAlignment','left',...
    'Position',[0.4609 0.7901 0.4992 0.1446],'FontWeight','bold');
% Editable text fields
h.areaAdditional.editable_text_field(1)= uicontrol('style','edit','units','normalized',...
    'String','','Parent',h.areaAdditional.f,'FontName','Arial','FontSize',10,...
    'Position',[0.0718 0.6626 0.1308 0.1255],...
    'Visible','on','Callback',@AreaRegionInsert3);
h.areaAdditional.editable_text_field(2)= uicontrol('style','edit','units','normalized',...
    'String','','Parent',h.areaAdditional.f,'FontName','Arial','FontSize',10,...
    'Position',[0.2129 0.6626 0.1308 0.1255],...
    'Visible','on','Callback',@AreaRegionInsert3);
% Push Buttons
uicontrol('style','pushbutton','units','normalized',...
    'BackgroundColor',[0.94,0.94,0.94],'ForegroundColor',[0.05,0.65,0.12],...
    'string','Add','callback',@AreaRegionAddExtra_add,'Visible','on','Value',0,...
    'FontSize',14,'FontName','Arial','FontWeight','normal','Position',...
    [0.0718 0.3621 0.2743 0.2490],'Parent',h.areaAdditional.f);
uicontrol('style','pushbutton','units','normalized',...
    'BackgroundColor',[0.94,0.94,0.94],'ForegroundColor',[0.78,0.22,0.32],...
    'string','Delete','callback',@AreaRegionAddExtra_delete,'Visible','on','Value',0,...
    'FontSize',14,'FontName','Arial','FontWeight','normal','Position',...
    [0.0718 0.0899 0.2743 0.2490],'Parent',h.areaAdditional.f);
% List Boxe
h.areaAdditional.list_box(1) = uicontrol('style','listbox','units','normalized',...
    'Parent',h.areaAdditional.f,'Visible','on','FontSize',11,...
    'Position',[0.4609 0.0899 0.4673 0.6982],'FontName','Arial');
if isfield(h,'areaAdditionalList_Num')
    for i = 1:size(h.areaAdditionalList_Num,1)
        out = h.areaAdditionalList_Num(i,1:2);
        out = ['[ ' num2str(out(1)) ' , ' num2str(out(2)) ' ]ppm'];
        h.areaAdditionalList_String{i,1} = out;
    end
    h.areaAdditional.list_box(1).String = h.areaAdditionalList_String;
end
waitfor(h.areaAdditional.f)
if isfield(h,'areaAdditionalList_Num')
    h = rmfield(h,'areaAdditionalList_Num');
end
for i = 1:length(h.areaAdditionalList_String)
    out = textscan(h.areaAdditionalList_String{i},'[ %f , %f ]ppm');
    h.areaAdditionalList_Num(i,1:2) = [out{1},out{2}];
end
h.areaAdditionalList_Num
end
% Area region insert for additional peaks
function AreaRegionInsert3(varargin)
global h
bound1 = str2double(h.areaAdditional.editable_text_field(1).String);
bound2 = str2double(h.areaAdditional.editable_text_field(2).String);
if ~isempty(bound1) && ~isempty(bound2)
    if isnan(bound1) || isnan(bound2)
        h.areaAdditional.AreaRegion = [];
        if isnan(bound1)
            h.areaAdditional.editable_text_field(1).String = '';
        end
        if isnan(bound2)
            h.areaAdditional.editable_text_field(2).String = '';
        end
    else
        if (bound1==bound2)
            h.areaAdditional.AreaRegion = [];
            h.areaAdditional.editable_text_field(2).String = '';
        else
            if(bound1>bound2)
                h.areaAdditional.AreaRegion = [];
                h.areaAdditional.editable_text_field(2).String = '';
            else
                h.areaAdditional.regionInsert = 1;
                h.areaAdditional.AreaRegion = [bound1,bound2];
            end
        end
    end
else
    h.areaAdditional.AreaRegion = [];
    h.areaAdditional.regionInsert = 0;
end
end
% Add inserted additional area regions
function AreaRegionAddExtra_add(varargin)
global h
a = str2double(h.areaAdditional.editable_text_field(1).String);%lower bound
b = str2double(h.areaAdditional.editable_text_field(2).String);%higher bound
if isnan(a) || isnan(b)
    return
end
c = h.areaAdditional.list_box(1).String;%already saved list
line2add = ['[ ' num2str(a) ' , ' num2str(b) ' ]ppm'];
if isempty(c)
    h.areaAdditional.list_box(1).String = {line2add};
else
    if ismember(line2add,c) % if regions already saved
        return
    end
    h.areaAdditional.list_box(1).String = [c;{line2add}];
end
h.areaAdditional.list_box(1).Value = ...
    length(h.areaAdditional.list_box(1).String);%select the new line
% Update the desired region bounds
h.areaAdditionalList_String = h.areaAdditional.list_box(1).String;
end
% Delete selected area regions
function AreaRegionAddExtra_delete(varargin)
global h
d = h.areaAdditional.list_box(1).Value;%selected line to remove
c = h.areaAdditional.list_box(1).String;%already saved list
if isempty(c)
    return
end
if d==length(c)
    h.areaAdditional.list_box(1).Value = d-1;%select the next line
else
    h.areaAdditional.list_box(1).Value = d;%select the new next line
end
ind = (1:length(c))~=d;
c = c(ind);%keep only this
h.areaAdditional.list_box(1).String = c;%update list
% Update the desired region bounds
h.areaAdditionalList_String = h.areaAdditional.list_box(1).String;
end

%% Control and Display Panel Callbacks
% GO
function callback16(varargin)
global h output %t_transfer
if ~isempty(h.extset)
    if h.autoMode==0
%         if h.area.regionInsert==1
%             % check if the region is inserted or not
%             if isempty(h.area.AreaRegion)
% %                 h.area.missing(1).Visible = 'on';
% %                 h.area.missing(1).BackgroundColor = [1 0 0];
%                 fprintf('\nCheck the area bounds !\n')
%                 return
%             else
%                 [~,d] = ismember({'areacalculation'},lower(h.checkList(:,1)));
%                 if d
%                     check = cell2mat(h.checkList(d,end));
%                     h.check_box(check).Enable = 'off';
%                     h.area.editable_text_field(1,1).Enable = 'off';
%                     h.area.editable_text_field(2,1).Enable = 'off';
%                 end
%             end
%         end
%         if h.area.regionInsert2==1
%             % check if the region is inserted or not
%             if isempty(h.area.AreaRegion2)
% %                 h.area.missing(2).Visible = 'on';
% %                 h.area.missing(2).BackgroundColor = [1 0 0];
%                 fprintf('\nCheck the area bounds !\n')
%                 return
%             else
%                 [~,d] = ismember({'referencepeak'},lower(h.checkList(:,1)));
%                 if d
%                     check = cell2mat(h.checkList(d,end));
%                     h.check_box(check).Enable = 'off';
%                     h.area.editable_text_field(3,1).Enable = 'off';
%                     h.area.editable_text_field(4,1).Enable = 'off';
%                 end
%             end
%         end
    end
    
    % Generating the extset text file
    fId = fopen('C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\Post_Doc_codes\extset01.txt','w');
    fprintf(fId, h.extset);
    fclose(fId);
%     clc
%     fprintf('\nHere 1: \n')
%     fprintf(h.extset)
%     drawnow
%     pause(1)
    if h.test==0
        % Time of the transfer
        t_transfer = datetime('now');
        % Exset file transfer
        desiredName = 'extset.txt'; %%#ok<NASGU>
        transfer_to_spectro500(...
            'C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\Post_Doc_codes',...
            'extset01.txt','/opt/topspin3.6.2/prog/tmp/',desiredName)
        if true && true
            % Check and see if the the extset file is transferred successfully and
            % scanned by IconNMR
            extset_path = '/opt/topspin3.6.2/prog/tmp/';
            % e = 0;eaten = 0;
            [~,eaten] = check_if_extset_eaten_spectro500(desiredName,...
                extset_path,t_transfer,1);
            % FileName = desiredName;waitCheck = 1;varargin = [];
            if eaten==0
                fprintf('File not transferred successfully! try again...')
                return
            else
                fprintf('\nextset file was eaten !\n')
            end
        else
            % Wait till the desired experiments are added
            newestHist = 1;
            quickCheck = 1;
            timeline = 0;
            tracking = 1;
            enterLoop1 = 0;
            enterLoop2 = 0;
            while(tracking)
                histTrack = track_history(newestHist,quickCheck,timeline);
                if isempty(histTrack.created_exp)
                    fprintf('\n No experiment was added. Let''s wait...\n')
                elseif isempty(histTrack.created_exp{end})
                    fprintf('\n No experiment was added. Let''s wait...\n')
                    enterLoop1 = enterLoop1+1;
                    if enterLoop1==10
                        % Check if the experiments were created but not logged in
                        % the topspin history file
                        if h.running==0
                            %                         pause(5)
                        end
                        % Ask for the user verification
                        opts.Interpreter = 'tex';
                        opts.Default = 'Yes';
                        quest = {'Were the requested experiments added?'};
                        answer0 = questdlg(quest,'Verification',...
                            'Yes','No',opts);
                        switch answer0
                            case 'Yes'
                                tracking = 0;
                                fprintf('\n The desired experiments were added. The acquition will start soon !!\n')
                            case 'No'
                        end
                        %                     expTrack = track_exp(h);
                        %                     if expTrack
                        %                         tracking = 0;
                        %                         fprintf(['\n The desired experiments were added.'...
                        %                             ' The acquition will start soon !!' ...
                        %                             '  /!\\ History file surpassed /!\\\n'])
                        %                     end
                    end
                elseif mod(length(histTrack.created_exp{end}),size(h.Experiment_Table,1)-1) ||...
                        mod(length(histTrack.created_exp{end}),h.Experiment_Table.ExpNo(end))
                    fprintf('\n Not all desired experiments were added. Let''s wait...\n')
                    % Check if experiments were added in the status file
                    statusPath = '/opt/topspin3.6.2/prog/curdir/changer';
                    exp_in_status = check_if_exp_added_to_status_file_spectro500...
                        (h.fileName,statusPath,h.Experiment_Table.ExpNo(2:end),1);
                    if exp_in_status
                        tracking = 0;
                        fprintf('\n The desired experiments were added. The acquition will start soon !!\n')
                    else
                        enterLoop2 = enterLoop2+1;
                    end
                    if enterLoop2==10
                        % Check if the experiments were created but not logged in
                        % the topspin history file
                        if h.running==0
                            %                         pause(5)
                        end
                        % Ask for the user verification
                        opts.Interpreter = 'tex';
                        opts.Default = 'Yes';
                        quest = {'Were the requested experiments added?'};
                        answer0 = questdlg(quest,'Verification',...
                            'Yes','No',opts);
                        switch answer0
                            case 'Yes'
                                tracking = 0;
                                fprintf('\n The desired experiments were added. The acquition will start soon !!\n')
                            case 'No'
                        end
                        %                     expTrack = track_exp(h);
                        %                     if expTrack
                        %                         tracking = 0;
                        %                         fprintf(['\n The desired experiments were added.'...
                        %                             ' The acquition will start soon !!' ...
                        %                             '  /!\\ History file surpassed /!\\\n'])
                        %                     end
                    end
                else
                    tracking = 0;
                    fprintf('\n The desired experiments were added. The acquition will start soon !!\n')
                end
            end
        end
        if h.TSarea==1
            % Transfer the intrng file to the created dataset folder
            expList = h.Experiment_Table.ExpNo(2:end);
            expList = expList(~ismember(expList,h.intrngArchive)); % Exp not found yet
            if ~isempty(expList)
                FileName_intrng = char(h.Experiment_Table.Name(2));
                datasetPath_intrng = '/opt/nmrdata/user/nmr/Nour';
                waitCheck = 0;
                [dataset_folder_ready,~] = check_if_dataset_folder_created_spectro500...
                    (FileName_intrng,datasetPath_intrng,expList,waitCheck);
                % Send intrng once experimental dataset folder is created
%                 desiredName_intrng = 'intrng';
                for i = 1:length(dataset_folder_ready)
                    % copy intrng files
                    PathAndFile2copy = '/home/nmr/Documents/Nour/intrng';
                    cp_spectro500(PathAndFile2copy,FileName_intrng,...
                        datasetPath_intrng,dataset_folder_ready(i))
%                     % intrng file transfer
%                     transfer_to_spectro500(...
%                         'C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\Post_Doc_codes',...
%                         'intrng0',[datasetPath_intrng '/' FileName_intrng '/' ...
%                         num2str(dataset_folder_ready(i)) '/pdata/1/'],desiredName_intrng)
                    % Archive of experiments to those the intrng file was transferred
                    h.intrngArchive = [h.intrngArchive dataset_folder_ready(i)];
                end
            end
        end
    end
    
    output = h.Experiment_Table(2:end,:);
    h.archive = [h.archive;output.ExpNo];
    

%     % Display the Extset file to be transferred
%     newFig = figure;%('units','normalized','position',[0.7 0.3 0.3 0.4]);
%     list_box = uicontrol('style','listbox','units','normalized',...
%         'Parent',newFig,'Visible','on','FontSize',11,...
%         'Position',[0.1 0.15 0.8 0.7],'FontName','Arial');
%     list_box.String = h.list_box(3).String;
%     uicontrol('style','text','units','normalized',...
%         'string','External Setup Text File','FontName','Arial','FontSize',20,...
%         'BackgroundColor',[0.94,0.94,0.94],'Parent',newFig,'Position',...
%         [0.05 0.85 0.9 0.09],'FontWeight','bold');
%     pause(1)
%     close(newFig)
    
    % Dialog print
    fprintf('\nThe extset text file containing the list of experiments has been transferred.\n')
    if h.autoMode==0
        if sum(output.StartRun)>0 || h.running==1
            % Update info
            h.running = 1;
            if h.firstRun==0
                if ~ismember({'Experiment_Table_HoldOn'},fieldnames(h))
                    h.Experiment_Table_HoldOn = h.Experiment_Table(2:end,:);
                else
                    h.Experiment_Table_HoldOn = [h.Experiment_Table_HoldOn;h.Experiment_Table(2:end,:)];
                end
                h.firstRun = 1;
                first = 1;
                h.WaitForGo = 0;
                callback1
                drawnow
                h.Experiment_Table(2:end,:) = [];
                h = extset_generate(h);
                h.list_box(3).String = sprintf(h.extset);
                h = exp_nb_update(h);
                h.list_box(2).Value = 1;
                h.list_box(2).String = [];
%                 pause(1)
                h = check_status(h,first); % instead of h = test_status2(h,first);
                drawnow
                if ~isempty(h.AreaRegion)%h.area.regionInsert==1
                    getAreaValue
                end
            else
                if h.runStopped==0
                    h.Experiment_Table_HoldOn = h.Experiment_Table(2:end,:);
                    h.QExpList = {'Launched Experiments : ','Experiments in Queue : '};
                    h.QExpList{1} = [h.QExpList{1} num2str(h.archive')];
                    h.list_box(4).String = h.QExpList; drawnow
                else
                    h.Experiment_Table_HoldOn = [h.Experiment_Table_HoldOn;h.Experiment_Table(2:end,:)];
                end
                first = 0;
                h.WaitForGo = 0;
                callback1
                drawnow
                h.Experiment_Table(2:end,:) = [];
                h = extset_generate(h);
                h.list_box(3).String = sprintf(h.extset);
                h = exp_nb_update(h);
                h.list_box(2).Value = 1;
                h.list_box(2).String = [];
%                 pause(1)
                h = check_status(h,first); % instead of h = test_status2(h,first);
                drawnow
                if ~isempty(h.AreaRegion)%h.area.regionInsert==1
                    getAreaValue
                end
                
            end
            %         h = test_status(h);
            %         h = display_spectrum(h,t_transfer);
            
            % Dialog print
            fprintf('The experiment(s) is(are) launched.\n')
        else
            if h.firstRun==0
                if ~ismember({'Experiment_Table_HoldOn'},fieldnames(h))
                    h.Experiment_Table_HoldOn = h.Experiment_Table(2:end,:);
                else
                    h.Experiment_Table_HoldOn = [h.Experiment_Table_HoldOn;h.Experiment_Table(2:end,:)];
                end
                h.QExpList = {'Launched Experiments : ','Experiments in Queue : '};
                [~,a] = ismember(h.archive,h.Experiment_Table_HoldOn.ExpNo);
                b = find(~ismember(1:length(h.archive),a));
                h.QExpList{1} = [h.QExpList{1} num2str(h.archive(b)')];
                h.QExpList{2} = [h.QExpList{2} num2str(h.archive(a)')];
                h.list_box(4).String = h.QExpList; drawnow
            else
                if h.runStopped==1
                    h.Experiment_Table_HoldOn = h.Experiment_Table(2:end,:);
                    h.runStopped = 0;
                else
                    h.Experiment_Table_HoldOn = [h.Experiment_Table_HoldOn;h.Experiment_Table(2:end,:)];
                end
                h.QExpList = {'Launched Experiments : ','Experiments in Queue : '};
                [~,a] = ismember(h.archive,h.Experiment_Table_HoldOn.ExpNo);
                b = find(~ismember(1:length(h.archive),find(a)));
                h.QExpList{1} = [h.QExpList{1} num2str(h.archive(b)')];
                h.QExpList{2} = [h.QExpList{2} num2str(h.archive(find(a))')];
                h.list_box(4).String = h.QExpList; drawnow
            end
            h.WaitForGo = 0;
            callback1
            drawnow
            h.Experiment_Table(2:end,:) = [];
            h = extset_generate(h);
            h.list_box(3).String = sprintf(h.extset);
            h = exp_nb_update(h);
            h.list_box(2).Value = 1;
            h.list_box(2).String = [];
            
            % Dialog print
            fprintf('The experiment(s) has(ve) been added to the queue.\n')
        end
    else
        % If experiments are launched until maximum area is reached
        if h.untilAreaMax
            % Update info
            h.running = 1;
            h.Experiment_Table_HoldOn = h.Experiment_Table(2:end,:);
            h.QExpList = {'Launched Experiments : ','Experiments in Queue : '};
            h.QExpList{1} = [h.QExpList{1} num2str(h.archive')];            
            first = 0;
            h.WaitForGo = 0;
%             h.Experiment_Table(2:end,:) = [];
            h = extset_generate(h);
            fprintf('The experiment(s) is(are) launched.\n')
            h = check_status(h,first);
            drawnow
            if ~isempty(h.AreaRegion)
                getAreaValue
            end
        end
    end
end
end
% STOP
function callback17(varargin)
global h %output
if ~(size(varargin,2)==0)
    quickStop = 1;
else
    quickStop = 0;
end

% Generating the extset text file
fId = fopen('C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\Post_Doc_codes\extset01.txt','w');
fprintf(fId, '\nSTOP_RUN\n');
fclose(fId);

if h.test==0
    % Time of the transfer
    % t_transfer = datetime('now');

    % Exset file transfer
    desiredName = 'extset.txt'; %%#ok<NASGU>
    transfer_to_spectro500(...
        'C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\Post_Doc_codes',...
        'extset01.txt','/opt/topspin3.6.2/prog/tmp/',desiredName)
    
%     % Check and see if the the extset file is transferred successfully and
%     % scanned by IconNMR
%     extset_path = '/opt/topspin3.6.2/prog/tmp/';
% %     pause(2)
%     eaten = check_if_extset_eaten_spectro500(desiredName,...
%         extset_path,t_transfer,1);
%     if eaten==0
%         fprintf('File not transferred successfully! try again...')
%         return
%     else
%         fprintf('\nextset file was eaten !\n')
%     end
    % Wait till the automation is stopped
    newestHist = 1;
    quickCheck = 1;
    timeline = 0;
    tracking = 1;
    while(tracking)
        histTrack = track_history(newestHist,quickCheck,timeline);
        if isempty(histTrack.automation_RUN)
            fprintf('\n Automation still running. Let''s wait...\n')
        elseif isempty(histTrack.automation_RUN{end})
            fprintf('\n Automation still running. Let''s wait...\n')
        elseif histTrack.automation_RUN{end}==1
            fprintf('\n Automation still running. Let''s wait...\n')
        else
            tracking = 0;
            fprintf('\n The automation has stopped !!\n')
        end
    end
end

h.runStopped = 1;

% Dialog print
if h.autoMode==0
    fprintf('\nThe automation has been stopped by the user.\n')
else
    fprintf('\nThe automation has been stopped automatically.\n')
end

% Quick stop when optimum reach at the previous iteration
if h.autoMode==1
    if quickStop
        return
    end
end

h.running = 0;

if h.autoMode==0
    h.WaitForGo = 1;
    callback1
    drawnow
end
end
% START
function callback18(varargin)
global h %output t_transfer

if ~(size(varargin,2)==0)
    quickStart = 1;
else
    quickStart = 0;
end

if h.running==0
    % Generating the extset text file
    fId = fopen('C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\Post_Doc_codes\extset01.txt','w');
    fprintf(fId, '\nSTART_RUN\n');
    fclose(fId);
    
    if h.test==0
        % Time of the transfer
        % t_transfer = datetime('now');

        if ~h.DontStartRunning
        % Exset file transfer
        desiredName = 'extset.txt'; %%#ok<NASGU>
        transfer_to_spectro500(...
            'C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\Post_Doc_codes',...
            'extset01.txt','/opt/topspin3.6.2/prog/tmp/',desiredName)
        end
%         % Check and see if the the extset file is transferred successfully and
%         % scanned by IconNMR
%         extset_path = '/opt/topspin3.6.2/prog/tmp/';
% %         pause(2)
%         eaten = check_if_extset_eaten_spectro500(desiredName,...
%             extset_path,t_transfer,1);
%         if eaten==0
%             fprintf('File not transferred successfully! try again...')
%             return
%         else
%             fprintf('\nextset file was eaten !\n')
%         end
        
        % Wait till the automation is started
        newestHist = 1;
        quickCheck = 1;
        timeline = 0;
        tracking = 1;
        while(tracking)
            histTrack = track_history(newestHist,quickCheck,timeline);
            if isempty(histTrack.automation_RUN)
                fprintf('\n Automation not started. Let''s wait...\n')
            elseif isempty(histTrack.automation_RUN{end})
                fprintf('\n Automation not started. Let''s wait...\n')
            elseif histTrack.automation_RUN{end}==0
                fprintf('\n Automation not started. Let''s wait...\n')
            else
                tracking = 0;
                fprintf('\n The automation has started !!\n')
            end
        end
    end
    
    
    % Quick start 
    if h.autoMode==1
        if quickStart
            return
        end
    end
    
    
    h.running = 1;
     
    
    h.QExpList = {'Launched Experiments : ','Experiments in Queue : '};
    h.QExpList{1} = [h.QExpList{1} num2str(h.archive')];

    if h.autoMode==0
        h.list_box(4).String = h.QExpList; drawnow
        callback1
        drawnow
    end
    
    % Dialog print
    fprintf('\nThe automation started.\n')
    fprintf('\n. . .\n')
else
    % Dialog print
    fprintf('\nThe automation is running.\n')
    fprintf('\n. . .\n')
%     pause(1)
end

% Update info
if h.autoMode==0
    if h.firstRun==0
        h.firstRun = 1;
        first = 1;
        h = check_status(h,first); % instead of h = test_status2(h,first);
        if isempty(h.status.uit.CellSelectionCallback)
            if ~h.untilAreaMax
                h.status.uit.CellSelectionCallback = @UITableCellSelection;
            end
        end
        if isempty(h.status.button(1).ButtonPushedFcn)
            h.status.button(1).ButtonPushedFcn = @setAreaRegion;
        end
        if isempty(h.status.button(2).ButtonPushedFcn)
            h.status.button(2).ButtonPushedFcn = @getAreaValue;
        end
        if isempty(h.status.button(3).ButtonPushedFcn)
            h.status.button(3).ButtonPushedFcn = @termination;
        end
        if isempty(h.status.uitextarea(1).ValueChangedFcn)
            h.status.uitextarea(1).ValueChangedFcn = @insertAreaRegion;
        end
        if isempty(h.status.uitextarea(2).ValueChangedFcn)
            h.status.uitextarea(2).ValueChangedFcn = @insertAreaRegion;
        end
        if isfield(h.status,'F')
            % The status window contains tabs
            if strcmp(h.status.F.CloseRequestFcn,'closereq')
                h.status.F.CloseRequestFcn = @closeWarning;
            end            
        else
            if strcmp(h.status.f(1).CloseRequestFcn,'closereq')
                h.status.f(1).CloseRequestFcn = @closeWarning;
            end
        end
        drawnow
        if ~isempty(h.AreaRegion)%h.area.regionInsert==1
            getAreaValue
        end
    else
        first = 0;
        h = check_status(h,first); % instead of h = test_status2(h,first);
        drawnow
        if ~isempty(h.AreaRegion)%h.area.regionInsert==1
            getAreaValue
        end
    end
else
    if h.cont==0
        first = 1;
    else
        first = 0;
    end
    h = check_status(h,first); % instead of h = test_status3(h,first);
    if isempty(h.status.uit.CellSelectionCallback)
        if ~h.untilAreaMax
            h.status.uit.CellSelectionCallback = @UITableCellSelection;
        end
    end
    if isfield(h.status,'F')
        % The status window contains tabs
        if strcmp(h.status.F.CloseRequestFcn,'closereq')
            h.status.F.CloseRequestFcn = @closeWarning;
        end
    else
        if strcmp(h.status.f(1).CloseRequestFcn,'closereq')
            h.status.f(1).CloseRequestFcn = @closeWarning;
        end
    end
    if ~isempty(h.area.AreaRegion)
        getAreaValue
    end
end
end
% Uplift the fixed input position in the extset file
function callback19(varargin)
global h
h = fixed_input_lift(h);
end
% Downlift fixed input position in the extset file
function callback20(varargin)
global h
h = fixed_input_drop(h);
end
% Delete fixed input from the exset file
function callback21(varargin)
global h
h = fixed_input_delete(h);
end
% Save the list of experiments for future auto-mode call
function saveH(varargin)
global h pathname
if ~isempty(h.extset)
    if size(h.Experiment_Table,1)~=1
        autoModeHandles.Table = h.Experiment_Table;
    else
        autoModeHandles.Table = [h.Experiment_Table;h.Experiment_Table_HoldOn];
    end
    if h.userExpListSelection_plateau==1
        if size(h.Experiment_Table,1)>2
            % More than 1 experiment was selected, but only one is required
            message = {['The interface was called to select ONLY ONE experiment to search for a plateau.',...
                'However, more than one were selected !'];'Please review your list.'};
            msg = msgbox(message);
            waitfor(msg)
            return
        end
    end

    % check if the region is inserted or not
    if isempty(h.area.AreaRegion) || isempty(h.area.AreaRegion2)
        AreaRegionInsert
        AreaRegionInsert2
        h.autoModeSAve = 0;
        if ~ismember({'fileName'},fieldnames(h))
            % Status window not open yet
            if h.userExpListSelection==0
                % enabling all children for area panel
                panelChildren = h.panel(6).Children;
                for i = 1:length(panelChildren)
                    if strcmp(panelChildren(i).Style,'edit')
                        panelChildren(i).Enable = 'on';
                    end
                end
            end
        else
            if isfield(h.status,'F')
                % The status window contains tabs
                figure(h.status.F)
            else
                figure(h.status.f(1))
            end
            err='Choose area bounds in the Status window !';
            nes_msgbox = msgbox(err);
            waitfor(nes_msgbox)
        end
        fprintf('\nCheck the area bounds !\n')
        return
    else
        autoModeHandles.area = h.area.AreaRegion;
        autoModeHandles.areaRef = h.area.AreaRegion2;
        autoModeHandles.archive = [];
        if isfield(h,'areaAdditionalList_Num')
            autoModeHandles.areaAdditionalList_Num = h.areaAdditionalList_Num;
        end
    end

    autoModeHandles.status = h.status;
    if ismember({'fileName'},fieldnames(h))
        autoModeHandles.fileName = h.fileName;
%         savefig(autoModeHandles.status.f,'autoModeHandles_fig_screenX.fig')
        couldexit = 0;
        % Remove figure handles from the saved struct for simpler saving
        autoModeHandles.status = rmfield(autoModeHandles.status,'f');
        if ismember({'plt'},fieldnames(autoModeHandles.status))
            % Remove figure handles from the saved struct for simpler saving
            autoModeHandles.status = rmfield(autoModeHandles.status,'plt');
        end
    else % no experiment is launched yet
        if h.test==0
            autoModeHandles.fileName = char(datetime('now','Format','MMMdd-yyyy'));
        else
%             autoModeHandles.fileName = 'Mar30-2022-1233-Nour.set';
            autoModeHandles.fileName = 'May23-2022-1436-Nour.set';
        end
        couldexit = 1;
    end
    
    % Ask User for the autohandles saving path
    conditionSAVEHANDLES = 1;
    while (conditionSAVEHANDLES)
        if h.userExpListSelection_plateau==1
            [file,path] = uiputfile([pathname '\autoModeHandlesLoopTillPlateau.mat'],'Choose a file to save dataset');
        else
            [file,path] = uiputfile([pathname '\autoModeHandles.mat'],'Choose a file to save dataset');
        end
        if ischar(file)
            conditionSAVEHANDLES = 0;
        else
            conditionSAVEHANDLES = 1;
        end
    end
    % Handles saving
    h.autoModeHandlesPathName = [path,file];
    save(h.autoModeHandlesPathName,'autoModeHandles')
    
    h.autoModeSAve = 1;
    if size(h.Experiment_Table,1)~=1
        % Generating the extset text file
        fId = fopen('C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\Post_Doc_codes\extset01.txt','wt');
        fprintf(fId, h.extset);
        fclose(fId);
        
        fprintf('\nThis experiments list is saved for auto-mode call.\n')
    else
        fprintf('\nThe latest experiments list is saved for auto-mode call.\n')
    end
    if couldexit
        % User's Choice :  exit?
        opts.Interpreter = 'tex';
        opts.Default = 'No';
        quest = {'Handles saved for auto-mode call.',...
            'Would you like terminate the application?'};
        
        % Dialog print
        fprintf('\n[ ? ] Exit the application?\n')
        
        answer0 = questdlg(quest,'Exit',...
            'Yes','No',opts);
        switch answer0
            case 'Yes'
                fprintf('Exit...\n')
                termination
            case 'No'
                fprintf('Continuing...\n')
                % disabling all children for area panel
                if h.userExpListSelection==0
                    panelChildren = h.panel(6).Children;
                    for i = 1:length(panelChildren)
                        if strcmp(panelChildren(i).Style,'edit')
                            panelChildren(i).Enable = 'off';
                        end
                    end
                end
        end
    end
else
    h.autoModeSAve = 0;
end
end

%% Status Table Callback
% Cell selection callback: UITable
function UITableCellSelection(~, event)
global h
if exist(H,'var')
return
end
if isa(h,'struct')
    stt = h.status;
    smoothly = 1;
else
    FigureHandle = get(0, 'Children');
    for i = 1:length(FigureHandle)
        if strcmp(FigureHandle(i).Name,'Status')
            FigureHandle = FigureHandle(i);
            break
        end
    end
    stt.f(1) = FigureHandle;
    typeChildren = {'button','textarea','label','table','buttongroup'};
    buttonText = {'Set area region','Area calculation','DONE'};
    labelText = {'Target  ','Max area','Or inser','of ExpNo','Referenc'};
    textareaPosition = [213;284;375];
    for i = 1:length(stt.f(1).Children)
        c = class(stt.f(1).Children(i));
        c = split(c,'.'); c = c(end);
        [~,a] = ismember(lower(c),typeChildren);
        if a==1 % children is a button
            t = {stt.f(1).Children(i).Text};
            [~,b] = ismember(t,buttonText);
            stt.button(b) = stt.f(1).Children(i);
        elseif a==2 % children is a textarea
            p = stt.f(1).Children(i).Position(1);
            [~,b] = ismember(p,textareaPosition);
            stt.uitextarea(b) = stt.f(1).Children(i);
        elseif a==3 % children is a label
            t = {stt.f(1).Children(i).Text};
            [~,b] = ismember({t{1}{1}(1:8)},labelText);
            stt.text(b) = stt.f(1).Children(i);
        elseif a==4 % children is a table
            stt.uit = stt.f(1).Children(i);
        elseif a==5 % children is a buttongroup
            stt.radiobuttonGroup(1) = stt.f(1).Children(i);
            subChild = stt.f(1).Children(i).Children;
            for j = 1:length(subChild)
                if strcmp(subChild(j).Text,'Target')
                    stt.radiobutton(1) = subChild(j);
                elseif strcmp(subChild(j).Text,'Reference')
                    stt.radiobutton(2) = subChild(j);
                end
            end
        end
    end
    smoothly = 0;
end
selectedCell = event.Indices;
newExp2Plot = double(stt.uit.Data.ExpNo{selectedCell(1)});
newExp2Plot_ind = selectedCell(1);
e = newExp2Plot;
ee = stt.uit.Data.Experiment{selectedCell(1)};
eee = stt.uit.Data.Title(selectedCell(1));
tt = ['Exp n� ' num2str(e) ' - ' ee];
if smoothly
    if ~cell2mat(h.status.errorR(newExp2Plot_ind))
        h.status.uitextarea(3).Value = {num2str(e)};
        if ismember({'plt'},fieldnames(stt))
            go = 1;
            for i = 1:length(stt.plt)
                if ~isvalid(stt.plt(i).plt{1,2})
                    isDeleted(i) = 1; %#ok<AGROW>
                else
                    isDeleted(i) = 0; %#ok<AGROW>
                end
            end
            for i = 1:length(stt.plt)
                if ~isDeleted(i)
                    if ismember(stt.plt(i).plt{1,2}.Children(1).String(1),eee)
                        if ismember({stt.plt(i).plt{1,2}.Children(2).Title.String},{tt})
                            go = 0;
                            break
                        end
                    end
                end
            end
            if ~go
                figure(stt.plt(i).plt{1,2}.Number)
                fprintf(['\n' tt ' is already plotted. Here it is ...\n'])
            else
                % Tr = plot_after_status_update(status,newExp2Plot,newExp2Plot_ind);
                ind = size(stt.plt,2)+1;
                stt.plt(ind).Time = stt.T;
                fprintf(['\n Exp ' num2str(newExp2Plot) ' is being transferred...'])
                stt.plt(ind).plt = plot_after_status_update(stt,newExp2Plot,newExp2Plot_ind);
                fprintf('DONE.\n')
                fprintf(['\n' tt ' is plotted.\n'])
                % Showing the region bounds
                %             bound1 = deblank(cell2mat(h.status.uitextarea(1).Value)); % region's lower bound
                %             bound2 = deblank(cell2mat(h.status.uitextarea(2).Value)); % region's larger bound
                %             bound1 = str2double(bound1);
                %             bound2 = str2double(bound2);
                %             if ~isempty(bound1) && ~isempty(bound2)
                %                 hold on
                %                 xline(bound1,'HandleVisibility','off')
                %                 xline(bound2,'HandleVisibility','off')
                %                 hold off
                %             end
            end
            go = 1;
            while go
                isDeleted = [];
                for i = 1:length(stt.plt)
                    if ~isvalid(stt.plt(i).plt{1,2})
                        isDeleted(i) = 1; %#ok<AGROW>
                    else
                        isDeleted(i) = 0; %#ok<AGROW>
                    end
                end
                if find(isDeleted,1)
                    stt.plt(find(isDeleted,1)) = [];
                    go = 1;
                else
                    go = 0;
                end
            end
        else
            stt.plt(1).Time = stt.T;
            fprintf(['\n Exp ' num2str(newExp2Plot) ' is being transferred...'])
            stt.plt(1).plt = plot_after_status_update(stt,newExp2Plot,newExp2Plot_ind);
            fprintf('DONE.\n')
            fprintf(['\n' tt ' is plotted.\n'])
            % Showing the region bounds
            %         bound1 = deblank(cell2mat(h.status.uitextarea(1).Value)); % region's lower bound
            %         bound2 = deblank(cell2mat(h.status.uitextarea(2).Value)); % region's larger bound
            %         bound1 = str2double(bound1);
            %         bound2 = str2double(bound2);
            %         if ~isempty(bound1) && ~isempty(bound2)
            %             hold on
            %             xline(bound1,'HandleVisibility','off')
            %             xline(bound2,'HandleVisibility','off')
            %             hold off
            %         end
        end
        movegui(gcf,'center');
        drawnow
    else
        fprintf(['\n' tt ' cannot be plotted. Error during acquisition.\n'])
    end
    h.status = stt;
else
    stt.uitextarea(3).Value = {num2str(e)};
    if ismember({'plt'},fieldnames(stt))
        go = 1;
        for i = 1:length(stt.plt)
            if ~isvalid(stt.plt(i).plt{1,2})
                isDeleted(i) = 1; %#ok<AGROW>
            else
                isDeleted(i) = 0; %#ok<AGROW>
            end
        end
        for i = 1:length(stt.plt)
            if ~isDeleted(i)
                if ismember(stt.plt(i).plt{1,2}.Children(1).String(1),eee)
                    if ismember({stt.plt(i).plt{1,2}.Children(2).Title.String},{tt})
                        go = 0;
                        break
                    end
                end
            end
        end
        if ~go
            figure(stt.plt(i).plt{1,2}.Number)
            fprintf(['\n' tt ' is already plotted. Here it is ...\n'])
        else
            % Tr = plot_after_status_update(status,newExp2Plot,newExp2Plot_ind);
            ind = size(stt.plt,2)+1;
            stt.plt(ind).Time = stt.T;
            fprintf(['\n Exp ' num2str(newExp2Plot) ' is being transferred...'])
            stt.plt(ind).plt = plot_after_status_update(stt,newExp2Plot,newExp2Plot_ind);
            fprintf('DONE.\n')
            fprintf(['\n' tt ' is plotted.\n'])
        end
        go = 1;
        while go
            isDeleted = [];
            for i = 1:length(stt.plt)
                if ~isvalid(stt.plt(i).plt{1,2})
                    isDeleted(i) = 1; %#ok<AGROW>
                else
                    isDeleted(i) = 0; %#ok<AGROW>
                end
            end
            if find(isDeleted,1)
                stt.plt(find(isDeleted,1)) = [];
                go = 1;
            else
                go = 0;
            end
        end
    else
        stt.name = stt.uit.Data.Date{newExp2Plot_ind};
        fprintf(['\n Exp ' num2str(newExp2Plot) ' is being transferred...'])
        stt.plt(1).plt = plot_after_status_update(stt,newExp2Plot,newExp2Plot_ind); %#ok<STRNU>
        fprintf('DONE.\n')
        fprintf(['\n' tt ' is plotted.\n'])
    end
    movegui(gcf,'center');
    drawnow
end
end
% Area region set from the completed experiments
function setAreaRegion(varargin)
global h
whichRegion = h.status.radiobuttonGroup(1).SelectedObject.Text;
if strcmp(whichRegion,'Target')
    target_exp = str2double(h.status.uitextarea(3).Value{1});
    if isnan(target_exp)
        target_set = 0;
    else
        if ismember(target_exp,cell2mat(h.status.uit.Data.ExpNo))
            target_set = 1;
            [~,target_exp_ind] = ismember(target_exp,cell2mat(h.status.uit.Data.ExpNo));
        else
            target_set = 0;
        end
    end
    [h.AreaRegion,h.AreaValue,ExpInd] = region_area2(h);
    h.status.text(1).Text = {['Target       : [ ' num2str(round(h.AreaRegion(1),2))...
        ' ppm , ' num2str(round(h.AreaRegion(2),2)) ' ppm ]']};
    h.area.editable_text_field(1).String = num2str(h.AreaRegion(1));
    h.area.editable_text_field(2).String = num2str(h.AreaRegion(2));
    AreaRegionInsert    
    h.area.AreaRegion = h.AreaRegion;
    h.status.uit.Data.Area(ExpInd) = h.AreaValue;
    if ~isempty(h.AreaRegion2)
        h.status.uit.Data.RelativeArea(ExpInd) = num2cell((cell2mat(h.AreaValue)./cell2mat(h.AreaValue2(ExpInd))));
    end
    ind = max(cell2mat(h.AreaValue))==cell2mat(h.AreaValue);
    indx = ExpInd(max(cell2mat(h.AreaValue))==cell2mat(h.AreaValue));
    h.status.text(2).Text = {['Max area is for exp� ' ...
        num2str(h.status.uit.Data.ExpNo{indx}) ' : ' num2str(h.AreaValue{ind})]};
    % h.status.button(2).Enable = 'on';
    h.status.table.Area = h.status.uit.Data.Area;
    h.status.table.RelativeArea = h.status.uit.Data.RelativeArea;
    if target_set
        %     h.status.uitextarea(3).Value = {' '};
        a = h.status.uit.Data.Running;
        ind = [];
        for i = 1:length(a)
            if isempty(h.status.uit.Data.Running{i})
                ind = [ind i]; %#ok<AGROW>
            end
        end
        [~,b] = ismember(cell2mat(h.status.st(:,5)),1);
        notDeleted_experiments = find(~b);
        DoOnly = intersect(ind,notDeleted_experiments);
        DoOnly = setdiff(DoOnly,target_exp_ind);
        if ~isempty(DoOnly)
            [h.AreaRegion,h.AreaValue,ExpInd] = region_area2(h,h.AreaRegion,DoOnly);
            if ~isempty(ExpInd)
                h.status.text(1).Text = {['Target       : [ ' num2str(round(h.AreaRegion(1),2))...
                    ' ppm , ' num2str(round(h.AreaRegion(2),2)) ' ppm ]']};
                h.status.uit.Data.Area(ExpInd) = h.AreaValue;
                if ~isempty(h.AreaRegion2)
                    h.status.uit.Data.RelativeArea(ExpInd) = num2cell((cell2mat(h.AreaValue)./cell2mat(h.AreaValue2(ExpInd))));
                end
                ind = find(max(cell2mat(h.AreaValue))==cell2mat(h.AreaValue));
                ind = ind(1);
                h.status.text(2).Text = {['Max area is for exp� ' num2str(h.status.uit.Data.ExpNo{ind}) ' : ' num2str(h.AreaValue{ind})]};
                h.status.table.Area = h.status.uit.Data.Area;
                h.status.table.RelativeArea = h.status.uit.Data.RelativeArea;
                if ~isempty(h.AreaRegion)%h.area.regionInsert==1
                    h.area.AreaRegion = h.AreaRegion;
                    h.area.editable_text_field(1).String = num2str(h.AreaRegion(1));
                    h.area.editable_text_field(2).String = num2str(h.AreaRegion(2));
                    AreaRegionInsert
                end
            end
        end
    end
    getAreaValue
elseif strcmp(whichRegion,'Reference')
    [h.AreaRegion2,h.AreaValue2,~] = region_area2(h);
    h.status.text(5).Text = {['Reference: [ ' num2str(round(h.AreaRegion2(1),2))...
        ' ppm , ' num2str(round(h.AreaRegion2(2),2)) ' ppm ]']};
    h.area.regionInsert2 = 1;
    h.area.AreaRegion2 = h.AreaRegion2;
    h.regionInsert2 = 1;
    if h.area.regionInsert2==1
        h.area.AreaRegion2 = h.AreaRegion2;
        h.area.editable_text_field(3).String = num2str(h.AreaRegion2(1));
        h.area.editable_text_field(4).String = num2str(h.AreaRegion2(2));
        AreaRegionInsert2
    end
    getAreaValue
end
end
% Insert Area region bounds 
function insertAreaRegion(varargin)
global h
whichRegion = h.status.radiobuttonGroup(1).SelectedObject.Text;
bound1 = deblank(cell2mat(h.status.uitextarea(1).Value));
bound2 = deblank(cell2mat(h.status.uitextarea(2).Value));
bound1 = str2double(bound1);
bound2 = str2double(bound2);
if strcmp(whichRegion,'Target')
    if ~isempty(bound1) && ~isempty(bound2)
        if isnan(bound1) || isnan(bound2)
            h.regionInsert = 0;
            if isnan(bound1)
                h.status.uitextarea(1).Value = {' '};
            end
            if isnan(bound2)
                h.status.uitextarea(2).Value = {' '};
            end
        else
            if (bound1==bound2)
                h.regionInsert = 0;
                h.status.uitextarea(2).Value = {' '};
            else
                if(bound1>bound2)
                    h.regionInsert = 0;
                    h.status.uitextarea(2).Value = {' '};
                else
                    h.AreaRegion = [bound1,bound2];
                    h.regionInsert = 1;
                    h.regionInsert2 = 1;
                    if ~isempty(h.AreaRegion)
                        h.area.AreaRegion = h.AreaRegion;
                        h.area.editable_text_field(1).String = num2str(h.AreaRegion(1));
                        h.area.editable_text_field(2).String = num2str(h.AreaRegion(2));
                        h.status.text(1).Text = {['Target       : [ '...
                            num2str(round(h.AreaRegion(1),2)) ' ppm , '...
                            num2str(round(h.AreaRegion(2),2)) ' ppm ]']};
                        AreaRegionInsert
                    end
                end
            end
        end
    else
        h.regionInsert = 0;
    end
elseif strcmp(whichRegion,'Reference')
    if ~isempty(bound1) && ~isempty(bound2)
        if isnan(bound1) || isnan(bound2)
            h.regionInsert2 = 0;
            if isnan(bound1)
                h.status.uitextarea(1).Value = {' '};
            end
            if isnan(bound2)
                h.status.uitextarea(2).Value = {' '};
            end
        else
            if (bound1==bound2)
                h.regionInsert2 = 0;
                h.status.uitextarea(2).Value = {' '};
            else
                if(bound1>bound2)
                    h.regionInsert2 = 0;
                    h.status.uitextarea(2).Value = {' '};
                else
                    h.AreaRegion2 = [bound1,bound2];
                    h.regionInsert = 1;
                    h.regionInsert2 = 1;
                    if ~isempty(h.AreaRegion2)
                        h.area.AreaRegion2 = h.AreaRegion2;
                        h.area.editable_text_field(3).String = num2str(h.AreaRegion2(1));
                        h.area.editable_text_field(4).String = num2str(h.AreaRegion2(2));
                        h.status.text(5).Text = {['Reference: [ '...
                            num2str(round(h.AreaRegion2(1),2)) ' ppm , '...
                            num2str(round(h.AreaRegion2(2),2)) ' ppm ]']};
                        AreaRegionInsert2
                    end
                end
            end
        end
    else
        h.regionInsert2 = 0;
    end
end
end
% Get area value of the completed experiments
function getAreaValue(varargin)
global h
fprintf('\n\nAreas are being checked\n\n...\n\n')
a = h.status.uit.Data.Area;
b = 1;
if h.autoMode
    AreaRegion = h.area.AreaRegion;
    regionInsert = h.area.regionInsert;
    AreaRegion2 = h.area.AreaRegion2;
    regionInsert2 = h.area.regionInsert2;
else
    AreaRegion = h.AreaRegion;
    regionInsert = h.regionInsert;
    AreaRegion2 = h.AreaRegion2;
    regionInsert2 = h.regionInsert2;
end
for i = 1:length(a)
    if isempty(a{i})
        b = 0;
        break
    else
        if a{i}==0
            if isempty(h.status.uit.Data.Running{i})
                indA = i;
                b = 0;
                break
            end
        end
    end
end
if ~isempty(AreaRegion2)
    indA = 1:length(a);
end
if (~b || regionInsert==1 || regionInsert2)
    if ~isempty(AreaRegion)
        c = h.status.uit.Data.Running;
        ind = [];
        for i = 1:length(c)
            if isempty(h.status.uit.Data.Running{i})
                ind = [ind i]; %#ok<AGROW>
            end
        end
        [~,c] = ismember(cell2mat(h.status.st(:,5)),1);
        notDeleted_experiments = find(~c);
        if regionInsert==1
            DoOnly = intersect(ind,1:length(a));
            DoOnly = intersect(DoOnly,notDeleted_experiments);
        else
            DoOnly = intersect(ind,indA:length(a));
        end
        %% Get Peak Areas
        if h.TSarea==1
            % Get the area values calculated by TopSpin
%             expList = double(cell2mat(h.status.uit.Data.ExpNo(DoOnly)));
            expList = h.Experiment_Table.ExpNo(2:end);
            FileName = h.status.uit.Data.Date{DoOnly(1)};
            datasetPath = '/opt/nmrdata/user/nmr/Nour';
            % Prepare outd file to avoid errors
%             outd4NewProcessing(FileName,datasetPath,expList);
%             clc;error('Stop right there ! line(4805)')

            % Ask TopSpin for new processing
            % changes
            [Areas,AreaRegions,expAreaFound,~] = get_area_values_from_spectro500...
                (FileName,datasetPath,expList,1);
%             [Areas,~,expAreaFound,~] = get_area_values_from_spectro500...
%                 (FileName,datasetPath,expList,1);
            % Target peak
            h.AreaValue = Areas(:,h.ind_target);
            if isfield(h,'AreaRegion')
                checkregions = 0;
            else
                checkregions = 1;
            end
            if checkregions
                h.AreaRegion = AreaRegions(1,2*h.ind_target-1:2*h.ind_target);
            end
            % Reference peak
            h.AreaValue2 = Areas(:,h.ind_reference);
            if checkregions
                h.AreaRegion2 = AreaRegions(1,2*h.ind_reference-1:2*h.ind_reference);
            end
            % Additional peaks, if requested
            AreaAdditRequested = 0;
            if size(Areas,2)>2
                AreaAdditRequested = 1;
                ind = find(~ismember(1:size(Areas,2),[h.ind_target,...
                    h.ind_reference]));
                h.AreaValueAddit = Areas(:,~ismember(1:size(Areas,2),...
                    [h.ind_target,h.ind_reference]));
                if checkregions
                    h.AreaValueAdditRegion = [];
                    for i = 1:length(ind)
                        h.AreaValueAdditRegion = [h.AreaValueAdditRegion;...
                            AreaRegions(2*ind(i)-1:2*ind(i))];
                    end
                end
            end
            ExpInd = find(ismember(double(cell2mat(h.status.uit.Data.ExpNo)),expAreaFound));
        else
            % Target peak
            [h.AreaRegion,h.AreaValue,ExpInd] = region_area2(h,AreaRegion,DoOnly); % varargin = {h.AreaRegion,DoOnly};
            % Reference peak
            if ~isempty(AreaRegion2)
                [h.AreaRegion2,h.AreaValue2,~] = region_area2(h,AreaRegion2,DoOnly,1); % varargin = {h.AreaRegion2,DoOnly};
            end
        end
        %% Fill values
        if ~isempty(ExpInd)
%             if
            h.status.text(1).Text = {['Target       : [ ' num2str(round(h.AreaRegion(1),2))...
                ' ppm , ' num2str(round(h.AreaRegion(2),2)) ' ppm ]']};
            if ~isempty(h.AreaRegion2)
                h.status.text(5).Text = {['Reference: [ ' num2str(round(h.AreaRegion2(1),2))...
                    ' ppm , ' num2str(round(h.AreaRegion2(2),2)) ' ppm ]']};
            end
            if h.TSarea==1
                h.status.uit.Data.Area(ExpInd) = num2cell(h.AreaValue);
                if AreaAdditRequested
                    % Additional peaks, other than the target and reference
                    % => hence nesttable 
                    h.status.uit.Data.AdditionalArea(ExpInd,:) = num2cell(h.AreaValueAddit);
                end
                if ~isempty(h.AreaRegion2)
                    h.status.uit.Data.RelativeArea(ExpInd) = ...
                        num2cell(h.AreaValue./h.AreaValue2);
                    if AreaAdditRequested
                        h.status.uit.Data.RelativeAdditionalArea(ExpInd,:) = ...
                            num2cell(h.AreaValueAddit./h.AreaValue2);
                    end
                end
            else
                h.status.uit.Data.Area(ExpInd) = h.AreaValue;
                if ~isempty(AreaRegion2)
                    h.status.uit.Data.RelativeArea(ExpInd) = ...
                        num2cell((cell2mat(h.AreaValue)./cell2mat(h.AreaValue2)));
                end
            end
            if isempty(AreaRegion2)
                ind = find(max(cell2mat(h.status.uit.Data.Area))==...
                    cell2mat(h.status.uit.Data.Area));
                ind = ind(1);
                h.status.text(2).Text = {['Max area is for exp� ' ...
                    num2str(h.status.uit.Data.ExpNo{ind}) ' : ' ...
                    num2str(round(h.status.uit.Data.Area{ind},4))]};
            else
                ind = find(max(cell2mat(h.status.uit.Data.RelativeArea))==...
                    cell2mat(h.status.uit.Data.RelativeArea));
                ind = ind(1);
                h.status.text(2).Text = {['Max area is for exp� ' ...
                    num2str(h.status.uit.Data.ExpNo{ind}) ' : ' ...
                    num2str(round(h.status.uit.Data.RelativeArea{ind},4))]};
            end
            h.status.table.Area = h.status.uit.Data.Area;
            h.status.table.AdditionalArea = h.status.uit.Data.AdditionalArea;
            h.status.table.RelativeArea = h.status.uit.Data.RelativeArea;
            h.status.table.RelativeAdditionalArea = h.status.uit.Data.RelativeAdditionalArea;
            if ~isempty(AreaRegion)
                h.area.editable_text_field(1).String = num2str(h.AreaRegion(1));
                h.area.editable_text_field(2).String = num2str(h.AreaRegion(2));
                AreaRegionInsert
            end
            if ~isempty(AreaRegion2)
                h.area.editable_text_field(3).String = num2str(h.AreaRegion2(1));
                h.area.editable_text_field(4).String = num2str(h.AreaRegion2(2));
                AreaRegionInsert2
            end
            h.regionInsert = 0;
            h.regionInsert2 = 0;
            h.status.uitextarea(1).Value = {' '};
            h.status.uitextarea(2).Value = {' '};
            % Dialog print
            fprintf('\nArea(s) has(ve) been calculated.\n')
        end
    else
        h.regionInsert = 0;
        % Dialog print
        fprintf('\nRegion bounds are not set. Please set or insert them again.\n')
    end
else
    % Dialog print
    fprintf('\nArea(s) already been calculated for available spectra.')
end
end
% Experiment and analysis termination
function termination(varargin)
global h hh
if ~isempty(h.status)
    % User's Choice :  termination?
    opts.Interpreter = 'tex';
    opts.Default = 'No';
    quest = 'Are you sure you would you like to terminate the application?';
    
    % Dialog print
    fprintf('\n[ ? ] Close the application?\n')
    
    answer0 = questdlg(quest,'Termination',...
        'Yes','No',opts);
    switch answer0
        case 'Yes'
            go = 1;
            fprintf('Finishing...\n')
        case 'No'
            go = 0;
            fprintf('Continuing...\n')
    end
    quickExit = 0;
else
    go = 1;
    quickExit = 1;
end
if go==1
    % NES: the next 3 lines are commented to prevent saving handles when
    % terminating the application, even if it was not already done
    % (h.autoModeSAve=0). This is to not auto save without the user's demand. 
%     if h.autoModeSAve==0
%         saveH
%     end
    if h.running==1
        callback17 % STOP button callback
    end
    [h,hh] = disable_entries(h,hh,1);
    if quickExit==0
        h.status.button(1).Enable = 'off'; %Set area region
        h.status.button(2).Enable = 'off'; %Area calculation
        h.status.uitextarea(1).Enable = 'off'; % region's lower bound
        h.status.uitextarea(2).Enable = 'off'; % region's larger bound
        h.status.uitextarea(3).Enable = 'off'; % exp number for region bounds set
        h.status.button(3).Enable = 'off'; %DONE
%         savefig(h.status.f,'autoModeHandles_fig_screenX.fig')
    end
    % Report
    writeFinishingReport
    set(h.f(1),'CloseRequestFcn','closereq'); % default function
    if h.userExpListSelection==0
        if isfield(h.status,'F')
            % The status window contains tabs
            set(h.status.F,'CloseRequestFcn','closereq'); % default function
        else
            set(h.status.f(1),'CloseRequestFcn','closereq'); % default function
        end
        fprintf('\nclosing...\n')
        close all
    else
        delete(h.f(1))
        if isfield(hh.calendar,'f')
            for i = 1:length(hh.calendar.f)
                hh.calendar.f(i).Visible = 'on';
                delete(hh.calendar.f(i))
            end
        end
    end
end
end
% Termination report
function writeFinishingReport(varargin)
global h
if isempty(h.status)
    % Output results
    h.AreaResults = NaN; % instead of [] to recognize it from an error run
    return
end
if h.autoMode==0
    % User's Choice :  Excel or Text file?
    opts.Interpreter = 'tex';
    opts.Default = 'Text';
    quest = 'In which format would you like to save the report?';
    
    % Dialog print
    fprintf('\n[ ? ] Excel or Text file?\n')
    
    answer0 = questdlg(quest,'Output',...
        'Excel','Text',opts);
else
    answer0 = 'Text';
end
switch answer0
    case 'Excel'
        excel = 1;
        fprintf('\nOutput results into an excel Sheet...\n')
    case 'Text'
        excel = 0;
        fprintf('\nOutput results into a text file...\n')
end

% Prepare the results table
T = h.status.uit.Data;
T.Available(:) = h.status.st(:,1);
T.Submitted(:) = h.status.st(:,2);
T.Running(:) = h.status.st(:,3);
T.Completed(:) = h.status.st(:,4);
T.Deleted(:) =  h.status.st(:,5);
Status_text = {'Available','Submitted','Running','Completed','Deleted','Error'};
Status = cell(size(T,1),1);
for i = 1:size(T,1)
    ind = find(cell2mat(table2array(T(i,7:11))),1,'last');
    if ~isempty(ind)
        Status(i,1) = Status_text(ind);
    else
        Status(i,1) = Status_text(end);
    end
end
T = [T,table(Status)];
% Output results
h.AreaResults = T(:,[3,12,13,14,15]);return
if h.DontStartRunning
    % Output results
    h.AreaResults = T(:,[3,12,13]);
    return
end

% Make a copy of the default file
reportsPath = 'C:\Users\elsabbagh-n\Documents\DataSet\Interface Reports\';
Date = datetime(h.fileName(1:10),'Format','MMMdd-yyyy');Date.Format = 'dd-MM-yyyy';
Time = datetime(h.fileName(12:15),'Format','HHmm');Time.Format = 'HH''h''mm';
User = h.fileName(17:end-4);

% File Name
if excel==1
    filename = [reportsPath 'Report of ' char(Date) '.xlsx'];
else
    if h.autoMode==0
        filename = [reportsPath 'Report of ' char(Date) '.txt'];
    else
        if h.cont==0
            filename = [reportsPath 'Report of ' char(Date) '.txt'];
            h.textfilename = filename;
        else
            filename = h.textfilename;
        end
    end
end

if excel==1
    % Name of the worksheet
    SheetName = [User ' @ ' char(Time)];
    
    if ~isfile(filename)
        % Copy the default file
        copyfile([reportsPath 'Default.xlsx'],filename)
        % Write the data in the copied file
        writetable(T(:,[1:6,14,12,13]),filename,'Sheet',1,'PreserveFormat',true)
        writematrix(h.status.text(1).Text{1}(16:end),filename,'Sheet',1,'Range','J2','PreserveFormat',true)
        writematrix(h.status.text(5).Text{1}(12:end),filename,'Sheet',1,'Range','K2','PreserveFormat',true)
        % No new sheet needed
        newSheet = 0;
        % No overwriting
        overwiting = 0;
    else
        % New sheet needed
        newSheet = 1;
        % Sheets name list
        sheets = sheetnames(filename);
        
        if ismember({SheetName},cellstr(sheets))
            % User's Choice :  Overwrite?
            opts.Interpreter = 'tex';
            opts.Default = 'No';
            quest = {'A worksheet with the same label already exists.',...
                'Would you like to overwrite it?'};
            
            % Dialog print
            fprintf('\n[ ? ] Overwrite report?\n')
            
            answer0 = questdlg(quest,'Overwrite',...
                'Yes','No',opts);
            switch answer0
                case 'Yes'
                    overwiting = 1;
                case 'No'
                    overwiting = 0;
            end
            if ~overwiting
                n = 1;
                SheetName_mod = SheetName;
                while ismember({SheetName_mod},cellstr(char(sheets)))
                    SheetName_mod = [SheetName ' (' num2str(n) ')'];
                    n = n+1;
                end
                SheetName = SheetName_mod;
            end
        end
    end
    
    % Open application
    hExcel = actxserver('Excel.Application');
    hExcel.DisplayAlerts = false;
    
    % Make the application visible
    % hExcel.Visible = 1;
    
    % Choose excel file
    hWorkbook = hExcel.Workbooks.Open(filename);
    
    if overwiting
        % When overwriting, delete the old worksheet before
        hWorkbook.Sheets.Item(SheetName).Delete;
    end
    
    % Copy default Sheet
    if newSheet
        %Get the list of sheets
        eSheets = hExcel.ActiveWorkbook.Sheets;
        % Get the default sheet which is stored at the end
        eSheet1 = eSheets.get('Item',sheets(end));
        % Make the default sheet activated to be copied
        eSheet1.Activate
        % Copy the activated sheet and place the new one before it
        hExcel.ActiveWorkbook.ActiveSheet.Copy(hExcel.ActiveWorkbook.ActiveSheet,[]);
    end
    
    % Rename the worksheet
    hExcel.ActiveWorkbook.ActiveSheet.Name = SheetName;
    
    if ~newSheet
        % Adjust cell format
        hWorksheet = hWorkbook.Sheets.Item(SheetName);
        for i = 1:9
            hWorksheet.Columns.Item(i).columnWidth = 20; %i^th column
        end
    end
    
    % Save and close excel file
    hWorkbook.Save
    hWorkbook.Close
    
    if newSheet
        % Write data
        writetable(T(:,[1:6,14,12,13]),filename,'Sheet',SheetName,'PreserveFormat',true)
        writematrix(h.status.text(1).Text{1}(16:end),filename,'Sheet',SheetName,'Range','J2','PreserveFormat',true)
        
        % Read again to adjust cell format
        hWorkbook = hExcel.Workbooks.Open(filename);
        % Adjust cell format
        hWorksheet = hWorkbook.Sheets.Item(SheetName);
        for i = 1:9
            hWorksheet.Columns.Item(i).columnWidth = 20; %i^th column
        end
        
        % Save and close excel file
        hWorkbook.Save
        hWorkbook.Close
    end
    
    % Quit application
    hExcel.Quit
    delete(hExcel)
else
    if isfile(filename)
        if h.autoMode==0
            % User's Choice :  Overwrite?
            opts.Interpreter = 'tex';
            opts.Default = 'No';
            quest = {'A text file with the same name already exists.',...
                'Would you like to overwrite it?'};
            
            % Dialog print
            fprintf('\n[ ? ] Overwrite report?\n')
            
            answer0 = questdlg(quest,'Overwrite',...
                'Yes','No',opts);
            switch answer0
                case 'Yes'
                    overwiting = 1;
                case 'No'
                    overwiting = 0;
            end
        else
            if h.cont==0
                overwiting = 0;
            else
                overwiting = 1;
            end
            overwiting = 1;
            if h.untilAreaMax
                continueWriting = 0;
            else
                if (length(h.archive)/(size(h.Experiment_Table,1)-1))==1
                    continueWriting = 0;
                else
                    continueWriting = 1;
                end
            end
        end
        if ~overwiting
            n = 1;
            filename_mod = filename;
            while isfile(filename_mod)
                filename_mod = [filename(1:end-4) ' (' num2str(n) ').txt'];
                n = n+1;
            end
            filename = filename_mod;
            h.textfilename = filename;
        end
    else
        if h.autoMode==1
            continueWriting = 0;
        end
    end
    
    % Write data
    if h.autoMode==0
        writetable(T(:,[1:6,14,12,13]),filename,'Delimiter','tab');
        fId = fopen(filename,'a');
        fprintf(fId,['\n\n Selected Bounds:\n' h.status.text(1).Text{1}(16:end)]);
        fprintf(fId,['\n\n Reference Bounds:\n' h.status.text(5).Text{1}(12:end)]);
        fclose(fId);
    else
        if continueWriting==0
            writetable(T(:,[1:6,16,12,13,14,15]),filename,'Delimiter','tab');
            fId = fopen(filename,'r');
            f = string(fgetl(fId));
            tline = '\n';
            while f~='-1' %#ok<BDSCA>
                tline = [tline,'\n',f]; %#ok<AGROW>
                f = string(fgetl(fId));
            end
            fclose(fId);
            tlineN = char(join(tline,''));
            fId = fopen(filename,'w');
            if isfield(h,'AreaValueAddit')
                str = [];
                for i = 1:size(h.AreaValueAddit,2)
                    str = [str '\n[ ' num2str(h.AreaValueAdditRegion(i,1)) ...
                        ' ppm , ' num2str(h.AreaValueAdditRegion(i,2))...
                        ' ppm ]']; %#ok<AGROW>
                end
                boundText = ['Selected Bounds:\n' h.status.text(1).Text{1}(16:end)...
                    '\nReference Bounds:\n' h.status.text(5).Text{1}(12:end)...
                    '\nAdditionl Bounds:' str tlineN];
            else
                boundText = ['Selected Bounds:\n' h.status.text(1).Text{1}(16:end)...
                    '\nReference Bounds:\n' h.status.text(5).Text{1}(12:end) tlineN];
            end
            fprintf(fId,boundText);
            fclose(fId);
        else
            fId = fopen(filename,'r+');
            f = string(fgetl(fId));
            b = 1;
            while f~='-1' %#ok<BDSCA>
                if contains(f,' ppm ]')
                    if b==1
                        bounds = f;
                        b = b+1;
                    end
                end
                f = string(fgetl(fId));
            end
            if exist('bounds','var')
                old = cell2mat(textscan(char(bounds),'[ %f ppm , %f ppm ]'));
                new = cell2mat(textscan(h.status.text(1).Text{1}(16:end),'[ %f ppm , %f ppm ]'));
            else
                old = 1;
                new = 1;
            end
            if isequal(old,new)
                textt = '';
                [~,d] = ismember(h.Experiment_Table.ExpNo(2:end),cell2mat(T.ExpNo));
                TT = table2cell(T(d,[1:6,14,12,13]));
                for j = 1:size(TT,1)
                    for i = 1:size(TT,2)
                        if isnumeric(TT{j,i})
                            if i==1
                                textt = [textt '\n' num2str(TT{j,i})]; %#ok<AGROW>
                            else
                                textt = [textt '\t' num2str(TT{j,i})]; %#ok<AGROW>
                            end
                        else
                            if i==1
                                textt = [textt '\n' TT{j,i}]; %#ok<AGROW>
                            else
                                textt = [textt '\t' TT{j,i}]; %#ok<AGROW>
                            end
                        end
                    end
                end
                textt(2) = 'n';
            else
                textt = '';
                TT = table2cell(T(:,[1:6,14,12,13]));
                for j = 1:size(TT,1)
                    for i = 1:size(TT,2)
                        if isnumeric(TT{j,i})
                            if i==1
                                textt = [textt '\n' num2str(TT{j,i})]; %#ok<AGROW>
                            else
                                textt = [textt '\t' num2str(TT{j,i})]; %#ok<AGROW>
                            end
                        else
                            if i==1
                                textt = [textt '\n' TT{j,i}]; %#ok<AGROW>
                            else
                                textt = [textt '\t' TT{j,i}]; %#ok<AGROW>
                            end
                        end
                    end
                end
                textt(2) = 'n';
                textt = ['\n\nSelected Bounds:\n' h.status.text(1).Text{1}(16:end)...
                '\nReference Bounds:\n' h.status.text(5).Text{1}(12:end) '\n' textt];
            end
            fprintf(fId,textt);
            fclose(fId);
        end
    end
end

% Output results
h.AreaResults = T(:,[3,12,13,14,15]);

if h.test==0
    % Change the name of the status file in IconNMR path in case of another
    % flow beginning
    old = h.fileName;
    statusPath = '/opt/topspin3.6.2/prog/curdir/changer';
    change_FileName_on_spectro500(statusPath,old,[])
end

% Last display
disp(T(:,[1:6,14,12,13,14,15]))
fprintf(['Selected Bounds:\n' h.status.text(1).Text{1}(16:end) '\n'])
fprintf(['Reference Bounds:\n' h.status.text(5).Text{1}(12:end) '\n'])

if excel==1
    fprintf(['\nThese results are stored in the worksheet labelled <' SheetName '>, from the excel file <' replace(filename,'\','\\') '>.\n'])
else
    [filepath,name,ext] = fileparts(filename);
    fprintf(['\nThese results are stored in the text file named <' [name,ext] '>, placed in <' replace(filepath,'\','\\') '>.\n'])
end
end
% Close windows warnings
function closeWarning(hObject, ~, ~)
global h hh
% closeWarning(hObject, eventdata, handles)
% hObject is the figure handles
% eventdata :  source is the figure and the EventName is 'Close'
% User's Choice :  real experiment?
opts.Interpreter = 'tex';
opts.Default = 'No';
closeBoth = 0;
if ismember({'fileName'},fieldnames(h))
    if isfield(h.status,'f')
        if ishandle(h.status.f(1))
            quest = {'Closing this window may cause errors if application is being used.',...
                'Use the button ''DONE'' of the Status window if finished with the application.','Close anyway?'};
            if isfield(h.status,'F')
                % The status window contains tabs
                figure(h.status.F)
            else
                figure(h.status.f(1))
            end
            if ~strcmp(hObject.Name,'Status')
                closeBoth = 1;
            end
        else
            quest = {'Closing this window may cause errors if application is being used.',...
                'Close anyway?'};
        end
    else
        quest = {'Closing this window may cause errors if application is being used.',...
            'Close anyway?'};
    end
else
    quest = {'Closing this window may cause errors if application is being used.',...
        'Close anyway?'};
end
% Dialog print
fprintf('\n[ ? ] Close status window?\n')

answer0 = questdlg(quest,'Close window?',...
    'Yes','No',opts);
switch answer0
    case 'Yes'
        fprintf('\nClosing it...')
        delete(hObject)
        if closeBoth
            if isfield(h.status,'F')
                % The status window contains tabs
                delete(h.status.F)
            else
                delete(h.status.f(1))
            end
        else
            if isfield(hh.calendar,'f')
                for i = 1:length(hh.calendar.f)
                    try
                    hh.calendar.f(i).Visible = 'on';
                    delete(hh.calendar.f(i))
                    catch 
                    end
                end
            end
        end
        fprintf(' Done.\n')
    case 'No'
        fprintf('\nKeeping it.\n')
        return
end
end

%% Others
% check_user_for_increasing_experiments
function go = check_user_for_increasing_experiments(varargin)
if isempty(varargin)
    count2 = 3;
else
    count2 = varargin{1};
    count2 = fix(count2);
end
message = {'OKAY to signal increasing area values.';...
    'Otherwise, leave this message to disappear.';[num2str(count2) ' seconds to report.']};
msg = msgbox(message);
for i = 0:count2-1
    if ishandle(msg)
        msg.Children(2).Children.String(3) = {[num2str(count2-i) ' seconds to report.']};
    end
    pause(1)
end
if ishandle(msg)
    %     fprintf('\nNew experiments will be requested.\n')
    go = 1;
    delete(msg)
else
    %     fprintf('\nExperiment stopped.\n')
    go = 0;
end
end
% check_user_for_decreasing_experiments
function go = check_user_for_decreasing_experiments(varargin)
if isempty(varargin)
    count2 = 3;
else
    count2 = varargin{1};
    count2 = fix(count2);
end
message = {'OKAY to signal decreasing area values.';...
    'Otherwise, leave this message to disappear.';[num2str(count2) ' seconds to report.']};
msg = msgbox(message);
for i = 0:count2-1
    if ishandle(msg)
        msg.Children(2).Children.String(3) = {[num2str(count2-i) ' seconds to report.']};
    end
    pause(1)
end
if ishandle(msg)
    %     fprintf('\nNew experiments will be requested.\n')
    go = 1;
    delete(msg)
else
    %     fprintf('\nExperiment stopped.\n')
    go = 0;
end
end




