function h = extset_generate(h,varargin)
% This function generates the external setup text file to be transfered and
% read by IconNMR.

if isempty(varargin)
    % No Request for an update of the 1D or 2D information about the
    % selected experiments
    exps = [];
else
    % Request an update of the 1D or 2D information about the selected
    % experiments
    exps = varargin{1};
end
% Table of the saved experiment with there parameters set by the user
TABLE = h.Experiment_Table(2:end,:);
[~,j] = sort(TABLE.Holder);
TABLE = TABLE(j,:);
h.Experiment_Table(2:end,:) = TABLE;
h.Experiment_Table_Dimensions = TABLE(:,[1 5:7]);
h.Experiment_Table_Dimensions.Dimension = ones(size(TABLE,1),1);
if ~isempty(TABLE)
    % Read the inserted information
    for i = 1:size(TABLE,1)
        for j = 1:size(TABLE,2)
            name = TABLE.Properties.VariableNames{j};
            eval(['class_name = class(TABLE.' name '(i));']);
            if class_name(1)=='d'
                eval([upper(name) '{i} = TABLE.' name '(i);']);
            else
                if class_name(1)=='l'
                    eval([upper(name) '{i} = TABLE.' name '(i);']);
                else
                    if class_name(1)=='s'
                        eval(['go = ismissing(TABLE.' name '(i));'])
                        if ~go
                            eval(['s = char(TABLE.' name '{i});']);
                        else
                            s = '';
                        end
                        if ~ismember({s},{'none','','...'})
%                             eval(['expp = char(TABLE.' name '(i));']);
%                             expp = textscan(expp,'%*s %s -%*[^-]');
%                             eval([upper(name) '{i} = expp{1}{1};']);
                            eval([upper(name) '{i} = char(TABLE.' name '(i));']);
                        else
                            eval([upper(name) '{i} = '''';']);
                        end
                    end
                end
            end
        end
    end
    
    % Set the text line corresponding to each inserted information
    for i = 1:size(TABLE,1)
        text.t_Index{i} = ['#  ' num2str(INDEX{i})]; %#ok<USENS>
        text.t_User{i} = ['USER ' USER{i}]; %#ok<USENS>
        text.t_Holder{i} = ['HOLDER ' num2str(HOLDER{i})]; %#ok<USENS>
        if ~ismember(NAME(i),{''})%#ok<USENS>
            text.t_Name{i} = ['NAME ' NAME{i}];
        else
            text.t_Name{i} = '';
        end
        text.t_ExpNo{i} = ['EXPNO ' num2str(EXPNO{i})]; %#ok<USENS>
        text.t_Solvent{i} = ['SOLVENT ' SOLVENT{i}]; %#ok<USENS>
%         if ~ismember(BARCODE(i),{''}) %#ok<USENS>
%             text.t_Barcode{i} = ['BARCODE ' num2str(BARCODE{i})];
%         else
%             text.t_Barcode{i} = '';
%         end
        if ~ismember(PARAMETERS(i),{''}) %#ok<USENS>
            text.t_Parameters{i} = ['PARAMETERS ' lower(PARAMETERS{i})];
        else
            text.t_Parameters{i} = '';
        end
        if EXPERIMENT{i}(3)=='-' %#ok<USENS>
            text.t_Experiment{i} = ['EXPERIMENT ' EXPERIMENT{i}(5:end)];
        else
            text.t_Experiment{i} = ['EXPERIMENT ' EXPERIMENT{i}];
        end
        % 1D or 2D experiment
        if ~isempty(exps)
            out = textscan(text.t_Experiment{i},'EXPERIMENT %s');
            [~,a] = ismember(out{1},exps(:,1));
            if a
                if strcmp(exps{a,2},'2D') %2D
                    h.Experiment_Table_Dimensions.Dimension(i) = 2;
                else %1D
                    h.Experiment_Table_Dimensions.Dimension(i) = 1;
                end
            end
        end
        if ~ismember(TITLE(i),{''}) %#ok<USENS>
            text.t_Title{i} = ['TITLE ' TITLE{i}];
        else
            text.t_Title{i} = '';
        end
        if SHIMPROGRAM{i} %#ok<USENS>
            text.t_ShimProgram{i} = ['SHIM_PROGRAM ' SHIMPROGRAM{i}];
        else
            text.t_ShimProgram{i} = '';
        end
%         if ~ismember(METHOD(i),{''}) %#ok<USENS>
%             text.t_Method{i} = ['METHOD ' METHOD{i}];
%         else
%             text.t_Method{i} = '';
%         end
        if STARTTIME{i} %#ok<USENS>
            dt = datetime(DATE{i},'Format','dd-MMM-yyyy HH:mm:ss'); %#ok<USENS>
            % TopSpin in UTC = France time - 01;
%             dt.Hour = dt.Hour-1;
            PosixTimeUTC = fix(posixtime(dt-hours*2));
            text.t_StartTime{i} = ['START_TIME ' num2str(PosixTimeUTC)];
        else
            text.t_StartTime{i} = '';
        end
        if IMPORTED{i} %#ok<USENS>
            text.t_Imported{i} = 'IMPORTED';
        else
            text.t_Imported{i} = '';
        end
%         if LOCKED{i} %#ok<USENS>
%             text.t_Locked{i} = 'LOCK_PROGRAM';
%         else
%             text.t_Locked{i} = '';
%         end
%         if NOSUBMIT{i} %#ok<USENS>
%             text.t_NoSubmit{i} = 'NO_SUBMIT';
%         else
%             text.t_NoSubmit{i} = '';
%         end
        if NIGHT{i} %#ok<USENS>
            text.t_Night{i} = 'NIGHT';
        else
            text.t_Night{i} = '';
        end
%         if SUBMITHOLDER{i} %#ok<USENS>
%             text.t_Submitholder{i} = 'SUBMIT_HOLDER';
%         else
%             text.t_Submitholder{i} = '';
%         end
        if DELETE{i} %#ok<USENS>
            text.t_Delete{i} = 'DELETE';
        else
            text.t_Delete{i} = '';
        end
%         if STARTRUN{i}
%             text.t_StartRun{i} = 'START_RUN';
%         else
%             text.t_StartRun{i} = '';
%         end
%         if STOPRUN{i} %#ok<USENS>
%             text.t_StopRun{i} = 'STOP_RUN';
%         else
%             text.t_StopRun{i} = '';
%         end
%         if END{i} %#ok<USENS>
%             text.t_End{i} = 'END';
%         else
%             text.t_End{i} = '';
%         end
    end
    
    % Fixed information for a holder
    s = 0;
    for i = 1:size(TABLE,1)
        s = s+STARTRUN{i}; %#ok<USENS>
    end
    if s
        text.t_StartRun = 'START_RUN';
    else
        text.t_StartRun = '';
    end
    s = 0;
    for i = 1:size(TABLE,1)
        s = s+STOPRUN{i}; %#ok<USENS>
    end
    if s
        text.t_StopRun = 'STOP_RUN';
    else
        text.t_StopRun = '';
    end
    for i = 1:size(TABLE,1)
        if SUBMITHOLDER{i} %#ok<USENS>
            text.t_Submitholder{i,1} = 'SUBMIT_HOLDER';
        else
            text.t_Submitholder{i,1} = '';
        end
    end
    for i = 1:size(TABLE,1)
        if NOSUBMIT{i} %#ok<USENS>
            text.t_NoSubmit{i,1} = 'NO_SUBMIT';
        else
            text.t_NoSubmit{i,1} = '';
        end
    end
    
    % Combining all the information in a the required text format
    extset = '';
    names = fieldnames(text);
    for i=1:size(TABLE,1)
        if ~DELETE{i}
            extset = [extset '\n' text.t_Index{i} '\n']; %#ok<AGROW>
            for j=2:14%numel(names)
                eval(['go1 = size(text.' names{j} ',2);'])
                if go1==size(TABLE,1)
                    eval(['go = ismember(text.' names{j} '(i),{''''});'])
                    if ~go
                        eval(['extset = [extset text.' names{j} '{i} ''\n''];'])
                    end
                end
            end
        else
            extset = [extset '\n' text.t_Index{i} '\n']; %#ok<AGROW>
            extset = [extset text.t_Holder{i} '\n']; %#ok<AGROW>
            extset = [extset text.t_Delete{i} '\n']; %#ok<AGROW>
        end
    end
    
    for i = 1:size(TABLE,1)
        if SUBMITHOLDER{i}
            extset = [extset '\n' text.t_Holder{i} '\n']; %#ok<AGROW>
            extset = [extset text.t_Submitholder{i,1}  '\n']; %#ok<AGROW>
        end
    end
    for i = 1:size(TABLE,1)
        if NOSUBMIT{i}
            extset = [extset '\n' text.t_Holder{i} '\n']; %#ok<AGROW>
            extset = [extset text.t_NoSubmit{i,1}  '\n']; %#ok<AGROW>
        end
    end
    
    if ~isempty(text.t_StartRun)
        extset = [text.t_StartRun '\n' extset];
    end
    if ~isempty(text.t_StopRun)
        extset = [extset '\n' text.t_StopRun '\n'];
    end
    extset = [extset '\nEnd\n'];
    h.extset = extset;
else
    h.extset = '';
end

end