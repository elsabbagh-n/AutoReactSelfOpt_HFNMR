function sendCommand2Topspin(cmd,waitcmd)
% This function sends cmd to the command line of TOPSPIN. Hostname,
% Username and Password are set to the those of Spectro500.
%
% No file transfer !
%
% Input
% cmd                Command line for TOPSPIN
% waitcmd            1 to wait until cmd executed, 0 to not wait
%
% cmd = 'atma';
% cmd = 'lock "MeOD"';
% cmd = 'topshim tuneb tunebxyz';
% cmd = 'zg';
% cmd = 're 230106_BBI_flowtube_test 7 1 /opt/nmrdata/user/nmr/Nour';

%% User Input
% Required information about the remote PC (spectro 500MHz)
Hostname = '172.16.77.57';
Hostname = 'RMN500-1525.ceisam.sciences.univ-nantes.prive';
Username = 'nmr';
Password = 'topspin';
%% Make sure that the corresponding cmd is valid
if isempty(cmd)
    return
end
%% Send command and wait for its execution on TOPSPIN
command = ['cd /opt/topspin3.6.2/prog/bin ; sendgui ' cmd];
command_output2 = ssh2_simple_command(Hostname, Username, Password,command);
clc
fprintf(['Sending <' cmd '> command to be executed on TOPSPIN.\n'])
display((cell2mat(command_output2)))
if waitcmd
    % see if cmd launched and terminated
    DONE = wait4TopspinExecution(cmd,2);
    % wait until termination
    while(DONE==0)
        DONE = wait4TopspinExecution(cmd,2);
    end
    fprintf(['<' cmd '> command executed successfully.\n'])
end
end




