function [Areas,AreaRegions,expAreaFound,allFound] = get_area_values_from_thisPC(FileName,datasetPath,...
    expList)
% This function returns the area values of an experiment in its dataset
% folder.
%
%
% Input
% FileName                Name of the folder to be checked
% datasetPath             Path of folder to be checked on the remote PC
% expList                 Number of the experiments to be checked
% AcquOrProc              Type of the parameter, 'acqus' or 'procs'
% Parameter               Parameter label or cell of labels if multiple
% varargin                if AcquOrProc = 'procs', then varargin = PROCNO
% Output
% ParValues               Values of the parameter(s), if found/valid
%
% FileName = '230113_BBI_flowtube_test_ChemReact - copie';datasetPath = 'C:\Users\elsabbagh-n\Documents\DataSet';expList = 45;

%% Make sure that the corresponding folder are valid
if isempty(expList)
    return
end
% Check if the main dataset folder is created
filename = fullfile(datasetPath,FileName);
if exist(filename, 'dir')==7
    expInFolder = zeros(length(dir(filename))-2,1);
    n = {dir(filename).name};
    n = n(3:end);
    for i = 1:length(n)
        expInFolder(i,1) = str2double(n{i});
    end
else
    error('File directory does not exist !')
end
expInFolder = sort(expInFolder,'ascend');
expFound = expList(ismember(expList,expInFolder));
%% Integral values file check
int_filename1 = 'integrals.txt';
int_filename2 = 'int1d';
format_int = '%*f      %f      %f      %f';
Areas        = zeros(length(expFound),2);% Target then Reference
AreaRegions  = zeros(length(expFound),4);% Target then Reference
expAreaFound = zeros(length(expFound),1);
for i = 1:length(expFound)
    % Check if the intergal file is in the dataset folder
    filename = fullfile(datasetPath,FileName,num2str(expFound(i)),'/pdata/1');
    fileInFolder = {dir(filename).name};
    if ismember(int_filename1,fileInFolder)
        % Intergral text file created
        filename = fullfile(datasetPath,FileName,num2str(expFound(i)),'/pdata/1',int_filename1);
    elseif ismember(int_filename2,fileInFolder)
        % Intergral text file created
        filename = fullfile(datasetPath,FileName,num2str(expFound(i)),'/pdata/1',int_filename2);
    end
    fileContent = regexp(fileread(filename),'\n','split')';
    FromWhichlines = find(contains(fileContent,'Number'))+1;
    ToWhichlines = length(fileContent)-1;
    ind = FromWhichlines:ToWhichlines;
    for j = 1:length(ind)
        out = textscan(fileContent{ind(j)},format_int);
        Areas(i,j) = out{3};
        AreaRegions(i,2*j-1:2*j) = [out{2} out{1}];
    end
    expAreaFound(i,1) = expFound(i);

    % Retrieve the absolute values of the areas
    ParValues = get_AcquOrProc_ParValue_from_thisPC(FileName,datasetPath,expFound(i),'procs',{'NC_proc','INTSCL'});
    fctr = 10^4*ParValues{2}*2^-ParValues{1};%10^4 to reduce the error due to the missing digits from the written area values
    Areas(i,:) = Areas(i,:)/fctr; % absolute values
%     fprintf(['\nArea value/s of experiment n° ' num2str(expFound(i)) ' has/ve been retrieved.\n'])
end

% Check if all experiments asked for are found
if size(expAreaFound,1)==length(expList)
    if isempty(find(expAreaFound==0,1))
        allFound = 1;
    else
        allFound = 0;
    end
else
    allFound = 0;
end

end


