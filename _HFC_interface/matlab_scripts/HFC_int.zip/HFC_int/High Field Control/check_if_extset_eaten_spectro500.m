function varargout = check_if_extset_eaten_spectro500(FileName,extset_path,...
    t_transfer,waitCheck,varargin)
% This function checks if the transferred extset file was scanned (eaten=1)
% by IconNMR or not (eaten=0). Hostname, Username and Password are set to
% the those of Spectro500.
%
% Input
% FileName         Name of the file to be checked
% extset_path      Path of the file to be downloaded from the remote PC
% t_transfer       Time of the transfer
% waitCheck        =1 to wait until updated, =0 check once
% Output
% eaten            =1 if extset text file was eaten by IconNMR or not

% FileName = 'extset.txt';
% extset_path = '/opt/topspin3.6.2/prog/tmp/';
% t_transfer = datetime('now');
% waitCheck = 1;
%% User Input

% Required information about the remote PC (spectro 500MHz)
Hostname = '172.16.77.57';
Hostname = 'RMN500-1525.ceisam.sciences.univ-nantes.prive';
Username = 'nmr';
Password = 'topspin';

%% Evaluate the input argument
tic
if waitCheck==1 && length(varargin)>=1
    iteration_time = varargin{1};
    printText = varargin{2};
end
%% transfer check
command = ['cd ' extset_path ';ls ;'];
command_output = ssh2_simple_command(Hostname, Username, Password,command);
t_tmp = 0;
t_save = 0;
out = [0 0];
command_output0 = cell(9,length(command_output));
for i = 1:length(command_output)
    command0 = ['cd ' extset_path ';stat ' command_output{i} ';'];
    command_output0(:,i) = ssh2_simple_command(Hostname, Username, Password,command0);
    if strcmp(command_output{i},'save')
        t = textscan(command_output0{7,i},'Modify: %{yyyy-mm-dd}D %{hh:mm:ss.SSS}T');
        t_save = datetime([char(t{1}) ' ' char(t{2})],'Format','hh:mm:ss.SSS');
        t_save.Format = 'yyyy-MM-dd hh:mm:ss.SSS';
    else
        save('eaten.mat','command_output','command_output0')
        if strcmp(command_output{i},FileName)
            if ~isempty(command_output0{7,i})
                t = textscan(command_output0{7,i},'Modify: %{yyyy-mm-dd}D %{hh:mm:ss.SSS}T');
                t_tmp = datetime([char(t{1}) ' ' char(t{2})],'Format','hh:mm:ss.SSS');
                t_tmp.Format = 'yyyy-MM-dd hh:mm:ss.SSS';
            else
                % No retrieve the input items ...
                if nargout==0
                    check_if_extset_eaten_spectro500(FileName,...
                        extset_path,t_transfer,waitCheck);
                elseif nargout==1
                    eval(['a(1) = check_if_extset_eaten_spectro500'...
                        '(FileName,extset_path,t_transfer,waitCheck);'])
                    varargout{1} = a(1); %#ok<NODEF>
                elseif nargout>=2
                    eval(['[a(1),a(2)] = check_if_extset_eaten_spectro500'...
                        '(FileName,extset_path,t_transfer,waitCheck);'])
                    varargout{1} = a(1); %#ok<NODEF>
                    varargout{2} = a(2);                   
                end
                return
            end
        end
    end
end
if ~isdatetime(t_tmp) % no extset file in the tmp path
    % so check the save folder
    if isdatetime(t_save)
        if t_save>t_transfer
            out(1) = 1;
            out(2) = 1;
        else
            out(1) = 0;
            out(2) = 0;
        end
    else % no save folder
        out(1) = 0;
        out(2) = 0;
    end
else % extset file still in the tmp path
    % so check it
    if t_tmp>t_transfer
        out(1) = 1;
    else
        out(1) = 0;
    end
    if t_save>t_transfer
        out(2) = 1;
    else
        out(2) = 0;
    end
end
varargout0 = cell(1,nargout);
for k = 1:min([length(varargout0),2])
    varargout0{k} = out(k);
end
% out
if (out(1)==0 || out(2)==0) || (out(2)==0 && false)
    if out(1)==0 || out(2)==0
        if waitCheck~=0
            if length(varargin)>=1
                iteration_time = iteration_time + toc;
            else
                iteration_time = 0;
            end
            %     disp(iteration_time)
            if iteration_time>5
                if iteration_time>10
                    fprintf('\nThis is the last check!\n')
                    %                 varargout = check_if_extset_eaten_spectro500(FileName,extset_path,...
                    %                     t_transfer,0);
                    if length(varargout0)==1
                        a(1) = check_if_extset_eaten_spectro500(FileName,extset_path,...
                            t_transfer,0);
                        % varargout{1} = a(1);
                        out = a;
                    elseif length(varargout0)==2
                        [a(1),a(2)] = check_if_extset_eaten_spectro500(FileName,extset_path,...
                            t_transfer,0);
                        % varargout{1} = a(1);
                        % varargout{2} = a(2);
                        out = a;
                    end
                else
                    if printText==1
                        fprintf('\nExtset scanning by IconNMR is taking too long!\n')
                    end
                    fprintf('\nChecking again\n')
                    %                 varargout = check_if_extset_eaten_spectro500(FileName,extset_path,...
                    %                     t_transfer,1,iteration_time,0);
                    if length(varargout0)==1
                        a(1) = check_if_extset_eaten_spectro500(FileName,extset_path,...
                            t_transfer,1,iteration_time,0);
                        % varargout{1} = a(1);
                        out = a;
                    elseif length(varargout0)==2
                        [a(1),a(2)] = check_if_extset_eaten_spectro500(FileName,extset_path,...
                            t_transfer,1,iteration_time,0);
                        % varargout{1} = a(1);
                        % varargout{2} = a(2);
                        out = a;
                    end
                end
            else
                % fprintf('\nChecking once\n')
                %             varargout = check_if_extset_eaten_spectro500(FileName,extset_path,...
                %                 t_transfer,1,iteration_time,1)
                if length(varargout0)==1
                    a(1) = check_if_extset_eaten_spectro500(FileName,extset_path,...
                        t_transfer,1,iteration_time,1);
                    % varargout{1} = a(1);
                    out = a;
                elseif length(varargout0)==2
                    [a(1),a(2)] = check_if_extset_eaten_spectro500(FileName,extset_path,...
                        t_transfer,1,iteration_time,1);
                    % varargout{1} = a(1);
                    % varargout{2} = a(2);
                    out = a;
                end
            end
        end
    elseif out(2)==0 && false% wait until file is moved
        if waitCheck~=0
            if length(varargin)>=1
                iteration_time = iteration_time + toc;
            else
                iteration_time = 0;
            end
            %     disp(iteration_time)
            if iteration_time>5
                if iteration_time>10
                    fprintf('\nThis is the last check!\n')
                    if length(varargout0)==1
                        a(1) = check_if_extset_eaten_spectro500(FileName,extset_path,...
                            t_transfer,0);
                        % varargout0{1} = a(1);
                        out = a;
                    elseif length(varargout0)==2
                        [a(1),a(2)] = check_if_extset_eaten_spectro500(FileName,extset_path,...
                            t_transfer,0);
                        % varargout0{1} = a(1);
                        % varargout0{2} = a(2);
                        out = a;
                    end
                else
                    if printText==1
                        fprintf('\nExtset scanning by IconNMR is taking too long!\n')
                    end
                    %                 fprintf('\nChecking again\n')
                    if length(varargout0)==1
                        a(1) = check_if_extset_eaten_spectro500(FileName,extset_path,...
                            t_transfer,1,iteration_time,0);
                        % varargout0{1} = a(1);
                        out = a;
                    elseif length(varargout0)==2
                        [a(1),a(2)] = check_if_extset_eaten_spectro500(FileName,extset_path,...
                            t_transfer,1,iteration_time,0);
                        % varargout0{1} = a(1);
                        % varargout0{2} = a(2);
                    end
                end
            else
                %             fprintf('\nChecking again\n')
                if length(varargout0)==1
                    a(1) = check_if_extset_eaten_spectro500(FileName,extset_path,...
                        t_transfer,1,iteration_time,1);
                    % varargout0{1} = a(1);
                    out = a;
                elseif length(varargout0)==2
                    [a(1),a(2)] = check_if_extset_eaten_spectro500(FileName,extset_path,...
                        t_transfer,1,iteration_time,1);
                    % varargout0{1} = a(1);
                    % varargout0{2} = a(2);
                    out = a;
                end
            end
        end
    end
%     return
else
    a = out;
end
varargout = cell(1,length(a));
for k = 1:min([length(varargout),2])
    varargout{k} = out(k);
end
% varargout
end


