function Reactor_Volume = determine_fast_reactor_volume(varargin)
% This function determines the volume of a reactor between a pump, or
% several ones, and a high-field spectrometer. The pump(s) should be primed
% and ready to pump new mixture, other than the one already filling the
% reactor and the flowtube unit. The peak of interest, of the compound,
% should be indicated in the autoModeHandles created to search for a
% plateau. After the plateau is reached, and knowing the time when the
% pump(s) was(were) launched and the flowrate value, the reactor volume is
% then determined / residence time distribution.
%% Initial values
varargin = {1};
close all force
clearvars -except varargin
clc
% File path of the HF-NMR interface script
addpath(genpath('C:\Users\Ceisam_Mimm\Documents\MATLAB\CurrentHFNMROptFolder\High Field Control'))
% File path of the SCP functions
addpath(genpath('C:\Users\Ceisam_Mimm\Documents\MATLAB\CurrentHFNMROptFolder\Freedman_ssh'))
% Flowrate mL/min
FR = 0.3;
%% Create auto NMR experiment
create_new = 0;
DetermineVolumeAutoHandlePath = 'C:\Users\Ceisam_Mimm\Documents\MATLAB\CurrentHFNMROptFolder\High Field Control\autoModeHandles_WET_yh.mat';
if create_new==0
    % Update already created handles
    load(DetermineVolumeAutoHandlePath,'autoModeHandles')
    autoModeHandles.archive = [];
    autoModeHandles.areaAdditionalList_Num = [];% [3.39 3.53]+0.17;%Addition
    autoModeHandles.Table.ExpNo(2) = 1;
    autoModeHandles.Table.Name(2) = string(['YH_' char(datetime('now','Format','yyyyMMdd')) '_ReactorVolume']);
    autoModeHandles.Table.Title(2) = "Plateau WET 1H to calculate reactor volume YH ACN+TMB";
    autoModeHandles.area = [6.05 6.13];
    autoModeHandles.areaRef = [3.68 3.76];
    save(DetermineVolumeAutoHandlePath,'autoModeHandles')
else
    DetermineVolumeAutoHandlePath = ExtSet_GUI_function('list');
end
%% Start pump time
% The starting time should be noted/determine using the next line
StartingTime = datetime('now','Format','HH:mm:ss');
clc;disp(StartingTime)
%% Series of experiment to observe the filling

[Area,Region,pathLatestExp] = ExtSet_GUI_function(DetermineVolumeAutoHandlePath,0,'maxuc');

ExtSet_GUI_function('stop')
clc
display(Region)
display(pathLatestExp)
drawnow

%% Get date/time
ExpNo = double(cell2mat(Area.ExpNo)); %1:14
[~,filename,~] = fileparts(fileparts(pathLatestExp));
[~,ExpTimes] = get_experiments_times_remote(ExpNo,filename);
% StartingTime = datetime('13:26:33','Format','HH:mm:ss');
% StartingTime.Day = ExpTimes(1).Day;
% StartingTime.Month = ExpTimes(1).Month;
% StartingTime.Year = ExpTimes(1).Year;
%% Data point
ind = ExpTimes>=StartingTime;
% x = ExpTimes(ind);
y = [Area.Area{ind}]';
yref = [Area.Area{ind}]'./[Area.RelativeArea{ind}]';
dy = diff(y);
D = ExpTimes-StartingTime;
[h,m,s] = hms(D);
D = h*60+m+s/60; %min
x = D;
figure
subplot(1,2,1)
plot(x,y,'-o')
hold on,plot(x,yref,'-o')
xlabel('min')
ylabel('Area')
subplot(1,2,2)
plot(x(2:end),dy,'-o')
xlabel('min')
ylabel('dArea')
while(1)
[BREAK,~]=ginput(1); %min
Reactor_Volume = BREAK*sum(FR) %mL %4.5mL
end

end













