function report = read_shim_report_TOPSPIN
% This function looks for calculated intergals by TopSpin for a desired
% list of experiments. Hostname, Username and Password are set to the those
% of Spectro500.
%
% No file transfer !
%
% Output
%   report      information gathered from the latest shim report

%% User Input

% Required information about the remote PC (spectro 500MHz)
Hostname = '172.16.77.57';
Hostname = 'RMN500-1525.ceisam.sciences.univ-nantes.prive';
Username = 'nmr';
Password = 'topspin';
% File path of the SCP functions
addpath(genpath('C:\Users\elsabbagh-n\Documents\MATLAB\Freedman_ssh'))

%% Make sure that the corresponding folder are valid

filename = 'topshim_report.txt';
filepath = '/opt/topspin3.6.2/prog/curdir/nmr/';
% Check if the file exists
command = ['cd ' filepath ' ; ls ;'];
command_output = ssh2_simple_command(Hostname, Username, Password,command);
[~,a] = ismember(filename,command_output);
if a
    % read file
    command = ['cd ' filepath ' ; cat ' filename ' ;'];
    command_output = ssh2_simple_command(Hostname, Username, Password,command);
    % Solvent
    whichline = contains(command_output,'solvent =');
    if isempty(find(whichline,1))
        report.Solvent = [];
    else
        out = textscan(command_output{whichline},'solvent = %s');
        report.Solvent = out{1}{1};
    end
    % Nucleus
    whichline = contains(command_output,'shim nucleus =');
    if isempty(find(whichline,1))
        report.Nucleus = [];
    else
        out = textscan(command_output{whichline},'shim nucleus =%s');
        report.Nucleus = out{1}{1};
    end
    % O1p
    whichline = contains(command_output,'o1p ');
    if isempty(find(whichline,1))
        report.O1P = [];
    else
        out = textscan(command_output{whichline},'o1p %*[^=] = %f ppm');
        report.O1P = out{1};
    end
    % Initial B0 stdDev
    whichline = contains(command_output,'initial B0 stdDev = ');
    if isempty(find(whichline,1))
        report.Initial_stdDev = [];
    else
        out = textscan(command_output{whichline},'initial B0 stdDev = %f Hz');
        report.Initial_stdDev = out{1};
    end
    % Final B0 stdDev
    whichline = contains(command_output,'final B0 stdDev = ');
    if isempty(find(whichline,1))
        report.Final_stdDev = [];
    else
        out = textscan(command_output{whichline},'final B0 stdDev = %f Hz');
        report.Final_stdDev = out{1};
    end
    % Improvement
    whichline = contains(command_output,'> improvement = ');
    if isempty(find(whichline,1))
        report.Improvement = [];
    else
        out = textscan(command_output{whichline},'%*[^>] > improvement = %f');
        report.Improvement = out{1};
    end
    % Envelope width
    whichline = contains(command_output,'envelope width = ');
    if isempty(find(whichline,1))
        report.Envelope_width = [];
    else
        out = textscan(command_output{whichline},'envelope width = %f Hz');
        report.Envelope_width = out{1};
    end
    % Duration
    whichline = contains(command_output,'duration = ');
    if isempty(find(whichline,1))
        report.Duration = [];
    else
        if contains(command_output{whichline},'min')
            if contains(command_output{whichline},'sec')
                out = textscan(command_output{whichline},'duration = %f min %f sec');
                report.Duration = out{1}*minutes + out{2}*seconds;
            else
                out = textscan(command_output{whichline},'duration = %f min');
                report.Duration = out{1}*minutes;
            end
        else
            out = textscan(command_output{whichline},'duration = %f sec');
            report.Duration = out{1}*seconds;
        end
    end
    % Status
    whichline1 = find(contains(command_output,'duration = '),1);
    whichline2 = find(contains(command_output,'finished '),1);
    if isempty(find(whichline1,1)) || isempty(find(whichline2,1))
        report.Status = [];
    else
        if (whichline2-whichline1)~=2
            report.Status = [];
        else
            report.Status = command_output{whichline1+1};
        end
    end
end
end


