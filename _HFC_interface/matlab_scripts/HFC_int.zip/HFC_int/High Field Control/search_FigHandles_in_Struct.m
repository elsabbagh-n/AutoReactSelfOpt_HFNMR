function foundInField = search_FigHandles_in_Struct(structID,wanted,secnd) %#ok<INUSL>
% This function finds the fieldname in a struct corresponding to a certain
% handle, e.g., a figure.
% Input :
%           structID    [struct]    Struct containing the search handle
%           wanted      [char]      Name of the searched handle: it can be
%                                   a Title or a Name or a String appearing
%                                   on the figure.
% Output :
%           foundInField            Name of the field in the [structID]
%                                   corresponding to the handle with the
%                                   title/name/string [wanted].
%

clc
foundInField = [];
gatherStrings = {''};
eval('struct_name = ''structID'';')
eval(['chl = fieldnames(' struct_name ');'])
poss = {'Name','Title','String','Text'};
for i = 1:length(chl) %#ok<USENS>
    eval(['c = isa(' struct_name '.' chl{i} ',''struct'');'])
    if ~c
        eval(['c(1) = isa(' struct_name '.' chl{i} ',''double'');'])
        eval(['c(2) = isa(' struct_name '.' chl{i} ',''char'');'])
        eval(['c(3) = isa(' struct_name '.' chl{i} ',''string'');'])
        eval(['c(4) = isa(' struct_name '.' chl{i} ',''cell'');'])
        eval(['c(5) = isa(' struct_name '.' chl{i} ',''table'');'])
        eval(['c(6) = isa(' struct_name '.' chl{i} ',''ExtSet_Input'');'])
        eval(['c(7) = isa(' struct_name '.' chl{i} ',''matlab.ui.Figure'');'])
        if ~c
            eval(['d = isa(' struct_name '.' chl{i} ',''matlab.ui.container.Panel'');'])
            eval(['e = isa(' struct_name '.' chl{i} ',''matlab.graphics.Graphics'');'])
            eval(['f = isa(' struct_name '.' chl{i} ',''matlab.ui.control.UIControl'');'])
            if ~d && ~e && ~f
                eval(['chl0 = fieldnames(' struct_name '.' chl{i} ');'])
                a = ismember(poss,chl0);
                if find(a)
                    eval(['b = strcmp(' struct_name '.' chl{i} '.' poss{a} ',wanted);'])
                    eval(['gatherStrings{end+1} = ' struct_name '.' chl{i} '.' poss{a} ';'])
                    if b
                        foundInField{end+1} = chl{i}; %#ok<AGROW>
                        fprintf(['\n''' wanted ''' found in ' foundInField{end} ':\n' struct_name '.' foundInField{end} '\n'])
%                         break
                    end
                end
            else
                eval(['sz = length(' struct_name '.' chl{i} ');'])
                for j = 1:sz
                    eval(['chl0 = fieldnames(' struct_name '.' chl{i} '(j));'])
                    a = ismember(poss,chl0);
                    if find(a)
                        eval(['b = strcmp(' struct_name '.' chl{i} '(j).' poss{a} ',wanted);'])
                        eval(['str = ' struct_name '.' chl{i} '(j).' poss{a} ';'])
                            if isa(str,'cell')
                                gatherStrings(end+1:end+length(str)) = str;
                            else
                                gatherStrings{end+1} = str; %#ok<AGROW>
                            end
                        if find(b)
                            foundInField{end+1} = chl{i}; %#ok<AGROW>
                            fprintf(['\n''' wanted ''' found in ' foundInField{end} ...
                                ':\n' struct_name '.' foundInField{end} '(' num2str(j) ')\n'])
%                             break
                        end
                    end
                end
            end
        end
    end
end

if isempty(foundInField) && secnd==0
    [i,~] = strnearest({wanted},gatherStrings(2:end));
    if ~isempty(gatherStrings{1+i{1}(1)})
        foundInField = search_FigHandles_in_Struct(structID,gatherStrings{1+i{1}(1)},1);
    end
    return
elseif isempty(foundInField) && secnd==1
    clc
    fprintf(['\n''' wanted ''' not found\n'])
    foundInField = [];
end
end



