function h = param_insert(h)
% This function fixes the value inserted in the field (Parameters Input
% Panel) to the chosen parameter from the list.

if ~isempty(h.editable_text_field(end).String)
    h.Fixed_Parameter(h.popup_menu(end,1).Value,2) = ...
        {str2double(h.editable_text_field(end).String)};
    l2 = h.Fixed_Parameter;
    emptyCells2 = cellfun(@isempty,h.Fixed_Parameter(:,2));
    full_p2 = find(~emptyCells2);
    text_ParametersInput2 = cell(1,length(full_p2));
    for i = 1:length(full_p2)
        text_ParametersInput2(1,i) = {[l2{full_p2(i),1},' = ',...
            num2str(l2{full_p2(i),2})]};
    end
    h.list_box(1).String = text_ParametersInput2;
    h.editable_text_field(end).String = '';
end
% h = tag_update(h);
end
