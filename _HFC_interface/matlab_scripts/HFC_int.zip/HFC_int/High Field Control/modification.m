function h = modification(h,ON)
% This function enable the user to modify the entries (ON = 1).

if ON
    for i = 1:size(h.ParametersList,1)
        [~,b]=ismember(h.ParametersList{i},h.checkList(:,1));
        if b
            check = cell2mat(h.checkList(b,2:end));
            if check(4)==0
                if check(3)==0 %it is an insert text
                    h.editable_text_field(check(2)).ForegroundColor = [1 0.07 0.65];
                else %it is a popup menu
                    h.popup_menu(check(3)).ForegroundColor = [1 0.07 0.65];
                end
            else %it is a check box then
                h.check_box(check(4)).ForegroundColor = [1 0.07 0.65];
            end
        end
    end
    % Parameter Input Panel
    h.check_box(end).ForegroundColor = [1 0.07 0.65];
    h.popup_menu(end,1).ForegroundColor = [1 0.07 0.65];
    h.editable_text_field(end,1).ForegroundColor = [1 0.07 0.65];
    h.push_button(1).ForegroundColor = [1 0.07 0.65];
    h.push_button(2).ForegroundColor = [1 0.07 0.65];
    h.list_box(1).ForegroundColor = [1 0.07 0.65];
    h.list_box(2).Enable = 'off';
    h.list_box(3).Enable = 'off';
    for j = 4:length(h.push_button)
        properties_ = properties(h.push_button(j));
        if ~isempty(properties_)
            h.push_button(j).Enable = 'off';
        end
    end
else
    for i = 1:size(h.ParametersList,1)
        [~,b]=ismember(h.ParametersList{i},h.checkList(:,1));
        if b
            check = cell2mat(h.checkList(b,2:end));
            if check(4)==0
                if check(3)==0 %it is an insert text
                    h.editable_text_field(check(2)).ForegroundColor = [0 0 0];
                else %it is a popup menu
                    h.popup_menu(check(3)).ForegroundColor = [0 0 0];
                end
            else %it is a check box then
                if ismember(h.ParametersList{i},{'StartRun';'StopRun'})
                    h.check_box(check(4)).ForegroundColor = [0 0.45 0.74];
                else
                    if ismember(h.ParametersList{i},{'Delete'})
                        h.check_box(check(4)).ForegroundColor = [1 0 0];
                    else
                        h.check_box(check(4)).ForegroundColor = [0 0 0];
                    end
                end
            end
        end
    end
    % Parameter Input Panel
    h.check_box(end).ForegroundColor = [0 0 0];
    h.popup_menu(end,1).ForegroundColor = [0 0 0];
    h.editable_text_field(end,1).ForegroundColor = [0 0 0];
    h.push_button(1).ForegroundColor = [0 0 0];
    h.push_button(2).ForegroundColor = [0 0 0];
    h.list_box(1).ForegroundColor = [0 0 0];
    h.list_box(2).Enable = 'on';
    h.list_box(3).Enable = 'on';
    for j = 4:length(h.push_button)
        properties_ = properties(h.push_button(j));
        if ~isempty(properties_)
            h.push_button(j).Enable = 'on';
        end
    end
end
end