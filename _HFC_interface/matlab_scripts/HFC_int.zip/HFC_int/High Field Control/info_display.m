function h = info_display(h)
% This function displays the already inserted information of the selected
% experiment in the list box of the Edit Input Panel. The information is
% displayed in the corresponding fields.

% h = tag_update(h);
if ~isempty(h.list_box(2).String)
    ind = split(h.list_box(2).String{h.list_box(2).Value},filesep);
    ind = str2double(ind{1});
    n_table = find(h.Experiment_Table.Index==ind);
    for i = 2:size(h.Experiment_Table,2)-1
        if ismember(lower(h.Experiment_Table.Properties.VariableNames(i)),...
                {'parameters'})
            if ~ismissing(h.Experiment_Table.Parameters(n_table))
                param = textscan(char(h.Experiment_Table.Parameters(n_table)),...
                    '%q %f','Delimiter',',');
                popup_menu_list = h.popup_menu(end,1).String;
                txt = popup_menu_list(contains(popup_menu_list,...
                    param{1}{1}));
                h.list_box(1).String = {[char(txt) ' = '...
                    char(string(param{2}(1)))]};
                for j = 2:size(param{1},1)
                    txt = popup_menu_list(contains(popup_menu_list,...
                        param{1}{j}));
                    h.list_box(1).String(j,1) = {[char(txt) ' = '...
                        char(string(param{2}(j)))]};
                end
            else
                h.list_box(1).String = [];
            end
            continue
        end
        if ismember(lower(h.Experiment_Table.Properties.VariableNames(i)),...
                {'starttime'})
            [~,d] = ismember(lower(...
                h.Experiment_Table.Properties.VariableNames(i)),...
                lower(h.checkList(:,1)));
            if d
                check = cell2mat(h.checkList(d,2:end));
                eval(['t = h.Experiment_Table.' h.checkList{d,1}...
                    '(n_table);'])
                eval(['h.check_box(' num2str(check(4)) ').Value = t;'])
                if t
                    h.calendar.static_text_field(1).Visible = 1;
                    h.calendar.static_text_field(1).String = ...
                        h.Experiment_Table.Date(n_table);
                    h.calendar.push_button(1).Visible = 1;
                    h.calendar.push_button(2).Visible = 1;
                else
                    h.calendar.static_text_field(1).Visible = 0;
                    h.calendar.static_text_field(1).String = '';
                    h.calendar.push_button(1).Visible = 0;
                    h.calendar.push_button(2).Visible = 0;
                    hh.calendar.f(1).Visible = 0;
                    hh.calendar.f(2).Visible = 0;
                end
            end
            continue
        end
        
        [~,d] = ismember(lower(...
            h.Experiment_Table.Properties.VariableNames(i)),...
            lower(h.checkList(:,1)));
        if d
            check = cell2mat(h.checkList(d,2:end));
            if check(4)==0
                if check(3)==0 %it is an insert text
                    eval(['h.editable_text_field('...
                        num2str(check(2)) ').String = '...
                        'h.Experiment_Table.' h.checkList{d,1}...
                        '(n_table);'])
                else %it is a popup menu
                    popup_menu_list = h.popup_menu(check(3),1).String; %#ok<NASGU>
                    eval(['[~,c]=ismember(lower(popup_menu_list),'...
                        'lower(h.Experiment_Table.' h.checkList{d,1}...
                        '(n_table)));'])
                    c = find(c,1);
                    if c
                        h.popup_menu(check(3),1).Value = c;
                    end
                end
            else %it is a check box then
                eval(['h.check_box(' num2str(check(4)) ').Value = '...
                    'h.Experiment_Table.' h.checkList{d,1}...
                    '(n_table);'])
            end
        end
    end
end
end
