function h = exp_duplicate(h)
% This function duplicates the experiment saved in the selected line of the
% list box of the Edit Input Panel.

if ~isempty(h.list_box(2).String)
    ind = split(h.list_box(2).String{h.list_box(2).Value},filesep);
    ind = str2double(ind{1});
    h = exp_create(h,ind);
end
end
