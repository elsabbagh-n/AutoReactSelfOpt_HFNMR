function status_updated = check_if_status_updated_spectro500(FileName,statusPath,...
    t_old,waitCheck,varargin)
% This function checks if the status file was updated (status_updated=1)
% by IconNMR or not (status_updated=0). Hostname, Username and Password are set to
% the those of Spectro500.
%
% Input
% FileName         Name of the file to be checked
% statusPath       Path of the file to be downloaded from the remote PC
% t_old            Time of the transfer
% waitCheck        =1 to wait until updated, =0 check once
% Output
% eaten            =1 if extset text file was eaten by IconNMR or =0 not

% FileName = h.fileName;
% statusPath = '/opt/topspin3.6.2/prog/curdir/changer';
% t_old = datetime('now');
% waitCheck = 1;
%% User Input

% Required information about the remote PC (spectro 500MHz)
Hostname = '172.16.77.57';
Hostname = 'RMN500-1525.ceisam.sciences.univ-nantes.prive';
Username = 'nmr';
Password = 'topspin';

%% Evaluate the input argument
tic
if waitCheck==1 && length(varargin)>=1
    iteration_time = varargin{1};
    printText = varargin{2};
end

%% Status update check

command = ['cd ' statusPath '; stat ' FileName ' ;'];
command_output = ssh2_simple_command(Hostname, Username, Password,command);
t = textscan(command_output{7},'Modify: %{yyyy-mm-dd}D %{hh:mm:ss.SSS}T');
t_new = datetime([char(t{1}) ' ' char(t{2})],'Format','hh:mm:ss.SSS');
t_new.Format = 'yyyy-MM-dd hh:mm:ss.SSS';
if t_new>t_old
    status_updated = 1;
else
    status_updated = 0;
end

if status_updated==0
    if waitCheck~=0
        if length(varargin)>=1
            iteration_time = iteration_time + toc;
        else
            iteration_time = 0;
        end
%         disp(iteration_time)
        if iteration_time>5
            if iteration_time>20
                warning('\nThis is the last check!\n')
                status_updated = check_if_status_updated_spectro500(FileName,statusPath,...
                    t_old,0);
            else
                if printText==1
                    warning('\nStatus file updating by IconNMR is taking too long!\n')
                end
%                 fprintf('\nChecking again\n')
                status_updated = check_if_status_updated_spectro500(FileName,statusPath,...
                    t_old,1,iteration_time,0);
            end
        else
%             fprintf('\nChecking again\n')
            status_updated = check_if_status_updated_spectro500(FileName,statusPath,...
                t_old,1,iteration_time,1);
        end
    end
end
end


