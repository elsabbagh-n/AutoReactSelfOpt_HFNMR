function [AreaRegion,AreaValue] = region_area(h,varargin)
% Region selection and area calculation Callback
%%
global hh newExp2Plot_ind autoFct
if ~(size(varargin,2)==0)
    % Auto area calcultation for the available experiments using specified region bounds
    bounds = varargin{1};
    autoFct = 1;
else
    % Manual bounds choice and area calculation
    autoFct = 0;
end

hh = h;

if autoFct==0
    % Window for the region selection
    if hh.screen==1
        hh.regionArea.f(1) = uifigure('units','normalized','position',...
            [0.0104 0.0565 0.6339 0.5519],'Name','Status',...
            'HandleVisibility', 'on');
    else
        hh.regionArea.f(1) = uifigure('units','normalized','position',...
            [-0.9833 0.0468 0.6339 0.5519],'Name','Region Selection',...
            'HandleVisibility','on');
    end
    movegui(gcf,'center');
    
    % Table for completed experiments
    [~,a] = ismember(cell2mat(hh.status.st(:,4)),1);
    [~,b] = ismember(cell2mat(hh.status.errorR),1);
    [~,c] = ismember(cell2mat(hh.status.st(:,5)),1);
    completed_experiments = find(a);
    noError_experiments = find(~b);
    noDeleted_experiments = find(~c);
    d = intersect(noError_experiments,completed_experiments);
    d = intersect(d,noDeleted_experiments);
    Areas(1:length(d),1) = {[]};
    t0 = [hh.status.uit.Data(d,1:6),table(Areas)];
    hh.regionArea.uit = uitable(hh.regionArea.f(1),'Data',...
        t0,'Units','normalized',...
        'Position',[0.02 0.79 0.96 0.2],'CellSelectionCallback',@UITableCellSelection);
    
    % axe for spectra plotting
    % hh.regionArea.ax(1) = uiaxes(hh.regionArea.f(1),'units','normalized','position',...
    %     [0.04 0.06 0.5 0.7]);
    hh.regionArea.ax(1) = uiaxes(hh.regionArea.f(1),'units','pixels','position',...
        [49.6800 36.7600 608.5000 417.2000]);
    hh.regionArea.ax(1).XLabel.String = 'Frequency (ppm)';
    hh.regionArea.ax(1).YLabel.String = 'Magnitude';
    hh.regionArea.ax(1).ButtonDownFcn = @axes1_ButtonDownFcn;
    legend
    
    hh.button(1) = uibutton(hh.regionArea.f(1),'push','Text','ZOOM IN',...
        'Position',[700 150 100 100],'FontSize',16,'ButtonPushedFcn',@zoomIN);
    hh.button(2) = uibutton(hh.regionArea.f(1),'push','Text','ZOOM OUT',...
        'Position',[850 150 100 100],'FontSize',16,'ButtonPushedFcn',@zoomOUT);
    hh.button(3) = uibutton(hh.regionArea.f(1),'push','Text','DONE',...
        'Position',[1000 150 100 100],'FontSize',16,'ButtonPushedFcn',@areaDone);
    
    hh.text(1) = uilabel(hh.regionArea.f(1),'Position',[670 400 500 50],...
        'FontSize',17,'Text',{'Choose region by selecting, with two clicks on the plot, its bounds.'});
    
    hh.text(2) = uilabel(hh.regionArea.f(1),'Position',[670 350 500 50],...
        'FontSize',17,'Text',{['Selected Bounds : ',...
        '[                   ppm ,                   ppm ]']});
    hh.text(3) = uilabel(hh.regionArea.f(1),'Position',[835 365 60 25],...
        'FontSize',17,'Text',{' '},'BackgroundColor',[1 1 1],'HorizontalAlignment','center');
    hh.text(4) = uilabel(hh.regionArea.f(1),'Position',[965 365 60 25],...
        'FontSize',17,'Text',{' '},'BackgroundColor',[1 1 1],'HorizontalAlignment','center');
    hh.text(5) = uilabel(hh.regionArea.f(1),'Position',[670 300 500 50],...
        'FontSize',17,'Text',{'Area arround : '});
    hh.text(6) = uilabel(hh.regionArea.f(1),'Position',[790 315 100 25],...
        'FontSize',17,'Text',{' '},'BackgroundColor',[1 1 1],'HorizontalAlignment','center');
    
    hh.regionArea.goingOnce = 1;
    newExp2Plot_ind = [];
    hh.regionArea.LIM = [];
    
    uiwait(hh.regionArea.f(1))
    clc
    disp(hh.regionArea.results.ExpNo_Areas)
    fprintf('\n Region bounds : [ %.1f , %.1f ] ppm.\n',hh.regionArea.results.LIM(1),hh.regionArea.results.LIM(2))
    AreaRegion = hh.regionArea.results.LIM;
    ind = double(hh.regionArea.results.ExpNoRef.ExpNo{1});
    AreaValue = hh.regionArea.results.ExpNo_Areas.Areas{ind==double(cell2mat(hh.regionArea.results.ExpNo_Areas.ExpNo))};
else
    clc
    disp(bounds)
    % Table for completed experiments
    [~,a] = ismember(cell2mat(hh.status.st(:,4)),1);
    [~,b] = ismember(cell2mat(hh.status.errorR),1);
    [~,c] = ismember(cell2mat(hh.status.st(:,5)),1);
    completed_experiments = find(a);
    noError_experiments = find(~b);
    noDeleted_experiments = find(~c);
    d = intersect(noError_experiments,completed_experiments);
    d = intersect(d,noDeleted_experiments);
    Areas(1:length(d),1) = {[]};
    hh.regionArea.t0 = [hh.status.uit.Data(d,1:6),table(Areas)];
    newExp2Plot = double(cell2mat(hh.regionArea.t0.ExpNo));
    newExp2Plot_ind = find(ismember(double(cell2mat(hh.regionArea.t0.ExpNo)),newExp2Plot));
    plt = plot_for_area_selection(hh.regionArea.t0,newExp2Plot,newExp2Plot_ind,autoFct);
    
    
end
%%
end

%% used functions
function UITableCellSelection(~, event)
global hh newExp2Plot_ind autoFct
stt = hh.regionArea;
selectedCell = event.Indices;
% display(selectedCell)
newExp2Plot = double(stt.uit.Data.ExpNo{selectedCell(1)});
newExp2Plot_ind = selectedCell(1);
stt.plt(newExp2Plot_ind).plt = plot_for_area_selection(stt,newExp2Plot,newExp2Plot_ind,autoFct);
clc
hh.regionArea = stt;
if isempty(hh.regionArea.LIM)
    LIM = [min(hh.regionArea.ax(1).XLim),max(hh.regionArea.ax(1).XLim)];
    hh.regionArea.LIM = LIM;
    hh.regionArea.X1 = xline(LIM(1),'LineStyle',':','HandleVisibility','off');
    hh.regionArea.X2 = xline(LIM(2),'LineStyle',':','HandleVisibility','off');
else
    LIM = [hh.regionArea.X1.Value hh.regionArea.X2.Value];
end
hh.text(3).Text = num2str(round(LIM(1),2));
hh.text(4).Text = num2str(round(LIM(2),2));
areaCalculation
% apply2all
end

function axes1_ButtonDownFcn(objectHandle,~)
% function axes1_ButtonDownFcn ( objectHandle , eventData )
global coordinates hh newExp2Plot_ind
if ~isempty(newExp2Plot_ind)
    axesHandle  = get(objectHandle,'Parent');
    coordinates = get(axesHandle,'CurrentPoint');
    coordinates = coordinates(1,1:2);
    d = hh.regionArea.ax(1).InnerPosition;
    xlim0 = hh.regionArea.ax(1).XLim;
    a = xlim0(2)+(xlim0(1)-xlim0(2))*(coordinates(1)-d(1))/d(3);
    if hh.regionArea.goingOnce==1
        hh.regionArea.X2.Value = a;
        hh.regionArea.X1.Value = xlim0(1);
        hh.regionArea.goingOnce  = 0;
        hh.text(6).Text = ' ';
        setBounds
    else
        hh.regionArea.X1.Value = a;
        hh.regionArea.goingOnce  = 1;
        if hh.regionArea.X1.Value>hh.regionArea.X2.Value
            a = hh.regionArea.X1.Value;
            b = hh.regionArea.X2.Value;
            hh.regionArea.X1.Value = b;
            hh.regionArea.X2.Value = a;
        end
        drawnow
        setBounds
        areaCalculation
        apply2all
    end
    clc
else
    clc
    fprintf('No plot available')
end
end

function setBounds(varargin)
global hh
LIM = [hh.regionArea.X1.Value hh.regionArea.X2.Value];
hh.text(3).Text = num2str(round(LIM(1),2));
hh.text(4).Text = num2str(round(LIM(2),2));
end

function areaCalculation(varargin)
global hh newExp2Plot_ind autoFct
if ~(size(varargin,2)==0)
    % Apply to all
    newExp2Plot_ind0 = varargin{1};
else
    newExp2Plot_ind0 = newExp2Plot_ind;
end
if autoFct==0
% Dataset
X = hh.regionArea.plt(newExp2Plot_ind0).plt{1}.XData; X = fliplr(X);
Y = hh.regionArea.plt(newExp2Plot_ind0).plt{1}.YData; Y = fliplr(Y);

% Initial Integration
Int = cumtrapz(X,Y);
hh.regionArea.Intv = @(a,b) max(Int(X<=b)) - min(Int(X>=a));

% Bounds
LIM = [hh.regionArea.X1.Value,hh.regionArea.X2.Value];

% Area Calculation version 1
hh.regionArea.Int_Val(newExp2Plot_ind0,1) = hh.regionArea.Intv(LIM(1),LIM(2));
% Area Calculation version 2
idx = X>LIM(1) & X<LIM(2);
hh.regionArea.Int_Val(newExp2Plot_ind0,2) = trapz(X(idx),Y(idx));

% Display in window
area_i = round(hh.regionArea.Int_Val(newExp2Plot_ind0,2));
hh.text(6).Text = num2str(area_i,'%.3d');
hh.regionArea.uit.Data.Areas{newExp2Plot_ind0} = area_i;
else
    
end
end

function apply2all(varargin)
global hh newExp2Plot_ind autoFct
stt = hh.regionArea;
ind = 1:size(stt.uit.Data,1);
for i = find(ind~=newExp2Plot_ind)
    newExp2Plot = double(stt.uit.Data.ExpNo{ind(i)});
    newExp2Plot_ind0 = ind(i);
    stt.plt(newExp2Plot_ind0).plt = plot_for_area_selection(stt,newExp2Plot,newExp2Plot_ind0,autoFct);
    clc
    hh.regionArea = stt;
    LIM = [hh.regionArea.X1.Value hh.regionArea.X2.Value];
    hh.text(3).Text = num2str(round(LIM(1),2));
    hh.text(4).Text = num2str(round(LIM(2),2));
    areaCalculation(newExp2Plot_ind0)
end
newExp2Plot = double(stt.uit.Data.ExpNo{newExp2Plot_ind});
stt.plt(newExp2Plot_ind).plt = plot_for_area_selection(stt,newExp2Plot,newExp2Plot_ind,autoFct);
clc
hh.regionArea = stt;
hh.text(6).Text = num2str(hh.regionArea.uit.Data.Areas{newExp2Plot_ind},'%.3d');
end

function zoomIN(varargin)
global hh newExp2Plot_ind
if ~isempty(newExp2Plot_ind)
    yy = hh.regionArea.ax(1).YLim;
    LIM = [hh.regionArea.X1.Value,hh.regionArea.X2.Value];
    hh.regionArea.ax(1).XLim = LIM;
    hh.regionArea.ax(1).YLim = yy;
else
    clc
    fprintf('No plot available')
end
end
function zoomOUT(varargin)
global hh newExp2Plot_ind
if ~isempty(newExp2Plot_ind)
    yy = hh.regionArea.ax(1).YLim;
    p = hh.regionArea.ax(1).Children;
    hh.regionArea.ax(1).XLim = [min(p.XData) max(p.XData)];
    hh.regionArea.ax(1).YLim = yy;
else
    clc
    fprintf('No plot available')
end
end

function areaDone(varargin)
global hh newExp2Plot_ind
if ~isempty(newExp2Plot_ind)
    LIM = [str2double(hh.text(3).Text),str2double(hh.text(4).Text)];
    ExpNo_Areas = hh.regionArea.uit.Data(:,[3,end]);
    hh.regionArea.results.LIM = LIM;
    hh.regionArea.results.ExpNo_Areas = ExpNo_Areas;
    hh.regionArea.results.ExpNoRef = ExpNo_Areas(newExp2Plot_ind,1);
    close(hh.regionArea.f(1))
else
    clc
    fprintf('No plot available')
end
end






