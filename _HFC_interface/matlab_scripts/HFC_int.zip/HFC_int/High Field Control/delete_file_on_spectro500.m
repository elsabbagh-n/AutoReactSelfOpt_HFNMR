function D = delete_file_on_spectro500(filePath,fileName)
% This function deletes files existing on a remonte PC. Hostname,
% Username and Password are set to the those of Spectro500.
%
% Input
% filePath      Path of the file to be deleted on the remote PC
% fileName      Name of the file to be deleted on the remote PC
% Output
% D             1 if file deleted, 0 not found

% Example :
% filePath = '/opt/topspin3.6.2/exp/stan/nmr/lists/bsms';
% fileName = 'ShimPlateauNES2';

%% User Input

% Required information about the remote PC (spectro 500MHz)
Hostname = '172.16.77.57';
Hostname = 'RMN500-1525.ceisam.sciences.univ-nantes.prive';
Username = 'nmr';
Password = 'topspin';
addpath(genpath('C:\Users\elsabbagh-n\Documents\MATLAB\Freedman_ssh'))

%% Check if file exists in path before deleting it

command = ['cd ' filePath ' ; ls'];
command_output = ssh2_simple_command(Hostname, Username, Password,command);
if ismember(fileName,command_output)
    command = ['cd ' filePath ' ; rm ' fileName];
    ssh2_simple_command(Hostname, Username, Password,command);
    D = 1;
    fprintf(['\n"' fileName '" file was deleted !\n'])
else
    D = 0;
    fprintf(['\nNo "' fileName '" file found to be deleted !\n'])
end

end





