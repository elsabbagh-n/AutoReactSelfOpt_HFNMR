function h = next_exps(h)
% This function updates the number of the experiment(s) (ExpNo) for
% auto-mode call.

% Table of the saved experiment with there parameters set by the user
TABLE = h.Experiment_Table(2:end,:);
if ~isempty(TABLE)
    list = [h.archive;h.Experiment_Table.ExpNo];
    for i = 1:size(TABLE,1)
        nb = 1;
        while (find(list==nb))
            nb = nb+1;
        end
        TABLE.ExpNo(i) = nb;
        list = [list;nb]; %#ok<AGROW>
    end
end
h.Experiment_Table(2:end,:) = TABLE;
end