function DONE = outd4NewProcessing(FileName,datasetPath,expList,varargin)
% This function adjust the outd before new processing on TOPSPIN to avoid
% printing error. Hostname, Username and Password are set to the those of
% Spectro500.
%
% No file transfer !
%
% Input
% FileName                Name of the folder to be checked
% datasetPath             Path of folder to be checked on the remote PC
% expList                 List of experiments to be checked
%
% expList = 16;FileName = '221109_2_test';datasetPath = '/opt/nmrdata/user/nmr/Nour';
% expList = 'all';FileName = '221109_1 - New';datasetPath ='C:\Users\elsabbagh-n\Documents\DataSet\';varargin = 1;
%% User Input
if isempty(varargin)
    remote = 1;
else
    remote = 0;
end
if remote
    % Required information about the remote PC (spectro 500MHz)
    Hostname = '172.16.77.57';
    Hostname = 'RMN500-1525.ceisam.sciences.univ-nantes.prive';
    Username = 'nmr';
    Password = 'topspin';
    % File path of the SCP functions
    addpath(genpath('C:\Users\elsabbagh-n\Documents\MATLAB\Freedman_ssh'))
end
%% Make sure that the corresponding folder are valid
if isempty(expList)
    return
elseif isa(expList,'char')
    if strcmpi(expList,'all')
        expAll = 1;
    else
        expAll = 0;
    end
else
    expAll = 0;
end
% Check if the main dataset folder is created
if remote
    command = ['cd ' datasetPath '/' FileName ' ; ls ;'];
    command_output = ssh2_simple_command(Hostname, Username, Password,command);
    expInFolder = zeros(length(command_output),1);
    for i = 1:length(command_output)
        expInFolder(i,1) = str2double(string(cell2mat(command_output(i))));
    end
else
    filename = fullfile(datasetPath,FileName);
    if exist(filename, 'dir')==7
        expInFolder = zeros(length(dir(filename))-2,1);
        n = {dir(filename).name};
        n = n(3:end);
        for i = 1:length(n)
            expInFolder(i,1) = str2double(n{i});
        end
    else
        error('File directory does not exist !')
    end
end
expInFolder = sort(expInFolder,'ascend');
if expAll
    expFound = expInFolder;
    if isempty(expFound)
        return
    end
else
    expFound = expList(ismember(expList,expInFolder));
    if isempty(expFound)
        return
    end
end
%% Edit outd file
DONE = zeros(length(expFound),1);
for i = 1:length(expFound)
    if expAll
        % Check if the outd file exists in the dataset folder
        command = ['cd ' datasetPath '/' FileName '/' num2str(expFound(i)) '/pdata/1 ; ls ;'];
        command_output = ssh2_simple_command(Hostname, Username, Password,command);
        if ismember('outd',command_output)
            % outd file available
            command = ['cd ' datasetPath '/' FileName '/' num2str(expFound(i)) '/pdata/1 ; cat outd;'];
            command_output = ssh2_simple_command(Hostname, Username, Password,command);
            % Find line to edit
            whichlines = find(contains(command_output,'CURPRIN'));
            if length(whichlines)>1
                for j = 2:length(whichlines)
                    % Delete extra line
                    command = ['cd ' datasetPath '/' FileName '/' num2str(expFound(i)) '/pdata/1; sed -i ''' num2str(whichlines(j)) 'd'' outd'];
                    % Edit outd
                    [~] = ssh2_simple_command(Hostname, Username, Password,command);
                end
            end
            % Line to add
            line2add = '##$CURPRIN= <integrals.txt>';
            % Command to add the line in the outd file
            command1 = ['cd ' datasetPath '/' FileName '/' num2str(expFound(i)) '/pdata/1; sed -i ''' num2str(whichlines) 'i' line2add ''' outd'];
            % Command to delete the previous the line in the outd file
            command2 = ['cd ' datasetPath '/' FileName '/' num2str(expFound(i)) '/pdata/1; sed -i ''' num2str(whichlines+1) 'd'' outd'];
            % Edit outd
            [~] = ssh2_simple_command(Hostname, Username, Password,command1);
            [~] = ssh2_simple_command(Hostname, Username, Password,command2);
            DONE(i) = 1;
        end
    else
        % Check if the outd file exists in the dataset folder
        filenameEXP = [FileName '\' num2str(expFound(i)) '\pdata\1\outd'];
        if exist(filenameEXP, 'file')==2
            AA = regexp(fileread(filenameEXP),'\n','split')';
            whichlines = find(contains(AA,'CURPRIN'));
            if ~isempty(whichlines)
                AA{whichlines} = '##$CURPRIN= <integrals.txt>';
                txt = strjoin(AA,'\n');
                fId = fopen(filenameEXP,'w');
                fprintf(fId,txt);
                fclose(fId);
            end
        else
            warning(['OUTD file does not exist in experiment n° '...
                num2str(expFound(i)) '!'])
        end
    end
end

% %#1
% p1 = [15.5193,14.2426,8738570.44;84.4807,85.7574,52616399.95];
% %#2
% p2 = [15.9245,14.4383,8568543;84.0755,85.5617,50777229.51];
% %#3
% p3 = [7.47004,7.7742,8698641.20;92.53,92.2258,103192546.73];
% %#4
% p4 = [9.04365,8.6211,9313419.97;90.9564,91.3789,98716998.64];
% %#5
% p5 = [10.1566,9.6174,9819370.41;89.8434,90.3826,92280541.28];
% %#10
% p10 = [20.8527,20.1630,23403660.61;79.1473,79.8370,92668407.95];
% %#21
% p21 = [60.8951,54.2832,27192571.75;39.1049,45.7168,22901344.43];
% %#22
% p22 = [59.5902,57.0910,27281597.32;33.9625,42.9090,20504573.54];
% %#23
% p23 = [60.7448,59.6822,27436085.12;29.2379,40.3178,18534232.97];
% %#24
% p24 = [70.2479,61.8514,27548192.12;29.752,38.1486,16991135.95];
% 
% poss = [1,2,3,4,5,10,24];
% poss = [21,22,23];
% a = zeros(2,length(poss)); %#ok<NASGU>
% b = zeros(2,length(poss)); %#ok<NASGU>
% c = zeros(2,length(poss)); %#ok<NASGU>
% for i = 1:length(poss)
%     eval(['a(1:2,i) = [p' num2str(poss(i)) '(1,1)-p' num2str(poss(i)) ...
%         '(1,2);p' num2str(poss(i)) '(2,1)-p' num2str(poss(i)) '(2,2)];'])
%     eval(['b(1:2,i) = [p' num2str(poss(i)) '(1,3)/p' num2str(poss(i)) ...
%         '(1,2);p' num2str(poss(i)) '(2,3)/p' num2str(poss(i)) '(2,2)];'])
%     eval(['c(1:2,i) = [(p' num2str(poss(i)) '(1,1)-p' num2str(poss(i)) ...
%         '(1,2))/p' num2str(poss(i)) '(1,3);(p' num2str(poss(i)) '(2,1)-p'...
%         num2str(poss(i)) '(2,2))/p' num2str(poss(i)) '(2,3)];'])
% end
end