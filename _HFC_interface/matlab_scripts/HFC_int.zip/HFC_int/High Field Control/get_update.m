function Tr = get_update(filePath,fileName,desiredPath)
% This function transfer files from a remonte PC to this PC. Hostname,
% Username and Password are set to the those of Spectro500. It transfers
% file of the selected folder, and files from its subfolders indicated. If
% the transfer is done successfully, it returns a value 1; if there were no
% transfer or the fileName didn't exist, it returns a nil value.
%
% Input
% filePath      Path of the file to be downloaded from the remote PC
% fileName      Name of the file to be downloaded from the remote PC
% desiredPath   Path to which the file will be download on this PC

% For test :
%   filePath = '/opt/nmrdata/user/nmr/Nour/220222/1/';
%   desiredPath = 'C:\Users\elsabbagh-n\Documents\DataSet';
%   fileName = 'fid';

%% User Input

% File path of this function
addpath(genpath('C:\Users\elsabbagh-n\Documents\MATLAB\Freedman_ssh'))

% Required information about the remote PC (spectro 500MHz)
Hostname = '172.16.77.57';
Hostname = 'RMN500-1525.ceisam.sciences.univ-nantes.prive';
Username = 'nmr';
Password = 'topspin';


%% File Upload

command = ['cd ' filePath ' ; ls'];
command_output = ssh2_simple_command(Hostname, Username, Password,command);

if ismember({fileName},command_output)
    % sometimes the transfer is fast, and the spectrum is transfered as
    % soon as it is saved, before the automatic phase proccessing is done
%     pause(0.1)
    clc
    
    % from the main folder
    gg = command_output(~ismember(command_output,{'pdata'}))';
    ssh2_conn = scp_simple_get(Hostname, Username, Password,gg,desiredPath, filePath);
    
    % and the sub folders
    if ismember({'pdata'},command_output)
        if ~isfolder([desiredPath 'pdata\1'])
            eval(['mkdir ''' desiredPath ''' pdata'])
            eval(['mkdir ''' [desiredPath 'pdata\'] ''' 1'])
        end
        filePath = [filePath 'pdata/1'];
        desiredPath = [desiredPath 'pdata\1'];
        fileName = '1r';
        Tr = transfer_from_spectro500(filePath,fileName,desiredPath);
    else
        Tr = 1;
    end
    ssh2_close(ssh2_conn); %close connection when done
else
    clc
    Tr = 0;
end
end






