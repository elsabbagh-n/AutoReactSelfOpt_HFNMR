function mkdir_spectro500(FileName,datasetPath,expList)
% This function creates the request experiment dataset folder in advance.
% Hostname, Username and Password are set to the those of Spectro500.
%
% No file transfer !
%
% Input
% FileName                Name of the folder to be created
% datasetPath             Path of folder to be created on the remote PC
% expList                 Requested experiments list

% FileName = char(h.Experiment_Table.Name(2));
% datasetPath = '/opt/nmrdata/user/nmr/Nour';
% expList = 1;
%% User Input

% Required information about the remote PC (spectro 500MHz)
Hostname = '172.16.77.57';
Hostname = 'RMN500-1525.ceisam.sciences.univ-nantes.prive';
Username = 'nmr';
Password = 'topspin';

%% Dataset folder creation check
% Create the main dataset folder
command = ['mkdir –p ' datasetPath '/' FileName '/ ;'];
ssh2_simple_command(Hostname, Username, Password,command);
for i = 1:length(expList)
    % Check if the main dataset folder is created
    command = ['mkdir –p ' datasetPath '/' FileName '/' num2str(expList(i)) ' ; '...
        'mkdir –p ' datasetPath '/' FileName '/' num2str(expList(i)) '/pdata/ ; '...
        'mkdir –p ' datasetPath '/' FileName '/' num2str(expList(i)) '/pdata/1/ ;'];
    ssh2_simple_command(Hostname, Username, Password,command);
end
end


