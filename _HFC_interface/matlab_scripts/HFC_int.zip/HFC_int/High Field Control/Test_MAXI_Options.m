%%
close all
clearvars
clc
skip = 1+0;
%%
if ~skip
    % File path of the HF-NMR interface script
    pathname = 'C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\Post_Doc_codes\Automation User Interface v5';
    addpath(genpath(pathname))
    % File path of the SCP functions
    addpath(genpath('C:\Users\elsabbagh-n\Documents\MATLAB\Freedman_ssh'))
    
    % WishList path
    wishlist = ['C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\Post_Doc_codes\'...
        'Automation User Interface v5\autoModeHandles.mat'];
    
    % Different conditions to be tested
    % cond = [FRsolvent(mL/min)   FRreactant(mL/min)  Cr  Tr(min)]
    load('C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\Post_Doc_codes\HF NMR timing\saveUntitled7.mat','u7')
    % u7.fct.Result.Table_1_Data(:,4:8)
    conditions = [[u7.fct.Result.Table_1_Data{:,8}]',...
        [u7.fct.Result.Table_1_Data{:,7}]',[u7.fct.Result.Table_1_Data{:,4}]',...
        [u7.fct.Result.Table_1_Data{:,5}]'];
    difCr = unique(conditions(:,3));
    difTr = unique(conditions(:,4));
    newConditions = [0.556 0.055 0.1 1.6367];
    for i = 1:length(difCr)
        [~,a] = ismember(conditions(:,3),difCr(i));
        %     find(a)
        store = conditions(find(a),:); %#ok<FNDSB>
        for j = 1:length(difTr)
            [~,b] = ismember(store(:,4),difTr(j));
            indc(j) = find(b); %#ok<*SAGROW>
        end
        newConditions = [newConditions;store(indc,:)];  %#ok<AGROW>
    end
    
    % % Conditions turn
    % route1 = [1 2 10 6 14 2 1];
    % route2 = [1 2 10 6 14 1 6 2 1];
    % newConditions(route1,:)
    % newConditions(route2,:)
    % Time0 = cell(length(route2),1);
    % t0 = datetime('now','Format','HH:mm:ss');
    % t0.Hour = 0;t0.Minute = 0;t0.Second = 0;
    % Time0(:) = {t0};
    %% Run experiments with control
    load(wishlist)
    autoModeHandles.Table.ExpNo(2) = 1;
    autoModeHandles.Table.Name(2) = "221020_7";
    autoModeHandles.archive = [];
    autoModeHandles.area = [0.9 1.4];
    autoModeHandles.areaRef = [3.1 3.6];
    save(wishlist,'autoModeHandles')
    [Area,Region] = ExtSet_GUI_function(wishlist,0,'maxc');
    % %% Save
    % %% Switch between conditions times
    % Time0{1}.Hour = 11;
    % Time0{1}.Minute = 41;
    % Time0{1}.Second = 00;
    
    load(wishlist)
    Results_11.Filename = char(autoModeHandles.Table.Name(2));
    Results_11.Area = Area;
    Results_11.Region = Region;
    FigureHandle = get(0, 'Children');
    for i = 1:length(FigureHandle)
        if strcmp(FigureHandle(i).Name,'Status')
            break
        end
    end
    Results_11.Table = FigureHandle(i).Children.Children(1).Children(end).Data;
    Results_11.Time0 = datetime('now','Format','HH:mm:ss');
    % Results_11.Time0.Hour = 15;
    % Results_11.Time0.Minute = 22;
    % Results_11.Time0.Second = 0;
    
    % %% Switch conditions
    
    % %%
    [exp_no,exp_times] = get_experiments_times_remote...
        (double([Results_11.Area.ExpNo{:}]),Results_11.Filename);
    Results_11.Times = exp_times;
    times_ = [Results_11.Times{:}]';
    areas = [Results_11.Area.Area{:}]';
    dareas = diff(areas);
    % dareas_t = diff(areas)./diff(times_);
    dareas = dareas/max(dareas);
    % dareas_t = dareas_t/max(dareas_t);
    figure
    yyaxis left;plot(times_-Results_11.Time0,areas,'-o','DisplayName','y = Area');
    yyaxis right,plot(times_(2:end)-Results_11.Time0,dareas,'-o','DisplayName','dy')
    save('C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\Post_Doc_codes\TestMAXI\Results_11.mat','Results_11')
end
%% Load
if ~skip
    times__ = [];
    times0_stabi_ = [datetime('19-10-2022 15:29:00','Format','dd-MM-yyyy HH:mm:ss') %1
        datetime('19-10-2022 15:50:00','Format','dd-MM-yyyy HH:mm:ss') %2
        datetime('19-10-2022 16:26:04','Format','dd-MM-yyyy HH:mm:ss') %3
        datetime('19-10-2022 16:54:00','Format','dd-MM-yyyy HH:mm:ss') %4
        datetime('19-10-2022 17:34:00','Format','dd-MM-yyyy HH:mm:ss') %5
        datetime('19-10-2022 00:00:00','Format','dd-MM-yyyy HH:mm:ss') %6
        datetime('19-10-2022 00:00:00','Format','dd-MM-yyyy HH:mm:ss') %7
        datetime('20-10-2022 15:23:00','Format','dd-MM-yyyy HH:mm:ss') %8
        datetime('20-10-2022 16:12:00','Format','dd-MM-yyyy HH:mm:ss') %9
        datetime('20-10-2022 16:56:00','Format','dd-MM-yyyy HH:mm:ss') %10
        datetime('20-10-2022 17:32:00','Format','dd-MM-yyyy HH:mm:ss')]; %11
    times0_stabi_.Format = 'HH:mm:ss';
    times0_exp_ = [datetime('19-10-2022 15:29:00','Format','dd-MM-yyyy HH:mm:ss') %1
        times0_stabi_(3) %2
        datetime('19-10-2022 16:26:04','Format','dd-MM-yyyy HH:mm:ss') %3
        datetime('19-10-2022 16:54:00','Format','dd-MM-yyyy HH:mm:ss') %4
        datetime('19-10-2022 17:51:00','Format','dd-MM-yyyy HH:mm:ss') %5
        datetime('19-10-2022 00:00:00','Format','dd-MM-yyyy HH:mm:ss') %6
        datetime('19-10-2022 00:00:00','Format','dd-MM-yyyy HH:mm:ss') %7
        datetime('20-10-2022 15:38:00','Format','dd-MM-yyyy HH:mm:ss') %8
        datetime('20-10-2022 16:27:00','Format','dd-MM-yyyy HH:mm:ss') %9
        datetime('20-10-2022 17:11:00','Format','dd-MM-yyyy HH:mm:ss') %10
        datetime('20-10-2022 17:47:00','Format','dd-MM-yyyy HH:mm:ss')]; %11
    times0_exp_.Format = 'HH:mm:ss';
    areas__ = [];
    dareas__ = [];
    FR_exp_ = [0.667;0.661;0.667;0.316;0.666;0;0;0.25;0.316;0.429;0.666];
    CR_exp_ = [0.2;0.1;0.2;0.3;0.4;0;0;0.5;0.5;0.5;0.5];
    FR_stabi_ = [0.611;0.611;0.611;0.611;0.611;0;0;0.611;0.611;0.611;0.611];
    CR_stabi_ = [0.1;0.1;0.1;0.1;0.1;0;0;0.1;0.1;0.1;0.1];
end
for i = 1:1
    pause(0.2)
    drawnow
eval(['f' num2str(i) ' = figure2;hold on'])
end
%%
figure2;
t = tiledlayout(1,2,'TileSpacing','compact');
bgAx = axes(t,'XTick',[],'YTick',[],'Box','off');
bgAx.Layout.TileSpan = [1 2];
bgAx.Visible = 'off';
% Create first plot
ax01 = axes(t);
hold on
ax01.Box = 'off';
ax01.XAxis.Visible = 'on';
% ax01.XTickLabel = [];
ylabel(ax01, 'Area')
% xlim(ax01, 'auto')
ylim(ax01, [-0.2 1.2])
% Create second plot
ax02 = axes(t);
hold on
ax02.Layout.Tile = 2;
ax02.Box = 'off';
ylabel(ax02,'Area')
% xlim(ax02, 'auto')
ylim(ax02, [-0.2 1.2])

% Link the axes
linkaxes([ax01 ax02], 'x')
xlim([ax01 ax02], 'auto')
title(t,{'Evolution of Area normalized',...
    ['Transition from concentration ratio of 0.1 to 0.5' sprintf('%40s','') 'Transition from concentration ratio of 0.5 to 0.1']})
xlabel(ax01,'Pumped Volume (mL)')
xlabel(ax02,'Pumped Volume (mL)')
pause(0.2)
drawnow
%%
figure2;
t = tiledlayout(2,2,'TileSpacing','compact');
bgAx = axes(t,'XTick',[],'YTick',[],'Box','off');
bgAx.Layout.TileSpan = [2 2];
bgAx.Visible = 'off';
% Create first plot
ax1 = axes(t);
hold on
ax1.Box = 'off';
ax1.XAxis.Visible = 'on';
% ax1.XTickLabel = [];
ylabel(ax1, 'Area')
% Create second plot
ax1d = axes(t);
hold on
ax1d.Layout.Tile = 3;
ax1d.Box = 'off';
ylabel(ax1d,'\partialArea')
% Create first plot
ax2 = axes(t);
hold on
ax2.Layout.Tile = 2;
ax2.Box = 'off';
ax2.XAxis.Visible = 'on';
% ax2.XTickLabel = [];
ylabel(ax2, 'Area')
% Create second plot
ax2d = axes(t);
hold on
ax2d.Layout.Tile = 4;
ax2d.Box = 'off';
ylabel(ax2d,'\partialArea')

% Link the axes
linkaxes([ax1 ax1d], 'x')
linkaxes([ax2 ax2d], 'x')
title(t,{'Evolution of Area and dArea vs Time during flow experiment',...
    ['Transition from concentration ratio of 0.1 to 0.5' sprintf('%40s','') 'Transition from concentration ratio of 0.5 to 0.1']})
xlim([ax1 ax1d ax2 ax2d], 'auto')
xlabel(ax1d,'Time')
xlabel(ax2d,'Time')
% plot(ax1,x,y,'-o','MarkerSize',3,'Color',[0,0.45,0.74],'DisplayName','Area')
% plot(ax1d,x(2:end),diff(y),'-o','MarkerSize',3,'Color',[0.85,0.33,0.1],'DisplayName','\partialArea')
% title('Transition from concentration ratio of 0.1 to 0.5 with different flowrates')
% title('Transition from concentration ratio of 0.5 to 0.1 with the same flowrate')
pause(0.2)
drawnow
%%
figure2;
t = tiledlayout(2,2,'TileSpacing','compact');
bgAx = axes(t,'XTick',[],'YTick',[],'Box','off');
bgAx.Layout.TileSpan = [2 2];
bgAx.Visible = 'off';
% Create first plot
ax1_ = axes(t);
hold on
ax1_.Box = 'off';
ax1_.XAxis.Visible = 'on';
% ax1_.XTickLabel = [];
ylabel(ax1_, 'Area')
% Create second plot
ax1d_ = axes(t);
hold on
ax1d_.Layout.Tile = 3;
ax1d_.Box = 'off';
ylabel(ax1d_,'\partialArea')
% Create first plot
ax2_ = axes(t);
hold on
ax2_.Layout.Tile = 2;
ax2_.Box = 'off';
ax2_.XAxis.Visible = 'on';
% ax2_.XTickLabel = [];
ylabel(ax2_, 'Area')
% Create second plot
ax2d_ = axes(t);
hold on
ax2d_.Layout.Tile = 4;
ax2d_.Box = 'off';
ylabel(ax2d_,'\partialArea')

% Link the axes
linkaxes([ax1_ ax1d_], 'x')
linkaxes([ax2_ ax2d_], 'x')
xlim([ax1_ ax1d_ ax2_ ax2d_], 'auto')
title(t,{'Evolution of Area and dArea vs Pumped Volume during flow experiment',...
    ['Transition from concentration ratio of 0.1 to 0.5' sprintf('%40s','') 'Transition from concentration ratio of 0.5 to 0.1']})
xlabel(ax1d_,'Pumped Volume (mL)')
xlabel(ax2d_,'Pumped Volume (mL)')
% plot(ax1,x,y,'-o','MarkerSize',3,'Color',[0,0.45,0.74],'DisplayName','Area')
% plot(ax1d,x(2:end),diff(y),'-o','MarkerSize',3,'Color',[0.85,0.33,0.1],'DisplayName','\partialArea')
% title('Transition from concentration ratio of 0.1 to 0.5 with different flowrates')
% title('Transition from concentration ratio of 0.5 to 0.1 with the same flowrate')
pause(0.2)
drawnow
%%
Cratio_all = [0.1 0.2 0.3 0.4 0.5];
Cratio_all = [0.121519 0545 0.3 0.4 0.5];
FR_all = [0.250 0.316 0.429 0.611 0.666 0.667];
Cratio_all_color = {[0.00,0.45,0.74],[0.00,0.45,0.74],[0.85,0.33,0.10],[0.93,0.69,0.13],[0.49,0.18,0.56]};
FR_all_shape = {'-','--','-.',':','-',':'};
mrker = 'o';
linewdth = 1;
for i = 28:29%[1:5 11:-1:8 12:26]%%
    %%
    j = i;
    load(['C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\Post_Doc_codes\TestMAXI\'...
        'Results_' num2str(i) '.mat'])
    eval(['Res = Results_' num2str(i) ';'])
    
    label0 = {['#' num2str(j,'%02d')]};
    if ~skip
        label1 = {num2str(CR_exp_(j))};
        label1_ = {num2str(CR_stabi_(j))};
        label2 = {[num2str(round(FR_exp_(j),3),'%0.3f') 'mL/min']};
        label2_ = {[num2str(round(FR_stabi_(j),3),'%0.3f') 'mL/min']};
    else
        label1 = {num2str(Res.CR_exp)};
        label1_ = {num2str(Res.CR_stabi)};
        label2 = {[num2str(round(Res.FR_exp,3),'%0.3f') 'mL/min']};
        label2_ = {[num2str(round(Res.FR_stabi,3),'%0.3f') 'mL/min']};
    end
    label_exp = cellfun(@(x,y,z) {sprintf('%3s%10s%18s', x, y,z)}, label0, label1, label2);
    label_stabi = cellfun(@(x,y,z) {sprintf('%3s%10s%18s', x, y,z)}, label0, label1_, label2_);
    

    if iscell(Res.Times)
        times_ = [Res.Times{:}]';
    else
        times_ = Res.Times;
    end
    times0_ = Res.Time0;
    if isstruct(Res.Area)
        areas = [Res.Area.Area{:}]';
    elseif istable(Res.Area)
        areas = [Res.Area.Area{:}]';
    else
        areas = Res.Area;
    end
    dareas = diff(areas);
    % dareas_t = diff(areas)./diff(times_);
    
    % dareas_t = dareas_t/max(dareas_t);
    
    if skip
        times0_stabi_(j) = Res.Time00;
        times0_exp_(j) = Res.Time0;
        FR_stabi_(j) = Res.FR_stabi;
        FR_exp_(j) = Res.FR_exp;
    else
        times__ = [times__;times_]; %#ok<AGROW>
        %     times0__ = [times0__;times0_]; %#ok<AGROW>
        areas__ = [areas__;areas]; %#ok<AGROW>
        dareas__ = [dareas__;dareas]; %#ok<AGROW>
    end

    [h,m,s] = hms(times_);
    t_minutes = h*60+m+s/60;
    ind1 = find(times_>=times0_stabi_(j));
    ind2 = find(times_<times0_exp_(j));
    [~,ind_stabi] = ismember(ind1,ind2);
    ind_stabi(ind_stabi==0) = [];
    ind_stabi_ = ind2;
    ind_exp = find(times_>=times0_exp_(j));
    if ind_stabi_
        if ind_stabi_(end)>10
            dareas(ind_stabi_(1:end-1)) = -(-dareas(ind_stabi_(1:end-1)))/max(-dareas(ind_stabi_(1:end-1)));
        end
    end
    if ind_exp
        dareas(ind_exp(1:end-1)) = dareas(ind_exp(1:end-1))/max(dareas(ind_exp(1:end-1)));
    end
        
    [h,m,s] = hms(times0_stabi_(j));
    t0_minutes_stabi = h*60+m+s/60;
    t_minutes_stabi = t_minutes-t0_minutes_stabi;
    [h,m,s] = hms(times0_exp_(j));
    t0_minutes_exp = h*60+m+s/60;
    t_minutes_exp = t_minutes-t0_minutes_exp;
    
    
    V_InMinutes_ = [t_minutes(ind_stabi_)*FR_stabi_(j);t_minutes(ind_exp)*FR_exp_(j)];
    V_InMinutes_stabi = [t_minutes_stabi(ind_stabi_)*FR_stabi_(j);t_minutes_stabi(ind_exp)*FR_exp_(j)];
    V_InMinutes_exp = [t_minutes_exp(ind_stabi_)*FR_stabi_(j);t_minutes_exp(ind_exp)*FR_exp_(j)];
    
    if ~isempty(ind_stabi)
        V_InMinutes_(ind_stabi_) = V_InMinutes_(ind_stabi_)-t0_minutes_stabi*FR_stabi_(j);
    end
    if ~isempty(ind_exp)
        V_InMinutes_(ind_exp) = V_InMinutes_(ind_exp)-t0_minutes_exp*FR_exp_(j);
    end
    
    %%
    i
    indc = ismember(Cratio_all,Res.CR_exp);
    c = Cratio_all_color{indc}; % color
    inds = ismember(FR_all,round(Res.FR_exp,3));
    s = FR_all_shape{inds};% shape
    if find(inds)==1
        if find(indc)==2
            label_exp = cellfun(@(x) {sprintf('C_r = %s',x)},label1);
        elseif find(indc)==3
            label_exp = cellfun(@(x,y) {sprintf('C_r = %s  %s',x,y)},label1,{label2{1}(1:5)});
        elseif find(indc)==4
            label_exp = cellfun(@(x,y) {sprintf('C_r = %s  %s',x,y)},label1,{label2{1}(6:end)});
        elseif find(indc)==5
            label_exp = cellfun(@(x) {sprintf('C_r = %s',x)},label1);
%         label_exp = cellfun(@(x) {sprintf('FR = %s', x)}, label2);
        end
    else
        if find(inds)==6
            label2{1}(1:5) = '0.666';
        end
        label_exp = cellfun(@(x) {sprintf('FR = %s', x)}, label2);
    end
    
    figure(f1)
    yyaxis left
    plot(times_,areas,'Color',c,'LineStyle',s,'LineWidth',linewdth,'Marker',mrker,'DisplayName',label_exp{1});
    yyaxis right,plot(times_(2:end),dareas,'Color',c,'LineStyle',s,'LineWidth',linewdth,'Marker',mrker,...
        'DisplayName',['#' num2str(j,'%02d')])
    pause(0.2)
    drawnow
    t = times_(ind_stabi);
%     figure(f2)
%     plot(t-times0_stabi_(j),areas(ind_stabi),'Marker','.','DisplayName',label_stabi{1});
%     figure(f3)
%     plot(t(2:end)-times0_stabi_(j),dareas(ind_stabi(1:end-1)),'Marker','.',...
%         'DisplayName',label_stabi{1})
%     pause(0.2)
%     drawnow    
    plot(ax2,t-times0_stabi_(j),areas(ind_stabi),'Color',c,'LineStyle',s,'LineWidth',linewdth,'Marker',mrker,'DisplayName',label_stabi{1});
    plot(ax2d,t(2:end)-times0_stabi_(j),dareas(ind_stabi(1:end-1)),'Color',c,'LineStyle',s,'LineWidth',linewdth,'Marker',mrker,...
        'DisplayName',label_stabi{1})
    pause(0.2)
    drawnow
    t = times_(ind_exp);
%     figure(f4)
%     plot(t-times0_exp_(j),areas(ind_exp),'Marker','.','DisplayName',label_exp{1});
%     figure(f5)
%     plot(t(2:end)-times0_exp_(j),dareas(ind_exp(1:end-1)),'Marker','.',...
%         'DisplayName',label_exp{1})
%     pause(0.2)
%     drawnow
    plot(ax1,t-times0_exp_(j),areas(ind_exp),'Color',c,'LineStyle',s,'LineWidth',linewdth,'Marker',mrker,'DisplayName',label_exp{1});
    plot(ax1d,t(2:end)-times0_exp_(j),dareas(ind_exp(1:end-1)),'Color',c,'LineStyle',s,'LineWidth',linewdth,'Marker',mrker,...
        'DisplayName',label_exp{1})
    pause(0.2)
    drawnow
    
    
%     figure(f6)
%     plot(V_InMinutes_(ind_exp),areas(ind_exp),'Marker','.','DisplayName',label_exp{1});
%     figure(f7)
%     plot(V_InMinutes_(ind_exp(2:end)),dareas(ind_exp(1:end-1)),'Marker','.',...
%         'DisplayName',label_exp{1})
    plot(ax1_,V_InMinutes_(ind_exp),areas(ind_exp),'Color',c,'LineStyle',s,'LineWidth',linewdth,'Marker',mrker,'DisplayName',label_exp{1});
    plot(ax1d_,V_InMinutes_(ind_exp(2:end)),dareas(ind_exp(1:end-1)),'Color',c,'LineStyle',s,'LineWidth',linewdth,'Marker',mrker,...
        'DisplayName',label_exp{1})
    pause(0.2)
    drawnow
%     figure(f8)
%     plot(V_InMinutes_(ind_stabi),areas(ind_stabi),'Marker','.','DisplayName',label_stabi{1});
%     figure(f9)
%     plot(V_InMinutes_(ind_stabi(2:end)),dareas(ind_stabi(1:end-1)),'Marker','.',...
%         'DisplayName',label_stabi{1})
    plot(ax2_,V_InMinutes_(ind_stabi),areas(ind_stabi),'Color',c,'LineStyle',s,'LineWidth',linewdth,'Marker',mrker,'DisplayName',label_stabi{1});
    plot(ax2d_,V_InMinutes_(ind_stabi(2:end)),dareas(ind_stabi(1:end-1)),'Color',c,'LineStyle',s,'LineWidth',linewdth,'Marker',mrker,...
        'DisplayName',label_stabi{1})
    pause(0.2)
    drawnow
    
%     figure(f2)
    a = areas(ind_exp);
    if a
        a = a-min(a(1:4));
        a = a/max(a(end-3:end));
%         plot(V_InMinutes_(ind_exp),a,'Marker','.','DisplayName',label_exp{1});
        plot(ax01,V_InMinutes_(ind_exp),a,'Color',c,'LineStyle',s,'LineWidth',linewdth,'Marker',mrker,'DisplayName',label_exp{1});
        pause(0.2)
        drawnow
    end
%     figure(f3)
    a = areas(ind_stabi);
    if a
        a = a-min(a(end-3:end));
        a = a/max(a(1:4));
%         plot(V_InMinutes_(ind_stabi),a,'Marker','.','DisplayName',label_stabi{1});
        plot(ax02,V_InMinutes_(ind_stabi),a,'Color',c,'LineStyle',s,'LineWidth',linewdth,'Marker',mrker,'DisplayName',label_stabi{1});
        pause(0.2)
        drawnow
    end
end

ax_ = {'ax01','ax02','ax1d','ax2d','ax1d_','ax2d_'};
loc_ax_ = {'east','east','northeast','southeast','northeast','southeast'};
for i = 1:length(ax_)
    eval(['l = legend(' ax_{i} ');'])
    titles = {'Line  °', 'C_r', 'FR_{tot}'};
    titles = sprintf('%0s%13s%23s', titles{:});
    l.Title.String = titles;
    l.Location = loc_ax_{i};
end
return
%%
FigureHandle = get(0, 'Children');
for i = 1:length(FigureHandle)
    figure(FigureHandle(i))
    % eval(['figure(f' num2str(i) ')'])
    l = legend;
    titles = {'Line  °', 'C_r', 'FR_{tot}'};
    titles = sprintf('%0s%13s%23s', titles{:});
    l.Title.String = titles;
end
for i = 6:11
eval(['figure(f' num2str(i) ')'])
xlabel('Volume pumped (mL)')
end
for i = [2:2:10 11]
eval(['figure(f' num2str(i) ')'])
ylabel('Area')
end
for i = 2:5
eval(['figure(f' num2str(i) ')'])
xlabel('Time')
end
return
title('Transition from concentration ratio of 0.1 to 0.5 with different flowrates')
title('Transition from concentration ratio of 0.5 to 0.1 with the same flowrate')
return
figure(f2)
xlabel('Time (min)')
yyaxis left
ylabel('Area')
yyaxis right
ylabel('d(Area)')
title('Area vs time since the start of the stabilization')
legend('Location','southeast')

figure(f3)
xlabel('Time (min)')
yyaxis left
ylabel('Area')
yyaxis right
ylabel('d(Area)')
title('Area vs time since the start of the stabilization')
legend('Location','east')

figure(f4)
xlabel('Time (min)')
yyaxis left
ylabel('Area')
yyaxis right
ylabel('d(Area)')
title('Area vs time since the start of the stabilization')
legend('Location','east')

figure(f5)
xlabel('Time (min)')
yyaxis left
ylabel('Area')
yyaxis right
ylabel('Pumped volume (mL)')
title('Area vs time since the start of the stabilization')
legend('Location','southeast')

figure(f5)
xlabel('Pumped volume (mL)')
yyaxis left
ylabel('Area')
yyaxis right
ylabel('d(Area)')
title('Area vs time since the start of the stabilization')
legend('Location','east')

return

figure(f3)
xlabel('Volume (min)')
yyaxis left
ylabel('Area')
yyaxis right
ylabel('d(Area)')
title('Area vs volume since the start of the stabilization')
figure(f4)
xlabel('Time (h:m:s)')
yyaxis left
ylabel('Area')
yyaxis right
ylabel('d(Area)')
title('Area vs time of acquisition')
figure(f5)
xlabel('Time (min)')
yyaxis left
ylabel('Area')
yyaxis right
ylabel('d(Area)')
title('Area vs time since the start of the experiment')
figure(f5)
xlabel('Volume (min)')
yyaxis left
ylabel('Area')
yyaxis right
ylabel('d(Area)')
title('Area vs volume since the start of the experiment')
%%
return
x = times__;
y = areas__;
[h,m,s] = hms(x);
x_minutes = h*60+m+s/60;
FR = [ (0.556+0.111) (0.556+0.055) (0.556+0.111)  (0.243+0.073) (0.556+0.055) (0.476+0.19)];
lst = times0_stabi_(end);lst.Minute = 51;
stages_ = [times0_stabi_;lst;times__(end)];
stages_ = sort(stages_,'ascend');
for i = 1:length(stages_)-1
    indc = ((x>=stages_(i)) + (x<= stages_(i+1)));
    a = find(indc==2);
    [h,m,s] = hms(stages_(i));
    x_ = x_minutes(a)-h*60+m+s/60;
    x_ = x_-x_(1);
    V_mL(a) = x_*FR(i);
end

f2 = figure('Units','normalized','Position',[0 0.0556 1 0.8435]);
movegui(gcf,'center');
t = tiledlayout(2,1,'TileSpacing','compact');
bgAx = axes(t,'XTick',[],'YTick',[],'Box','off');
bgAx.Layout.TileSpan = [2 1];
bgAx.Visible = 'off';
ax1 = axes(t);
hold on
yyaxis(ax1,'left')
plot(ax1,x,y,'-o','MarkerSize',3,'Color',[0,0.45,0.74],'DisplayName','Area')
ylabel(ax1, 'Area')
ax1.Box = 'off';
ax1.XAxis.Visible = 'on';
ax1.XTickLabel = [];
% Create second plot
ax1d = axes(t);
hold on
yyaxis(ax1,'left')
ax1d.Layout.Tile = 2;
plot(ax1d,x(2:end),diff(y),'-o','MarkerSize',3,'Color',[0.85,0.33,0.1],'DisplayName','\partialArea')
ax1d.Box = 'off';
ylabel(ax1d,'\partialArea')
% Link the axes
linkaxes([ax1 ax1d], 'x')
title(t,'Evolution of Area and dArea during flow experiment')
% Stages and blocks Limits
xl1 = xline(ax1,stages_,':','HandleVisibility','off');
xl2 = xline(ax1d,stages_,':','HandleVisibility','off');
ylim01 = ylim(ax1);
dylim01 = ylim01(2)-ylim01(1);
ylim02 = ylim(ax1d);
dylim02 = ylim02(2)-ylim02(1);
area_y01 = [(ylim01(1)+dylim01*0.01)*ones(2,1);(ylim01(2)-dylim01*0.01)*ones(2,1)];
area_y02 = [(ylim02(1)+dylim02*0.01)*ones(2,1);(ylim02(2)-dylim02*0.01)*ones(2,1)];
area_cond_1 = [stages_([2,5]),stages_([3,6])];
area_cond_2 = [stages_([1,3]),stages_([2,4])];
area_cond_3 = [stages_(4),stages_(5)];
area_cond_4 = [stages_(6),stages_(7)];

area_cond_1_x = [[area_cond_1(1,:)';flipud(area_cond_1(1,:)')],...
    [area_cond_1(2,:)';flipud(area_cond_1(2,:)')]];
area_cond_2_x = [[area_cond_2(1,:)';flipud(area_cond_2(1,:)')],...
    [area_cond_2(2,:)';flipud(area_cond_2(2,:)')]];
area_cond_3_x = [area_cond_3(1,:)';flipud(area_cond_3(1,:)')];
area_cond_4_x = [area_cond_4(1,:)';flipud(area_cond_4(1,:)')];
for i = 1:2
    eval(['ax = ax' num2str(i) ';'])
    eval(['area_y0 = area_y0' num2str(i) ';'])
    area1 = fill(ax,area_cond_1_x,area_y0.*ones(4,2),[1 0.9569 0.8510]);
    area1(1).EdgeColor = 'none';
    area1(2).EdgeColor = 'none';
    area1(1).DisplayName = 'Cond 1';
    area1(2).DisplayName = 'Cond 1';
    area2 = fill(ax,area_cond_2_x,area_y0.*ones(4,2),[0.9412 1 0.9020]);
    area2(1).EdgeColor = 'none';
    area2(2).EdgeColor = 'none';
    area2(1).DisplayName = 'Cond 2';
    area2(2).DisplayName = 'Cond 2';
    area3 = fill(ax,area_cond_3_x,area_y0.*ones(4,1),[0.9686 0.9216 1]);
    area3(1).EdgeColor = 'none';
    area3(1).DisplayName = 'Cond 3';
    area4 = fill(ax,area_cond_4_x,area_y0.*ones(4,1),[1 0.9020 0.9020]);
    area4(1).EdgeColor = 'none';
    area4(1).DisplayName = 'Cond 4';
end

ax1.Children = circshift(ax1.Children,1);
ax1d.Children = circshift(ax1d.Children,1);
legend(legendUnq(ax1))
legend(legendUnq(ax1d))
legend(ax1,'Location','best')
legend(ax1d,'Location','best')
xlim([min(stages_)-5*minutes max(stages_)+5*minutes])
%%

yyaxis(ax1,'right')
hold on
plot(ax1,x,V_mL,'o','MarkerSize',1,'DisplayName','Volume')
% v = 10.2291;
v = 7.15653;
% v = 5.46841;
mm = mink(abs(V_mL-v),7);
for i = [1:7]
xline(ax1,x(find(abs(V_mL-v)==mm(i))),'HandleVisibility','off')
end
yline(ax1,5.46841,'HandleVisibility','off')
ylabel(ax1, 'Filled volume (mL)')
yyaxis(ax1d,'right')
plot(ax1d,x,V_mL,'o','MarkerSize',1,'DisplayName','Volume')
ylabel(ax1d, 'Filled volume (mL)')
%% Functions
% Get experiments times of acquisition on remote computer
function [exp_no,exp_times] = get_experiments_times_remote(exp_nos,varargin)
global fct
if isempty(exp_nos)
    return
end
if exp_nos==0
    return
end
exp_times = cell(length(exp_nos),0);
exp_no = cell(length(exp_nos),0);
if isempty(varargin)
    filename = fct.Table(1).Data{1,1};
else
    filename = varargin{1};
end
for i = 1:length(exp_nos)
    if isempty(varargin)
        % Ind in Area matrix
        [~,ind] = ismember(cell2mat(fct.Area.ExpNo),exp_nos(i));
        ind = find(ind,1);
        % exp_nb = str2double(fct.Table(1).Data{i,3}) + (j-1)*nb_of_experiments_in_block;
        exp_nb = double(fct.Area.ExpNo{ind});
    else
        exp_nb = exp_nos(i);
    end
    FilePath = ['/opt/nmrdata/user/nmr/Nour/' filename '/' num2str(exp_nb) '/'];
    Fid = 'fid';
    % Get Date and Time of fid file on remote computer
    DateTime = get_date_time_file_spectro500(FilePath,Fid);
    % Output
    exp_times(i,1) = {datetime(DateTime,'format','HH:mm:ss')};
    exp_no(i,1) = {exp_nb};
    fprintf(['\nExp n° ' num2str(exp_nb) '/' num2str(length(exp_nos)) ' done.\n'])
end
end




















