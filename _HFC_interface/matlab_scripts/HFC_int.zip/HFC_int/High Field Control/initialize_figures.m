function figure_handles = initialize_figures(whichFigure,screen,autoMode,varargin)
% This function creates the spectrometer500 communication & control (C&C)
% interface and the status window. It returns the figure handles if asked
% for and save them in the path inputted (saveHere).
%
% PS : for now, the interface generation is not integrated in the function
% (whichFigure=1).
%
% Input
%   whichFigure     1 for the C&C interface, 2 for the status window
%   (required)
%
%   screen          number of Monitor screens available.
%   (required)
%
%   automode        1 for automode and 0 for manual mode.
%   (required only for whichFigure=2)
%
%   saveHere        the path in which the created figure is saved. If not
%   (optional)      inserted, the handles of the created figure are not saved.
%
% Output
%   figure_handles  the handles of the created figure.
%   (optional)
%
% Nour EL SABBAGH - 2022

tab = 1+0;

% Evaluate the input argument
if ~(size(varargin,2)==0)
    saveHere = varargin{1};
    saving = 1;
else
    saving = 0;
end

% Create figure handles
if whichFigure==1
    % Interface handles
elseif whichFigure==2
    if tab
        % Status window handles
        if screen==1
            fig.F = uifigure('units','normalized','position',...
                [0.0363 0.3063 0.9273 0.3556],'Name','Status',...
                'HandleVisibility','on','Visible','off');
        else
            fig.F = uifigure('units','normalized','position',...
                [-0.9594 0.1949 0.5859 0.2556],'Name','Status',...
                'HandleVisibility','on','Visible','off');
        end
        movegui(gcf,'center');
        
        % Create Tabs
        G = uitabgroup(fig.F,'Units','normalized','Position',[0 0 1 1]);
        TAB(1) = uitab(G,'Title','Status table & Area setup');
        TAB(2) = uitab(G,'Title','Graphical Application Update');
        
        % Generate the Graphical Application Update Tab handles
        fig = graphical_application_update(fig,screen);
        
        % Get the Status table Tab
        G.SelectedTab = TAB(1);
        fig.f(1) = TAB(1);
    else
        % Window for the status update
        if screen==1
            fig.f(1) = uifigure('units','normalized','position',...
                [0.0363 0.3063 0.9273 0.3556],'Name','Status',...
                'HandleVisibility', 'on','Visible','off');
        else
            fig.f(1) = uifigure('units','normalized','position',...
                [-0.9594 0.1949 0.5859 0.2556],'Name','Status',...
                'HandleVisibility','on','Visible','off');
        end
        movegui(gcf,'center');
    end
    
    % Table for experiment updating
    Date = [];Holder = [];ExpNo = [];Experiment = [];Solvent = [];
    Title = [];Available = [];Submitted = [];Running = [];Completed = [];
    Deleted = [];Area = [];RelativeArea = [];...
        AdditionalArea = [];RelativeAdditionalArea = [];
    t0 = table(Date,Holder,ExpNo,Experiment,Solvent,Title,Available,...
        Submitted,Running,Completed,Deleted,Area,RelativeArea,...
        AdditionalArea,RelativeAdditionalArea);
    fig.uit = uitable(fig.f(1),'Data',t0,'Units','normalized',...
        'Position',[0.02 0.3618 0.96 0.5820]);
    
    % Buttons to go and calculate the area
    fig.radiobuttonGroup(1) = uibuttongroup(fig.f(1),...
        'Position',[23 10 410 75]);
    fig.radiobutton(1) = uiradiobutton(fig.radiobuttonGroup(1),...
        'Text','Target','Value',1,'Position',[5 45 91 22],...
        'FontSize',15);
    fig.radiobutton(2) = uiradiobutton(fig.radiobuttonGroup(1),...
        'Text','Reference','Value',0,'Position',[5 10 91 22]....
        ,'FontSize',15);
    fig.button(1) = uibutton(fig.f(1),'push','Text','Set area region',...
        'Position',[130 50 150 30],'FontSize',20,'BackgroundColor',...
        [0.3,0.75,0.93],'FontColor',[1,1,1]);
    fig.button(2) = uibutton(fig.f(1),'push','Text','Area calculation',...
        'Position',[440 25 200 50],'FontSize',20,'Enable','off',...
        'BackgroundColor',[0.47,0.8,0.04],'FontColor',[1,1,1]);
    fig.button(3) = uibutton(fig.f(1),'push','Text','DONE',...
        'Position',[950 25 150 50],'FontSize',20,'Enable','off',...
        'BackgroundColor',[1,0.41,0.16],'FontColor',[1,1,1]);
    fig.text(1) = uilabel(fig.f(1),'Position',[660 65 500 20],...
        'FontSize',17,'Text',{'Target       : [  ppm ,  ppm ]'});
    fig.text(2) = uilabel(fig.f(1),'Position',[660 10 500 20],...
        'FontSize',17,'Text',{'Max area is for exp°  : '});
    fig.text(3) = uilabel(fig.f(1),'Position',[130 15 260 30],...
        'FontSize',17,'Text',{'Or insert: [              ,              ] ppm'});
    fig.text(4) = uilabel(fig.f(1),'Position',[290 50 85 30],...
        'FontSize',15,'Text',{'of ExpNo° '});
    fig.text(5) = uilabel(fig.f(1),'Position',[660 37.5 500 20],...
        'FontSize',17,'Text',{'Reference: [  ppm ,  ppm ]'});
    fig.uitextarea(1) = uitextarea(fig.f(1),'Value',' ',...
        'Position',[213 15 60 30],'FontSize',15);
    fig.uitextarea(2) = uitextarea(fig.f(1),'Value',' ',...
        'Position',[284 15 60 30],'FontSize',15);
    fig.uitextarea(3) = uitextarea(fig.f(1),'Value',' ',...
        'Position',[375 50 35 30],'FontSize',15);
    
    % Set style for uitable
    fig.colorGrad = colorGradient([1 1 0],[0.04,0.74,0.00],4);
    fig.sHiLite(1:5) = uistyle;
    fig.sHiLite(1).BackgroundColor = fig.colorGrad(1,:);
    fig.sHiLite(2).BackgroundColor = fig.colorGrad(2,:);
    fig.sHiLite(3).BackgroundColor = fig.colorGrad(3,:);
    fig.sHiLite(4).BackgroundColor = fig.colorGrad(4,:);
    fig.sHiLite(5).BackgroundColor = [0.8500 0.3250 0.0980];
    % fig.sHiLite(6).HorizontalAlignment = 'center';
    % addStyle(fig.uit,fig.sHiLite(6))
    % fig.uit.HorizontalAlignment = 'center';
    
    % Disable some handles
    if autoMode
        fig.radiobutton(1).Enable = 'off';
        fig.radiobutton(2).Enable = 'off';
        for i = 1:3
            fig.button(i).Enable = 'off';
        end
        for i = 1:5
            fig.text(i).Enable = 'off';
        end
        for i = 1:3
            fig.uitextarea(i).Enable = 'off';
        end
    end
end

drawnow
if isfield(fig,'F')
    fig.F.Visible = 'on';
else
    fig.f(1).Visible = 'on';
end

% Save handles if desired
if saving
    if whichFigure==1
        messagePrint = ['\n' replace(['Figure handles saved in "' [saveHere...
            '\ExtSet_GUI_function_Interfacea_screen' num2str(screen) '.fig']]...
            ,'\','\\') '".\n'];
        savePath = [saveHere '\ExtSet_GUI_function_Interfacea_screen' num2str(screen) '.fig'];
    elseif whichFigure==2
        if tab
            messagePrint = ['\n' replace(['Figure handles saved in "' [saveHere ...
                '\autoModeHandles_fig_screen' num2str(screen) '_tab.fig']],'\',...
                '\\') '".\n'];
            savePath = [saveHere '\autoModeHandles_fig_screen' num2str(screen) '_tab.fig'];
        else
            messagePrint = ['\n' replace(['Figure handles saved in "' [saveHere ...
                '\autoModeHandles_fig_screen' num2str(screen) '.fig']],'\',...
                '\\') '".\n'];
            savePath = [saveHere '\autoModeHandles_fig_screen' num2str(screen) '.fig'];
        end
    end
    savefig(fig.F,savePath)
    fprintf(messagePrint)
end

% Evaluate the output argument
if nargout>=1
    figure_handles = fig;
end
end