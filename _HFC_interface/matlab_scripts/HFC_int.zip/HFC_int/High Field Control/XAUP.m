%%

%%
source = 'C:\Users\elsabbagh-n\Documents\DataSet\230113_BBI_flowtube_test_ChemReact - copie\21\pdata\1\intrng';
for i = [22:29 31 32 34:45]
    destination = ['C:\Users\elsabbagh-n\Documents\DataSet\230113_BBI_flowtube_test_ChemReact - copie\' num2str(i) '\pdata\1'];
    copyfile(source,destination)
end

%%
clc
clearvars

FileName = '230113_BBI_flowtube_test_ChemReact_copie';
datasetPath = 'C:\Users\elsabbagh-n\Documents\DataSet';
expList = [21:29 31 32 34:45];
for i = 1:length(expList)
    expNb = expList(i);
    cmd = ['re ' FileName ' ' num2str(expNb) ' 1 ' datasetPath];
    sendCommand2Topspin_thisPC(cmd);
    pause(0.25)
    cmd = 'xaup';
    sendCommand2Topspin_thisPC(cmd);
    pause(0.5)
    [A,~,~,~] = get_area_values_from_thisPC(FileName,datasetPath,expNb);
    Areas(i,1:length(A)) = A;
    % Date and time of the updated status file
    filePath = fullfile(datasetPath,FileName,num2str(expNb),'fid');
    D = dir(filePath);
    t = D.date(end-7:end);
    T(i,1) = datetime(t,'Format','HH:mm:ss'); %#ok<SAGROW>
end
%% Plot
figure,hold on
plot(T,Areas(:,1)./Areas(:,2),'b','Marker','o','DisplayName','Citral 1 / Ref 1')
plot(T,Areas(:,1)./Areas(:,4),'b--','Marker','o','DisplayName','Citral 1 / Ref 2')
plot(T,Areas(:,3)./Areas(:,2),'g','Marker','o','DisplayName','Citral 2 / Ref 1')
plot(T,Areas(:,3)./Areas(:,4),'g--','Marker','o','DisplayName','Citral 2 / Ref 2')
plot(T,Areas(:,5)./Areas(:,2),'r','Marker','o','DisplayName','Cyclo 1 / Ref 1')
plot(T,Areas(:,5)./Areas(:,4),'r--','Marker','o','DisplayName','Cyclo 1 / Ref 2')
plot(T,Areas(:,6)./Areas(:,2),'y','Marker','o','DisplayName','Cyclo 2 / Ref 1')
plot(T,Areas(:,6)./Areas(:,4),'y--','Marker','o','DisplayName','Cyclo 2 / Ref 2')
legend

%%
clc
clearvars

FileName = '221109_1';
datasetPath = 'C:\Users\elsabbagh-n\Documents\DataSet';
expList = 1:35;
for i = 1:length(expList)
    expNb = expList(i);
    ParValues(i,:) = get_AcquOrProc_ParValue_from_thisPC(FileName,datasetPath,expNb,'procs',{'NC_proc','INTSCL'},1);
    [Areas(i,:),~,~,~] = get_area_values_from_thisPC(FileName,datasetPath,expNb);
%     fctr(i,1) = 10^7*ParValues{i,2}*2^-ParValues{i,1};
    fctr(i,1) = 10^7*ParValues{i,2};
    % Date and time of the updated status file
    filePath = fullfile(datasetPath,FileName,num2str(expNb),'fid');
    D = dir(filePath);
    t = D.date(end-7:end);
    T(i,1) = datetime(t,'Format','HH:mm:ss');
end
Results = [Areas,zeros(length(expList),1),Areas(:,1)./Areas(:,2),...
    zeros(length(expList),1),Areas(:,1)./fctr,Areas(:,2)./fctr];
% Plot
figure,hold on
yyaxis left
plot(T,Results(:,6),'Marker','.')
plot(T,Results(:,7),'-.','Marker','.')
yyaxis right
plot(T,Results(:,4),'-.','Marker','.')

%%




















