function [h,hh] = enable_entries(h,hh)
% This function enable entries when the delete checkbox is unchecked.

% Fixed Input Panel
c = {'User';'Solvent';'StartRun';'StopRun'};
for i = 1:length(c)
    [~,d] = ismember(c(i),h.checkList(:,1));
    if d
        check = cell2mat(h.checkList(d,2:end));
        if check(4)==0 %it is a popup menu
            h.popup_menu(h.checkList{d,4},1).Enable='on';
        else%it is a check box then
            h.check_box(h.checkList{d,5},1).Enable='on';
        end
    end
end
[~,d] = ismember('Holder',h.checkList(:,1));
if d
    h.editable_text_field(h.checkList{d,3},1).ForegroundColor = [0 0 0];
end

% Experimental Input Panel
for i = 1:length(h.ExperimentalInput)
    [~,d] = ismember(h.ExperimentalInput(i),h.checkList(:,1));
    if d
        check = cell2mat(h.checkList(d,2:end));
        if check(4)==0
            if check(3)==0 %it is an insert text
                h.editable_text_field(h.checkList{d,3},1).Enable='on';
            else %it is a popup menu
                h.popup_menu(h.checkList{d,4},1).Enable='on';
            end
        else %it is a check box then
            h.check_box(h.checkList{d,5},1).Enable='on';
        end
    end
end
[~,d] = ismember({'starttime'},lower(h.checkList(:,1)));
if d
    if h.check_box(h.checkList{d,5},1).Value
        h.calendar.push_button(1).Enable = 'on';
        h.calendar.push_button(2).Enable = 'on';
        h.calendar.static_text_field(1).Enable = 'on';
    end
end
if hh.v
    hh.calendar.f(1).Visible = 'on';
    hh.calendar.f(2).Visible = 'on';
else
    hh.calendar.f(1).Visible = 'off';
    hh.calendar.f(2).Visible = 'off';
end

% Parameter Input Panel
h.check_box(end).Enable='on';
h.popup_menu(end,1).Enable='on';
h.editable_text_field(end,1).Enable='on';
h.push_button(1).Enable='on';
h.push_button(2).Enable='on';
h.list_box(1).Enable='on';
end