function command_output = get_folder_content_spectro500...
    (foldername,folderpath)
% This function gets files' content on a remonte PC to this PC. Hostname,
% Username and Password are set to the those of Spectro500. It transfers
% file of the selected folder, and files from its subfolders indicated. If
% the transfer is done successfully, it returns a value 1; if there were no
% transfer or the folderName didn't exist, it returns a nil value.
%
% Input
% foldername      File name to be downloaded from the remote PC
% folderpath      Path of the file to be downloaded from the remote PC
% desiredPath     Path to which the file will be download on this PC
% quickCheck      =0 for transferred, =1 for checking the content
%% User Input

% Required information about the remote PC (spectro 500MHz)
Hostname = '172.16.77.57';
Hostname = 'RMN500-1525.ceisam.sciences.univ-nantes.prive';
Username = 'nmr';
Password = 'topspin';


%% Folder Upload
command = ['cd ' folderpath '/' foldername ' ; ls'];
command_output = ssh2_simple_command(Hostname, Username, Password,command);
end






