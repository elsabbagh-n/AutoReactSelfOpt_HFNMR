function [reportTable,varargout] = readReportFile(filename)
% filename = 'C:\Users\elsabbagh-n\Documents\DataSet\Interface Reports\Report of 23-09-2022 (3).txt';
if exist(filename, 'file')~=2
     return
end
reportTable = readtable(filename);
if nargout>=2 % Region
    AA = regexp(fileread(filename),'\n','split')';
    whichline = find(contains(AA,'Date'),1);
    if whichline>6
        % Additional bounds
        nbAdditionalBounds = whichline-7;
    else
        % No additional bounds
        nbAdditionalBounds = 0;
    end
    fileID = fopen(filename,'r');
    formatSpec = '%s';
    A = fscanf(fileID,formatSpec);
    out = textscan(A,'%[^:]:[%fppm,%fppm]');
    for i = 1:length(out{1})-1
        eval(['results.' out{1}{i} ' = [out{2}(i) out{3}(i)];'])
    end
    if nbAdditionalBounds
        out2 = textscan(out{1}{end},'[%fppm,%fppm]'); %#ok<NASGU>
        for i = 1:nbAdditionalBounds-1
            eval(['results.' out{1}{end-1} '(end+1,:) = [out2{1}(i) out2{2}(i)];'])
        end
    end
    varargout{1} = results;
    fclose('all');
end
end