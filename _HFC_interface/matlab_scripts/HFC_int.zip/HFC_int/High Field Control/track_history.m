function histTrack = track_history(newestHist,quickCheck,timeline)
% This function keeps track on the history text file of TopSpin3.6.2.
%
% Input:
%
%   newestHist      =1 to only investigate commands of the latest date =0
%                   =0 to be able to choose which one
%                   In the  second case, a menu will appear for the user to
%                   choose the desired date.
%
%   quickCheck      =1 to not transfer the history file while reading it
%                   directly from TopSpin computer
%                   =0 to transfer the history file to this PC before
%                   reading it 
%                   ='\...\...\history' to read an existing history file
%
%   timeline        =1 to have a timenline output
%                   =0 no output
%
% Output :
%
%   histTrack       a struct containing the following fields
%                   iconNMR_ON          IconNMR window is open(1) or not(0)
%                   automation_ON       Automation window open(1) or not(0)
%                   automation_RUN      Automation running(1) or not(0)
%                   created_exp         List of created experiments
%                   still_running_exp   List of running experiments
%                   completed_exp       List of completed experiments
%                   inqueue_exp         List of in queue experiments

global f l hist_date_ind

%% Transfer the history file or get its content

% nmr history file path on remote PC
hist_path = '/opt/topspin3.6.2/prog/curdir/nmr/';
hist_filename = 'history';
% nmr history file path on this PC
desiredPath = 'C:\Users\elsabbagh-n\Documents\DataSet\history\';

if isa(quickCheck,'double')
    if quickCheck==0
        % file transfer
        get_history_from_spectro500(hist_filename,hist_path,desiredPath,0)
        hist_lines_orig = regexp(fileread([desiredPath hist_filename]),'\n','split')';
    else
        % no file transfer
        hist_lines_orig = get_history_from_spectro500(hist_filename,hist_path,...
            desiredPath,quickCheck);
    end
elseif isa(quickCheck,'char')
    hist_lines_orig = regexp(fileread(quickCheck),'\n','split')';
end

%% Separate lines according to dates

iconNMR_date = find(contains(hist_lines_orig,'+0200    JD'));
if isempty(iconNMR_date)
    pat = '+0' + digitsPattern(1) + '00    JD';
    iconNMR_date = find(contains(hist_lines_orig,pat));
end

if newestHist==0
    % User chooses the desired date
    f = figure;
    uicontrol('style','text','units','normalized',...
        'string','History dates found',...
        'FontName','Arial','FontSize',14,...
        'BackgroundColor',[0.94,0.94,0.94],'Parent',f,...
        'Position',[0.05 0.8 0.9 0.14]);
    l = uicontrol('style','listbox','units','normalized',...
        'Parent',f,'Visible','on','FontSize',11,...
        'Position',[0.05 0.2 0.9 0.6],'String',hist_lines_orig(iconNMR_date),...
        'FontName','Arial');
    uicontrol('style','pushbutton','units','normalized',...
        'BackgroundColor',[0.94,0.94,0.94],'string','Select','FontName','Arial',...
        'Parent',f,'callback',@callback01,'Position',...
        [0.05 0.06 0.9 0.1],'Value',0,'FontSize',20,...
        'ForegroundColor',[0.05,0.65,0.12]);
    uiwait(f)
elseif newestHist==-1
    % All dates
    hist_date_ind = 1:length(iconNMR_date);
else
    % Last date fixed
    hist_date_ind = length(iconNMR_date);
end
%%
for dx = 1:length(hist_date_ind)
    if length(hist_date_ind)~=1
        fprintf('\n-----Date package n° %d-----',dx)
    end
    % Index of lines of a specific date
    iconNMR_date1 = iconNMR_date(hist_date_ind(dx));
    if hist_date_ind(dx)==length(iconNMR_date)
        iconNMR_date2 = length(hist_lines_orig);
    else
        iconNMR_date2 = iconNMR_date(hist_date_ind(dx)+1);
    end
    
    % History text lines from a specific date X
    hist_lines_dateX = hist_lines_orig(iconNMR_date1:iconNMR_date2);
    if timeline==1
        fprintf('\nHistory from %s \n',hist_lines_dateX{1}(1:10))
    end
    %% Find if IconNMR is open
    
    % IconNMR called on the specified date X
    iconNMR_Launched_dateX = find(contains(hist_lines_dateX,'cmd sent: xwish3 iconnmr'));
    if isempty(iconNMR_Launched_dateX)
        fprintf('IconNMR not openned. History check was abandoned.\n')
        histTrack.iconNMR_ON = [];
        histTrack.automation_ON = [];
        histTrack.automation_RUN = [];
        histTrack.created_exp = [];
        histTrack.still_running_exp = [];
        histTrack.completed_exp = [];
        histTrack.inqueue_exp = [];
        if length(hist_date_ind)==1
            return
        else
            continue
        end
    else
        histTrack.iconNMR_ON = cell(length(iconNMR_Launched_dateX),1);
        histTrack.automation_ON = cell(length(iconNMR_Launched_dateX),1);
        histTrack.automation_RUN = cell(length(iconNMR_Launched_dateX),1);
        histTrack.created_exp = cell(length(iconNMR_Launched_dateX),1);
        histTrack.still_running_exp = cell(length(iconNMR_Launched_dateX),1);
        histTrack.completed_exp = cell(length(iconNMR_Launched_dateX),1);
        histTrack.inqueue_exp = cell(length(iconNMR_Launched_dateX),1);
    end
    
    
    %% Separate lines according to IconNMR launch
    
    % for ic = 1:length(iconNMR_Launched_dateX)
    for ic = length(iconNMR_Launched_dateX)
        % History from a specific launch from the specified date
        
        % History lines
        if ic==length(iconNMR_Launched_dateX)
            hist_lines = hist_lines_dateX(iconNMR_Launched_dateX(ic)-2:end);
        else
            hist_lines = hist_lines_dateX(iconNMR_Launched_dateX(ic)-2:iconNMR_Launched_dateX(ic+1)-3);
        end
        
        % IconNMR called
        iconNMR_Launched = find(contains(hist_lines,'cmd sent: xwish3 iconnmr'));
        
        % IconNMR closed
        iconNMR_Closed = find(contains(hist_lines,'cmd term: iconnmr; status=0'));
        
        if ~newestHist
            while(length(iconNMR_Launched)>length(iconNMR_Closed))
                iconNMR_Closed(end+1) = length(hist_lines)+1; %#ok<AGROW>
            end
        end
        
        if ~isempty(iconNMR_Closed)
            histTrack.iconNMR_ON{ic,1} = 0;
        else
            histTrack.iconNMR_ON{ic,1} = 1;
        end
        
        %% Find if Automation Window is open
        
        % Automation opened
        % automation_Opened = find(contains(hist_lines,['cmd enter: sendgui '...
        %      'clientid=local -exch exchange.24510 _get_property globals ZG_SAFETY']));
        automation_Opened = [];
        for i = 1:length(iconNMR_Launched)
            lines_t = hist_lines{iconNMR_Launched(i)};
            comp = textscan(lines_t,'%[^ ]');
            comp = comp{1};
            mark = comp{2};
            out = find(contains(hist_lines,['cmd enter: sendgui '...
                'clientid=local -exch exchange.' mark ' _get_property globals ZG_SAFETY']));
            automation_Opened = [automation_Opened;out]; %#ok<AGROW>
        end
        
        %     if isempty(automation_Opened)
        %         return
        %     end
        % if ~length(automation_Opened)>1
        %     hist_lines = hist_lines(1:automation_Opened(2)-1);
        %     automation_Opened = find(contains(hist_lines,['cmd enter: sendgui '...
        %         'clientid=local -exch exchange.24510 _get_property globals ZG_SAFETY']));
        % end
        
        % Automation closed
        if ~isempty(iconNMR_Closed)
            if ~isempty(automation_Opened)
                %         automation_Closed = iconNMR_Closed(iconNMR_Closed>automation_Opened(end));
                automation_Closed = iconNMR_Closed;
                iconNMR_Closed = iconNMR_Closed+1;
            else
                automation_Closed = [];
            end
        else
            automation_Closed = [];
        end
        
        if isempty(automation_Opened)
            histTrack.automation_ON{ic,1} = 0;
        else
            if ~isempty(automation_Closed)
                histTrack.automation_ON{ic,1} = 0;
            else
                histTrack.automation_ON{ic,1} = 1;
            end
        end
        
        %% Find if Experiments is/are created
        
        % Experiment created
        t = 'new object "/opt/topspin3.6.2/prog/curdir/changer/inmrchanger/';
        experiment_Created = find(contains(hist_lines,t));
        %     if isempty(experiment_Created)
        %         return
        %     end
        experiment_Log = cell(size(experiment_Created,1)+1,4);
        experiment_Log (1,:) = {'Index','Status file','Folde name','ExpNo'};
        for i = 1:size(experiment_Created,1)
            lines_t = hist_lines{experiment_Created(i)};
            comp = textscan(lines_t,'%[^ ]');
            comp = comp{1};
            experiment_Log{i+1,1} = str2double(comp{3});
            path_t = regexp(comp{6}(3:end-1),'/','split');
            [~,a] = ismember({'inmrchanger','data'},path_t);
            experiment_Log{i+1,2} = [char(datetime(path_t{a(1)+1}(1:15),'Format',...
                'MMMdd-yyyy-HHmm')),path_t{a(1)+1}(16:end),'.set'];
            experiment_Log{i+1,3} = path_t{a(2)+2};
            experiment_Log{i+1,4} = str2double(path_t{a(2)+3});
        end
        
        %% Find if Automation is running
        
        % Automation started
        automation_Started = find(contains(hist_lines,['cmd sent: sendgui '...
            'clientid=local _enable_cmd exit-']));
        %     if isempty(automation_Started)
        %         return
        %     end
        % automation_Started = automation_Started(end);
        
        % Automation stopped
        automation_Stopped = find(contains(hist_lines,['cmd sent: sendgui '...
            'clientid=local _enable_cmd exit+']));
        % if ~isempty(automation_Stopped)
        %     automation_Stopped = automation_Stopped(automation_Stopped>automation_Started);
        % end
        
        if isempty(automation_Started)
            histTrack.automation_RUN{ic,1} = 0;
        else
            if ~isempty(automation_Stopped)
                if (automation_Stopped(end)>automation_Started(end))
                    histTrack.automation_RUN{ic,1} = 0;
                else
                    histTrack.automation_RUN{ic,1} = 1;
                end
            else
                histTrack.automation_RUN{ic,1} = 1;
            end
        end
        
        %% Find if Acquisition is launched
        
        % Acquisition launched
        t = 'new object "/opt/nmrdata/user/nmr/';
        acquisition_Launched = find(contains(hist_lines,t));
        %     if isempty(acquisition_Launched)
        %         return
        %     end
        
        acquisition_Log = cell(size(acquisition_Launched,1)+1,4);
        acquisition_Log (1,:) = {'Index','User','Folde name','ExpNo'};
        for i = 1:size(acquisition_Launched,1)
            lines_t = hist_lines{acquisition_Launched(i)};
            comp = textscan(lines_t,'%[^ ]');
            comp = comp{1};
            acquisition_Log{i+1,1} = str2double(comp{3});
            path_t = regexp(comp{6}(3:end-1),'/','split');
            [~,a] = ismember({'nmr'},path_t);
            acquisition_Log{i+1,2} = path_t{a+1};
            acquisition_Log{i+1,3} = path_t{a+2};
            acquisition_Log{i+1,4} = str2double(path_t{a+3});
        end
        
        if length(experiment_Created)<length(acquisition_Launched)
            % exp submitted on the go
            for i = length(experiment_Created)+1:length(acquisition_Launched)
                %         experiment_Created(i,1) = acquisition_Launched(i,1)-1;
                experiment_Created(i,1) = 0;
                experiment_Log = [experiment_Log;experiment_Log(end,:)]; %#ok<AGROW>
                experiment_Log{end,end} = acquisition_Log{i+1,end};
            end
        end
        
        % Processing started
        t = 'cmd enter: xwish3 tclsh inmr_scripts/restart_xw DoProcessing';
        processing_Started = find(contains(hist_lines,t));
        %     if isempty(processing_Started)
        %         return
        %     end
        processing_S_Log = cell(size(processing_Started,1)+1,1);
        processing_S_Log (1,:) = {'Index'};
        for i = 1:size(processing_Started,1)
            lines_t = hist_lines{processing_Started(i)};
            comp = textscan(lines_t,'%[^ ]');
            comp = comp{1};
            processing_S_Log{i+1,1} = str2double(comp{3});
        end
        
        % Processing ended
        t = 'cmd(o) sent: autoplot';
        processing_Ended = find(contains(hist_lines,t));
        %     if isempty(processing_Ended)
        %         return
        %     end
        t = 'proc term';
        processing_Ended2 = find(contains(hist_lines,t));
        %     if isempty(processing_Ended2)
        %         return
        %     end
        for i = 1:size(processing_Ended,1)
            ind = processing_Ended2(processing_Ended2>processing_Ended(i));
            if length(ind)>=5
                processing_Ended(i,2) = ind(5);
            else
                processing_Ended(i,2) = 0;
            end
        end
        processing_E_Log = cell(size(processing_Ended,1)+1,1);
        processing_E_Log (1,:) = {'Index'};
        for i = 1:size(processing_Ended,1)
            lines_t = hist_lines{processing_Ended(i,1)};
            comp = textscan(lines_t,'%[^ ]');
            comp = comp{1};
            processing_E_Log{i+1,1} = str2double(comp{3});
        end
        
        %% Dialog print
        
        % if iconNMR_ON
        %     fprintf('\nIconNMR is still opened.\n')
        % else
        %     fprintf('\nIconNMR is closed.\n')
        % end
        % if automation_ON
        %     fprintf('\nAutomation window is still opened.\n')
        % else
        %     fprintf('\nAutomation window is closed.\n')
        % end
        % if automation_RUN
        %     fprintf('\nAutomation is running.\n')
        % else
        %     fprintf('\nAutomation is stopped.\n')
        % end
        
        %% Gather in periodic scheme
        
        nb = length(experiment_Created);
        LOG = cell(nb+1,6);
        LOG (1,:) = {'Index','ExpNo','Creation','Acquisition','Processing','Ending'};
        for i = 1:nb
            LOG{i+1,2} = experiment_Log{i+1,4}; % ExpNo
            if experiment_Created(i)~=0
                LOG{i+1,3} = experiment_Created(i); % Creation
            else
                LOG{i+1,3} = []; % Creation
            end
            if exist('acquisition_Log','var')
                if (i<=(size(acquisition_Log,1)-1))
                    [~,a] = ismember(LOG{i+1,2},cell2mat(acquisition_Log(2:end,4)));
                    if a
                        LOG{i+1,1} = acquisition_Log{a+1,1}; % Index
                        LOG{i+1,4} = acquisition_Launched(a); % Acquisition
                    end
                end
            end
            if exist('processing_S_Log','var')
                if (i<=(size(processing_S_Log,1)-1))
                    [~,a] = ismember(LOG{i+1,1},cell2mat(processing_S_Log(2:end)));
                    if a
                        LOG{i+1,5} = processing_Started(a);% Processing
                    end
                end
            end
            if exist('processing_E_Log','var')
                if (i<=(size(processing_E_Log,1)-1))
                    [~,a] = ismember(LOG{i+1,1},cell2mat(processing_E_Log(2:end)));
                    if a
                        LOG{i+1,6} = processing_Ended(a,2);% Ending
                    end
                end
            end
        end
        
        if timeline
            cre = cell(nb,3);
            acq = cell(nb,3);
            pro1 = cell(nb,3);
            pro2 = cell(nb,3);
            for i = 1:nb
                %         cre(i,1:3) = {3+2*LOG{i+1,2} ['**[ experiment_Created ' num2str(LOG{i+1,2})] LOG{i+1,3}};
                cre(i,1:3) = {3+i ['**[ experiment_Created ' num2str(LOG{i+1,2})] LOG{i+1,3}};
                %     if isempty(LOG{i+1,4})
                %         acq(i,1:3) = {4 ['acquisition_Launched exp n° ' num2str(LOG{i+1,2}) ' not launched'] 9999};
                %     else
                %         acq(i,1:3) = {4 ['acquisition_Launched exp n° ' num2str(LOG{i+1,2})] LOG{i+1,4}};
                %     end
                %         acq(i,1:3) = {3+2*LOG{i+1,2} ['acquisition_Launched exp ' num2str(LOG{i+1,2})] LOG{i+1,4}};
                if isempty(LOG{i+1,3})
                    acq(i,1:3) = {3+i ['**[ acquisition_Launched exp ' num2str(LOG{i+1,2})] LOG{i+1,4}};
                else
                    acq(i,1:3) = {3+i ['acquisition_Launched exp ' num2str(LOG{i+1,2})] LOG{i+1,4}};
                end
                
                %     if isempty(LOG{i+1,5})
                %         pro1(i,1:3) = {4 ['processing_Started exp n° ' num2str(LOG{i+1,2}) ' not started'] 9999};
                %     else
                %         pro1(i,1:3) = {4 ['processing_Started exp n° ' num2str(LOG{i+1,2})] LOG{i+1,5}};
                %     end
                %         pro1(i,1:3) = {3+2*LOG{i+1,2} ['processing_Started exp ' num2str(LOG{i+1,2})] LOG{i+1,5}};
                pro1(i,1:3) = {3+i ['processing_Started exp ' num2str(LOG{i+1,2})] LOG{i+1,5}};
                %     if isempty(LOG{i+1,6})
                %         pro2(i,1:3) = {4 ['processing_Ended exp n° ' num2str(LOG{i+1,2}) ' not finished'] 9999};
                %     else
                %         pro2(i,1:3) = {4 ['processing_Ended exp n° ' num2str(LOG{i+1,2})] LOG{i+1,6}};
                %     end
                %         pro2(i,1:3) = {3+2*LOG{i+1,2} ['processing_Ended exp ' num2str(LOG{i+1,2}) ' ]**'] LOG{i+1,6}};
                pro2(i,1:3) = {3+i ['processing_Ended exp ' num2str(LOG{i+1,2}) ' ]**'] LOG{i+1,6}};
            end
            
            if exist('iconNMR_Launched','var')
                ind = {1 'iconNMR_Launched' iconNMR_Launched(1)};
                for i = 2:length(iconNMR_Launched)
                    ind = [ind;{1 'iconNMR_Launched' iconNMR_Launched(i)}]; %#ok<AGROW>
                end
            end
            if exist('iconNMR_Closed','var')
                for i = 1:length(iconNMR_Closed)
                    ind = [ind;{1 'iconNMR_Closed' iconNMR_Closed(i)}]; %#ok<AGROW>
                end
            end
            if exist('automation_Opened','var')
                for i = 1:length(automation_Opened)
                    ind = [ind;{2 'automation_Opened' automation_Opened(i)}]; %#ok<AGROW>
                end
            end
            if exist('automation_Closed','var')
                for i = 1:length(automation_Closed)
                    ind = [ind;{2 'automation_Closed' automation_Closed(i)}]; %#ok<AGROW>
                end
            end
            if exist('automation_Started','var')
                for i = 1:length(automation_Started)
                    ind = [ind;{3 'automation_Started' automation_Started(i)}]; %#ok<AGROW>
                end
            end
            if exist('automation_Stopped','var')
                for i = 1:length(automation_Stopped)
                    ind = [ind;{3 'automation_Stopped' automation_Stopped(i)}]; %#ok<AGROW>
                end
            end
            ind = [ind;cre;acq;pro1;pro2]; %#ok<AGROW>
            
            emptyCells = cellfun(@isempty,ind(:,end));
            ind = ind(~emptyCells,:);
            [~,ord] = sort(cell2mat(ind(:,end)),'ascend');
            text_hist = '';
            for i = 1:length(ord)
                if ind{ord(i),3}<=length(hist_lines)
                    text_hist = [text_hist  hist_lines{ind{ord(i),3}}(1:8)]; %#ok<AGROW>
                else
                    text_hist = [text_hist  '00:00:00']; %#ok<AGROW>
                end
                n = 1;
                while(n<=ind{ord(i),1})
                    text_hist = [text_hist '\t' ]; %#ok<AGROW>
                    n = n+1;
                end
                %         text_hist = [text_hist num2str(i) ' ' ind{ord(i),2} '\n']; %#ok<AGROW>
                text_hist = [text_hist ' ' ind{ord(i),2} '\n']; %#ok<AGROW>
            end
            fprintf('\nTimeLine : \n\n')
            fprintf(text_hist)
        end
        %% Output
        
        histTrack.created_exp{ic,1} = cell2mat(LOG(2:end,2));
        emptyCells = cellfun(@isempty,LOG(2:end,6));
        histTrack.completed_exp{ic,1} = histTrack.created_exp{ic,1}(~emptyCells);
        emptyCells = cellfun(@isempty,LOG(2:end,4));
        started_exp = histTrack.created_exp{ic,1}(~emptyCells);
        histTrack.still_running_exp{ic,1} = started_exp(~ismember(started_exp,histTrack.completed_exp{ic,1}));
        histTrack.inqueue_exp{ic,1} = histTrack.created_exp{ic,1}(~ismember(histTrack.created_exp{ic,1},started_exp));
        
        clearvars hist_lines iconNMR_Launched iconNMR_Closed automation_Opened...
            automation_Closed experiment_Created experiment_Log automation_Started...
            automation_Stopped acquisition_Launched acquisition_Log processing_Started...
            processing_S_Log processing_Ended processing_Ended2 processing_E_Log LOG...
            cre acq pro1 pro2 ind text_hist
    end
    drawnow
end
end
function callback01(varargin)
global f l hist_date_ind hist_date
hist_date_ind = l.Value;
hist_date = l.String(l.Value);
close(f)
end