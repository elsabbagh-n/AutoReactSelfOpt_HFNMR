function h = tag_update(h)
% This function updates the inserted information in the table called
% Auto_Experiment_Table. This latter is used to update the tag of the
% currently inserted experiment in the Edit Input Panel.

for i = 2:size(h.Auto_Experiment_Table,2)-1
    if ismember(lower(h.Auto_Experiment_Table.Properties.VariableNames(i)),...
            {'parameters'})
        if size(h.list_box(1).String,1)==1
            param = split(h.list_box(1).String,' = ');
            ind = find(param{1,1}=='[',1);
            if ~isempty(ind)
                param{1,1} = param{1,1}(1:ind-2);
            end
        else
            param = split(h.list_box(1).String,' = ');
            for j = 1:size(param,1)
                ind = find(param{j,1}=='[',1);
                if ~isempty(ind)
                    param{j,1} = param{j,1}(1:ind-2);
                end
            end
        end
        h.Auto_Experiment_Table.Parameters(1) = join(join...
            (string(param),','),',',1);
        continue
    end
    [~,d] = ismember(lower(...
        h.Auto_Experiment_Table.Properties.VariableNames(i)),...
        lower(h.checkList(:,1)));
    if d
        check = cell2mat(h.checkList(d,2:end));
        if check(4)==0
            if check(3)==0 %it is an insert text
                eval(['h.Auto_Experiment_Table.' h.checkList{d,1}...
                    '(1) = string(h.editable_text_field('...
                    num2str(check(2)) ').String);'])
            else %it is a popup menu
                popup_menu_list = h.popup_menu(check(3),1).String; %#ok<NASGU>
                eval(['h.Auto_Experiment_Table.' h.checkList{d,1}...
                    '(1) = string(popup_menu_list(h.popup_menu('...
                    num2str(check(3)) ').Value));'])
            end
        else %it is a check box then
            eval(['h.Auto_Experiment_Table.' h.checkList{d,1}...
                '(1) = h.check_box('...
                num2str(check(4)) ').Value;'])
        end
    end
end
% Current Experiment Tag
if h.Auto_Experiment_Table.Delete(1)
    tag = ['#\Delete holder°',num2str(h.Auto_Experiment_Table.Holder(1))];
else
    % 'Index\ExpNo\Solvent\Experiment\Parameters'
    tag = char(fullfile('#',...
        ['Exp°',num2str(h.Auto_Experiment_Table.ExpNo(1))],...
        h.Auto_Experiment_Table.Solvent(1),...
        h.Auto_Experiment_Table.Experiment(1),...
        h.Auto_Experiment_Table.Parameters(1)));
end
h.static_text_field(end,1).String = tag;
end
