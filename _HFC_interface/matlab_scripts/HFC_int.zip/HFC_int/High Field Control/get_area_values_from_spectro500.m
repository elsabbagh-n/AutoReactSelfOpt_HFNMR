function [Areas,AreaRegions,expAreaFound,allFound] = get_area_values_from_spectro500(FileName,datasetPath,...
    expList,varargin)
% This function looks for calculated intergals by TopSpin for a desired
% list of experiments. Hostname, Username and Password are set to the those
% of Spectro500. 
%
% No file transfer !
%
% Input
% FileName                Name of the folder to be checked
% datasetPath             Path of folder to be checked on the remote PC
% expList                 List of experiments to be checked
% waitCheck               =1 to wait until updated, =0 check once
% Output
% Areas                   Area values got from TopSpin
% AreaRegions             Area Regions used by TopSpin
% allFound                =1 if integral is calculated for all experiments

% FileName = '221202_BBI_flowtube_test';datasetPath = '/opt/nmrdata/user/nmr/Nour';expList = 5;varargin = [];%{1};
%FileName = '240226';datasetPath = '/opt/nmrdata/user/nmr/Nour';expList = 1;varargin = {1,h};
% File path of the SCP functions
addpath(genpath('C:\Users\elsabbagh-n\Documents\MATLAB\Freedman_ssh'))

if isempty(varargin)
    askForNewProcessing = 0;
else
    if isstruct(varargin{1})
        % In Automatic Mode
        askForNewProcessing = 2;
        h = varargin{1};
    else
        % In Manual Mode
        askForNewProcessing = 1;
        if length(varargin)>1
            h = varargin{2};
        end
    end
end
dimension = 1;
%% User Input

% Required information about the remote PC (spectro 500MHz)
Hostname = 'RMN500-1525.ceisam.sciences.univ-nantes.prive';%or '172.16.225.54' %old '172.16.77.57';
Username = 'nmr';
Password = 'topspin';

%% Make sure that the corresponding folder are valid
if isempty(expList)
    return
end
% Check if the main dataset folder is created
command = ['cd ' datasetPath '/' FileName ' ; ls ;'];
command_output = ssh2_simple_command(Hostname, Username, Password,command);
expInFolder = zeros(length(command_output),1);
for i = 1:length(command_output)
    expInFolder(i,1) = str2double(string(cell2mat(command_output(i))));
end
expInFolder = sort(expInFolder,'ascend');
expFound = expList(ismember(expList,expInFolder));

%% Integral values file check
int_filename1 = 'integrals.txt';
int_filename2 = 'int1d';
int_filename3 = 'int2d';
format_int = '%*f      %f      %f      %f';
Areas        = zeros(length(expFound),2);% Target then Reference
AreaRegions  = zeros(length(expFound),4);% Target then Reference
expAreaFound = zeros(length(expFound),1);
for i = 1:length(expFound)
    % Check if the intergal file is in the dataset folder
    command = ['cd ' datasetPath '/' FileName '/' num2str(expFound(i)) '/pdata/1 ; ls ;'];
    command_output = ssh2_simple_command(Hostname, Username, Password,command);
    if ismember(int_filename1,command_output) && ~ismember(int_filename3,command_output)
        % 1D
        dimension = 1;
        % Intergral text file created
        command = ['cd ' datasetPath '/' FileName '/' num2str(expFound(i)) '/pdata/1 ; cat ' int_filename1 ';'];
        command_output = ssh2_simple_command(Hostname, Username, Password,command);
        FromWhichlines = find(contains(command_output,'Number'));
        ToWhichlines = length(command_output);
        ind = FromWhichlines+1:ToWhichlines;
        for j = 1:length(ind)
            out = textscan(command_output{ind(j)},format_int);
            Areas(i,j) = out{3};
            AreaRegions(i,2*j-1:2*j) = [out{2} out{1}];
        end
%         % Integral n°1
%         out = textscan(command_output{whichlines+1},format_int);
%         Areas(i,1) = out{3};
%         AreaRegions(i,1:2) = [out{2} out{1}];
%         % Integral n°2
%         out = textscan(command_output{whichlines+2},format_int);
%         Areas(i,2) = out{3};
%         AreaRegions(i,3:4) = [out{2} out{1}];
        expAreaFound(i,1) = expFound(i);
    elseif ismember(int_filename2,command_output)
        % 1D
        dimension = 1;
        % Intergral text file created
        command = ['cd ' datasetPath '/' FileName '/' num2str(expFound(i)) '/pdata/1 ; cat ' int_filename2 ';'];
        command_output = ssh2_simple_command(Hostname, Username, Password,command);
        FromWhichlines = find(contains(command_output,'Number'));
        ToWhichlines = length(command_output);
        ind = FromWhichlines+1:ToWhichlines;
        for j = 1:length(ind)
            out = textscan(command_output{ind(j)},format_int);
            Areas(i,j) = out{3};
            AreaRegions(i,2*j-1:2*j) = [out{2} out{1}];
        end
%         % Integral n°1
%         out = textscan(command_output{FromWhichlines+1},format_int);
%         Areas(i,1) = out{3};
%         AreaRegions(i,1:2) = [out{2} out{1}];
%         % Integral n°2
%         out = textscan(command_output{FromWhichlines+2},format_int);
%         Areas(i,2) = out{3};
%         AreaRegions(i,3:4) = [out{2} out{1}];
        expAreaFound(i,1) = expFound(i);
    elseif ismember(int_filename3,command_output)
        % 2D
        dimension = 2;
        % Intergral text file created
        AreaRegions = cell(length(expFound),2);
        command = ['cd ' datasetPath '/' FileName '/' num2str(expFound(i)) '/pdata/1 ; cat ' int_filename3 ';'];
        command_output = ssh2_simple_command(Hostname, Username, Password,command);
        FromWhichlines = find(contains(command_output,'SI_F2'));
        ToWhichlines = length(command_output);
        ind = FromWhichlines+2:ToWhichlines;
        format_int2D_1 = '%*f %*f %*f %*f %f %f %f %f';
        format_int2D_2 = ' %*f %*f %*f %f %f';
        for j = 1:length(ind)/2
            out = textscan(command_output{ind(2*j-1)},format_int2D_1);
            out2 = textscan(command_output{ind(2*j)},format_int2D_2);
            Areas(i,j) = out{3};
            AreaRegions(i,j) = {[out{2} out{1};out2{2} out2{1}]};
        end
        expAreaFound(i,1) = expFound(i);
    end
    if expAreaFound(i,1)
        % Retrieve the absolute values of the areas
        ParValues = get_AcquOrProc_ParValue_from_spectro500(FileName,datasetPath,expFound(i),'procs',{'NC_proc','INTSCL'});
        if dimension==1
            fctr = 10^4*ParValues{2}*2^-ParValues{1};%10^4 to reduce the error due to the missing digits from the written area values
        else
            fctr = ParValues{2}*2^-ParValues{1};%
        end
        Areas(i,:) = Areas(i,:)/fctr; % absolute values
        fprintf(['\nArea value/s of experiment n° ' num2str(expFound(i)) '/' num2str(expFound(end)) ' has/ve been retrieved.\n'])
    else
        fprintf(['\nUnfortunately, area value/s of experiment n° ' num2str(expFound(i)) '/' num2str(expFound(end)) ' has/ve not been retrieved...\n'])
    end
end

% Check if all experiments asked for are found
if size(expAreaFound,1)==length(expList)
    if isempty(find(expAreaFound==0,1))
        allFound = 1;
    else
        allFound = 0;
    end
else
    allFound = 0;
end

%% If some area calculation was not done correctly by topspin
if askForNewProcessing==1
    if allFound==0
        for i = 1:length(expFound)
            if expAreaFound(i)==0
                % Transfer the intrng file to the dataset folder again to
                % make sure
                if dimension==1
                    % 1D
                    PathAndFile2copy = '/home/nmr/Documents/Nour/intrng';
                else
                    % 2D
                    PathAndFile2copy = '/home/nmr/Documents/Nour/int2drng';
                end
                cp_spectro500(PathAndFile2copy,FileName,...
                    datasetPath,expFound(i))
                % Ask for new processing
                fprintf(['\nAreas were not calculated during automatic processing of exp n°'...
                    num2str(expFound(i)) '.\nAsking for it again...\n'])
                % Read dataset
                command_re = ['re ' datasetPath '/' FileName '/' num2str(expFound(i)) '/pdata/1;'];
                command = ['cd /opt/topspin3.6.2/prog/bin ; sendgui ' command_re];
                command_output1 = ssh2_simple_command(Hostname, Username, Password,command);
                display(command_output1)
                % New processing
                if dimension==1
                    % 1D
                    command_proc = 'xaup ';
                    command = ['cd /opt/topspin3.6.2/prog/bin ; sendgui ' command_proc];
                    command_output2 = ssh2_simple_command(Hostname, Username, Password,command);
                    display(command_output2)
                    fprintf('        Done.\n')
                else
                    % 2D
                    command_proc = 'xpyp ';
                    command = ['cd /opt/topspin3.6.2/prog/bin ; sendgui ' command_proc];
                    command_output2 = ssh2_simple_command(Hostname, Username, Password,command);
                    display(command_output2)
                    pause(1)
                    command_proc = '.int ';
                    command = ['cd /opt/topspin3.6.2/prog/bin ; sendgui ' command_proc];
                    command_output2 = ssh2_simple_command(Hostname, Username, Password,command);
                    display(command_output2)
                    pause(1)
                    command_proc = '.sret ';
                    command = ['cd /opt/topspin3.6.2/prog/bin ; sendgui ' command_proc];
                    command_output2 = ssh2_simple_command(Hostname, Username, Password,command);
                    display(command_output2)
                    fprintf('        Done.\n')
                end
                % Get Area
%                 [Areas(i,:),AreaRegions(i,:),expAreaFound(i),allFound0] = get_area_values_from_spectro500(FileName,datasetPath,...
%                     expFound(i));
                [areas,arearegions,expareafound,allFound0] = get_area_values_from_spectro500(FileName,datasetPath,...
                    expFound(i));
                Areas(i,1:length(areas)) = areas;
                AreaRegions(i,1:2*length(areas)) = arearegions;
                expAreaFound(i) = expareafound;
                if allFound0
                    fprintf(['\nArea values were gathered from the new processing of exp n°'...
                        num2str(expFound(i)) '.\n'])
                else
                    fprintf(['\nWarning ! No area found, even after the new processing of exp n°'...
                        num2str(expFound(i)) ' ! \n'])
                end
            end
        end
    end
elseif askForNewProcessing==2
    for i = 1:length(expFound)
        % Generating the new intrng text file
        h = intrng_generate(h);
        % Transfer intrng file to the remote computer
        transfer_to_spectro500(...
            'C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\Post_Doc_codes',...
            'intrng0','/home/nmr/Documents/Nour','intrng')
        % Transfer the intrng file to the dataset folder again with the new
        % range
        PathAndFile2copy = '/home/nmr/Documents/Nour/intrng';
        cp_spectro500(PathAndFile2copy,FileName,...
            datasetPath,expFound(i))
        % Ask for new processing
        fprintf(['\nProcessing exp n°' num2str(expFound(i)) ' again...\n'])
        % Read dataset
        command_re = ['re ' datasetPath '/' FileName '/' num2str(expFound(i)) '/pdata/1;'];
        command = ['cd /opt/topspin3.6.2/prog/bin ; sendgui ' command_re];
        command_output1 = ssh2_simple_command(Hostname, Username, Password,command);
        display(command_output1)
        % New processing
        command_proc = 'xaup ';
        command = ['cd /opt/topspin3.6.2/prog/bin ; sendgui ' command_proc];
        command_output2 = ssh2_simple_command(Hostname, Username, Password,command);
        display(command_output2)
        fprintf('        Done.\n')
        % Get Area
        % [Areas(i,:),AreaRegions(i,:),expAreaFound(i),allFound0] = get_area_values_from_spectro500(FileName,datasetPath,...
        %     expFound(i));
        [areas,arearegions,expareafound,allFound0] = get_area_values_from_spectro500(FileName,datasetPath,...
            expFound(i));
        Areas(i,1:length(areas)) = areas;
        AreaRegions(i,1:2*length(areas)) = arearegions;
        expAreaFound(i) = expareafound;
        if allFound0
            fprintf(['\nArea values were gathered from the new processing of exp n°'...
                num2str(expFound(i)) '.\n'])
        else
            fprintf(['\nWarning ! No area found, even after the new processing of exp n°'...
                num2str(expFound(i)) ' ! \n'])
        end
    end
end
end


