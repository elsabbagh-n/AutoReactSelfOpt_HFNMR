function DateTime = get_date_time_file_spectro500(FilePath,Fid)
% This function gets the date and time of the file specified in filePath.
% DateTime=0 if no file found. Hostname, Username and Password are set to
% the those of Spectro500.
%
% No file transfer !
%
% Input
% Fid                  Name of the file to be checked
% FilePath             Path of file to be checked on the remote PC
% Output
% DateTime             Date and time of modification of the Fid file

%% User Input

% Required information about the remote PC (spectro 500MHz)
Hostname = '172.16.77.57';
Hostname = 'RMN500-1525.ceisam.sciences.univ-nantes.prive';
Username = 'nmr';
Password = 'topspin';

%% Dataset folder creation check

% Check if the main dataset folder is created
command = ['cd ' FilePath '; stat ' Fid ';'];
command_output = ssh2_simple_command(Hostname, Username, Password,command);
if ~isempty(command_output{1})
    whichline = find(contains(command_output,'Modify'),1);
    DateTime = textscan(command_output{whichline},'Modify: %{yyyy-mm-dd}D %{hh:mm:ss.SSS}T');
    DateTime = datetime([char(DateTime{1}) ' ' char(DateTime{2})],'Format','hh:mm:ss.SSS');
    DateTime.Format = 'yyyy-MM-dd hh:mm:ss.SSS';
else
    DateTime = 0;
end
end

