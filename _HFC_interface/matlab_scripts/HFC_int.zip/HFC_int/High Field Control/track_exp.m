function expTrack = track_exp(h)
% This function keeps track on the created experiments on IconNMR of
% TopSpin3.6.2 when the history track fails.
%
% Input:
%       h           struct      handles containing information about the
%                               desired experiments.
% Output:
%       expTrack    logical     =1 if the experiment is created, =0 if not.
%                               Its dimension is according to the desired
%                               experiments number in the inputted handles.

desiredPath = 'C:\Users\elsabbagh-n\Documents\DataSet\status\';
if ismember({'fileName'},fieldnames(h))
    status_fileName = h.fileName;
%     fprintf('\n1\n')
    if h.test==1
%         fprintf('\n2\n')
    else
        statusPath = '/opt/topspin3.6.2/prog/curdir/changer';
        status_fileName = get_status_from_spectro500(statusPath,status_fileName,desiredPath,1);
%         fprintf('\n3\n')
    end
else
    if h.test==1
        status_fileName = 'May23-2022-1436-Nour.set';
%         fprintf('\n2\n')
    else
        status_fileName = char(datetime('now','Format','MMMdd-yyyy'));
        statusPath = '/opt/topspin3.6.2/prog/curdir/changer';
        status_fileName = get_status_from_spectro500(statusPath,status_fileName,desiredPath,1);
%         fprintf('\n3\n')
    end
end

% Path of the updated IconNMR status file
filePath = [desiredPath status_fileName];
if exist(filePath, 'file')==2
    % Read the status file
    text = regexp(fileread(filePath),'\n','split')';
    whichline = find(contains(text,'##Holder##'));
    
    % The number of the submitted experiments
    nb1 = length(whichline);
    
    % Gather information about the submitted experiments writtin in the
    % following order :
    % Holder Status Date ExpNo Solvent Experiment DataDirectory AcquTime
    % where only : Holder & ExpNo are required
    expPool = cell(nb1,2);
    text_format = '##Holder## %d%*s%*s%d';
    for i = 1:nb1
        expPool(i,1:2) = textscan(text{whichline(i)},text_format);
    end
    expPool = double(cell2mat(expPool));
    
    % The wanted experiment & holder number : [Holder ExpNo]
    wanted = [h.Experiment_Table.Holder(2:end),h.Experiment_Table.ExpNo(2:end)];
    
    % Check if the list of wanted experiment(s) exists in the pool
    nb2 = size(h.Experiment_Table,1)-1;
    expTrack = zeros(nb2,1);
    for i = 1:nb2
        [~,a] = ismember(expPool(:,1),wanted(i,1));
        if sum(find(a))~=0
            [~,b] = ismember(expPool(find(a),2),wanted(i,2)); %#ok<FNDSB>
            if find(b)
                expTrack(i) = 1;
            else
                expTrack(i) = 0;
            end
        end
    end
end
end





