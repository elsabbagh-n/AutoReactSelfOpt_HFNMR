function h = int2drng_generate(h)
% This function generates the intrng text file to be transfered once the
% dataset folder is created.
% h.area2D.AreaRegion = [2 3;5 6];h.area2D.AreaRegion2 = [8 9;8 9];h.area2DAdditionalList_Num = [4 5;8 9];
if isfield(h,'area2DAdditionalList_Num')
    RegionsList = h.area2DAdditionalList_Num;
else
    RegionsList = [];
end
RegionsList = [RegionsList;h.area2D.AreaRegion;h.area2D.AreaRegion2];
% [~,ind] = sort(RegionsList(1:2:end,2),'descend');
% RegionsList = RegionsList(ind,:);
h.ind_target2D = find(h.area2D.AreaRegion(1,:)==RegionsList(1:2:end,:),1);
h.ind_reference2D = find(h.area2D.AreaRegion2(1,:)==RegionsList(1:2:end,:),1);
% h.int2Drng = '0 0 #regions in PPM';
h.int2Drng = '0 0 ';
for i = 1:size(RegionsList,1)/2
    h.int2Drng = [h.int2Drng,'\n','a 0 0 0 ',num2str(RegionsList(2*i-1,2)),' ',...
        num2str(RegionsList(2*i-1,1)),...
        '\n','  0 0 0 ',num2str(RegionsList(2*i,2)),' ',num2str(RegionsList(2*i,1))];
%     h.int2Drng = [h.int2Drng,'\n','a 0 0 0 ',num2str(RegionsList(2*i-1,2)),' ',...
%         num2str(RegionsList(2*i-1,1)),' #2nd dimension F1 for region ',num2str(i),...
%         '\n','  0 0 0 ',num2str(RegionsList(2*i,2)),' ',num2str(RegionsList(2*i,1)),...
%         ' #1st dimension F2 for region ',num2str(i)];
end
h.int2Drng = [h.int2Drng,'\n'];
fId = fopen('C:\Users\Ceisam_Mimm\Documents\MATLAB\CurrentHFNMROptFolder\High Field Control\int2drng0','w');
fprintf(fId, h.int2Drng);
fclose(fId);
fId = fopen('C:\Users\Ceisam_Mimm\Documents\MATLAB\CurrentHFNMROptFolder\High Field Control\int2drng','w');
fprintf(fId, h.int2Drng);
fclose(fId);

end
