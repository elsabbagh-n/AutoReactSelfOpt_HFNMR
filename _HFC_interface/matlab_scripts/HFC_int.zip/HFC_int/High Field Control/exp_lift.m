function h = exp_lift(h,several)
% This function decreases the rank (index) of the experiment of the
% selected line in the list box of the Edit Input Panel. If it reaches the
% top list (index = 1), it becomes the priority experiment.
% several : 0 if one lift is wanted, 1 if several ones are applied
% automatically (priority checked).

if ~isempty(h.list_box(2).String)
    ind = split(h.list_box(2).String{h.list_box(2).Value},filesep);
    ind = str2double(ind{1});
    n_table = find(h.Experiment_Table.Index==ind);
    if ind~=1
        % change others
        h.Experiment_Table.Index(find(h.Experiment_Table.Index==ind-1)) = ind;
        % new indexing
        h.Experiment_Table.Index(n_table) = ind-1;
        h.Experiment_Table = sortrows(h.Experiment_Table,'Index');
        % 'Index\ExpNo\Solvent\Experiment\Parameters'
        for i = 2:size(h.Experiment_Table,1)
            if h.Experiment_Table.Delete(i)
                tag = [num2str(h.Experiment_Table.Index(i))...
                    '\Delete holder°',num2str(h.Experiment_Table.Holder(i))];
            else
                tag = char(fullfile(num2str(h.Experiment_Table.Index(i)),...
                ['Exp°',num2str(h.Experiment_Table.ExpNo(i))],...
                h.Experiment_Table.Solvent(i),...
                h.Experiment_Table.Experiment(i),...
                h.Experiment_Table.Parameters(i)));
            end
            if i==2
                txt = {tag};
            else
                txt(end+1) = {tag};
            end
        end
        if exist('txt','var')
            if ~isempty(txt)
                h.list_box(2).String = txt;
            end
        end
        h.list_box(2).Value = h.list_box(2).Value-1;
        if several==0 && ind==2
            h.Experiment_Table.Priority =...
                zeros(size(h.Experiment_Table.Priority));
            h.Experiment_Table.Priority(n_table-1) = 1;
        end
    end
    h = info_display(h);
end
end
