function [status,output] = sendCommand2Topspin_thisPC(cmd)
% This function sends cmd to the command line of TOPSPIN.
%
%
% Input
% cmd                Command line for TOPSPIN
% waitcmd            1 to wait until cmd executed, 0 to not wait
%
% cmd = 'atma';
% cmd = 'lock "MeOD"';
% cmd = 'topshim tuneb tunebxyz';
% cmd = 'zg';
% cmd = 're 230106_BBI_flowtube_test 7 1 /opt/nmrdata/user/nmr/Nour';

%% Make sure that the corresponding cmd is valid
if isempty(cmd)
    return
end
%% Send command and wait for its execution on TOPSPIN
command = ['cd C:\Bruker\TopSpin4.0.7\prog\bin & sendgui ' cmd];
[status,output] = system(command,'-echo');
status = ~status;
end




