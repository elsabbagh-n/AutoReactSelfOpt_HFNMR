function [h,hh] = disable_entries(h,hh,allButton)
% This function disable entries when the delete checkbox is checked.

% Fixed Input Panel
if allButton==1
    c = {'Holder';'User';'Solvent';'StartRun';'StopRun';'Delete';'AreaCalculation'};
else
    c = {'User';'Solvent';'StartRun';'StopRun'};
end
for i = 1:length(c)
    [~,d] = ismember(c(i),h.checkList(:,1));
    if d
        check = cell2mat(h.checkList(d,2:end));
        if check(4)==0
            if check(3)==0 %it is an insert text
                h.editable_text_field(h.checkList{d,3},1).Enable = 'off';
            else %it is a popup menu
                h.popup_menu(h.checkList{d,4},1).Enable = 'off';
            end
        else%it is a check box then
            h.check_box(h.checkList{d,5},1).Enable = 'off';
        end
    end
end
if allButton~=1
    [~,d] = ismember('Holder',h.checkList(:,1));
    if d
        h.editable_text_field(h.checkList{d,3},1).ForegroundColor = [1 0 0];
    end
end

% Experimental Input Panel
for i = 1:length(h.ExperimentalInput)
    [~,d] = ismember(h.ExperimentalInput(i),h.checkList(:,1));
    if d
        check = cell2mat(h.checkList(d,2:end));
        if check(4)==0
            if check(3)==0 %it is an insert text
                h.editable_text_field(h.checkList{d,3},1).Enable='off';
            else %it is a popup menu
                h.popup_menu(h.checkList{d,4},1).Enable='off';
            end
        else %it is a check box then
            h.check_box(h.checkList{d,5},1).Enable='off';
        end
    end
end
[~,d] = ismember({'starttime'},lower(h.checkList(:,1)));
if d
    if h.check_box(h.checkList{d,5},1).Value
        h.calendar.push_button(1).Enable = 'off';
        h.calendar.push_button(2).Enable = 'off';
        h.calendar.static_text_field(1).Enable = 'off';
    end
end
if hh.v
    hh.calendar.f(1).Visible = 'off';
    hh.calendar.f(2).Visible = 'off';
    hh.v = 1;
else
    hh.v = 0;
end

% Parameter Input Panel
h.check_box(end).Enable='off';
h.popup_menu(end,1).Enable='off';
h.editable_text_field(end,1).Enable='off';
h.push_button(1).Enable='off';
h.push_button(2).Enable='off';
h.list_box(1).Enable='off';

if allButton==1
    % Edit Experiments List Panel
    h.push_button(3).Enable = 'off';%Add
    h.push_button(4).Enable = 'off';%Delete
    h.push_button(5).Enable = 'off';%Duplicate
    h.push_button(6).Enable = 'off';%up arrow
    h.push_button(7).Enable = 'off';%down arrow
    h.toggle_button(1).Enable = 'off';%accros arrow
    
    % Display Extset Text File Panel
    h.push_button(8).Enable = 'off';%Go
%     h.push_button(9).Enable = 'off';%up arrow
%     h.push_button(10).Enable = 'off';%down arrow
    h.push_button(11).Enable = 'off';%STOP
    h.push_button(12).Enable = 'off';%START
%     h.push_button(13).Enable = 'off';%X
end
end