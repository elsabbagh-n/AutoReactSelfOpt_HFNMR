function [AreaRegion,AreaValue,ExpInd] = region_area2(h,varargin)
% Region selection and area calculation Callback

global h1 newExp2Plot_ind autoFct bounds
if ~(size(varargin,2)==0)
    % Auto area calcultation for the available experiments using specified region bounds
    bounds = varargin{1};
    DoOnly = varargin{2}; 
    autoFct = 1;
    if (size(varargin,2)>=3)
        refArea = varargin{3};
    else
        refArea = 0;
    end
else
    % Manual bounds choice and area calculation
    autoFct = 0;
end

h1 = h;
target_exp = str2double(h1.status.uitextarea(3).Value{1});
if isnan(target_exp)
    target_set = 0;
else
    if ismember(target_exp,cell2mat(h.status.uit.Data.ExpNo))
        target_set = 1;
        target_ind = find(ismember(double(cell2mat(h1.status.uit.Data.ExpNo)),target_exp));
    else
        target_set = 0;
    end
end
if autoFct==0
    % Window for the region selection
    if h1.screen==1
        h1.regionArea.f(1) = uifigure('units','normalized','position',...
            [0.0207 0.0569 0.9586 0.8542],'Name','Status',...
            'HandleVisibility', 'on');
    else
        h1.regionArea.f(1) = uifigure('units','normalized','position',...
            [-0.9833 0.0468 0.6339 0.5519],'Name','Region Selection',...
            'HandleVisibility','on');
    end
    movegui(gcf,'center');
    
    % Table for completed experiments
    [~,a] = ismember(cell2mat(h1.status.st(:,4)),1);
    [~,b] = ismember(cell2mat(h1.status.errorR),1);
    [~,c] = ismember(cell2mat(h1.status.st(:,5)),1);
    completed_experiments = find(a);
    noError_experiments = find(~b);
    noDeleted_experiments = find(~c);
    d = intersect(noError_experiments,completed_experiments);
    d = intersect(d,noDeleted_experiments);
    if target_set
        d = intersect(d,target_ind);
    end
    Areas(1:length(d),1) = {[]};
    t0 = [h1.status.uit.Data(d,1:6),table(Areas)];
    h1.regionArea.uit = uitable(h1.regionArea.f(1),'Data',...
        t0,'Units','normalized',...
        'Position',[0.02 0.79 0.96 0.2],'CellSelectionCallback',@UITableCellSelection);
    
    % axe for spectra plotting
    % h1.regionArea.ax(1) = uiaxes(h1.regionArea.f(1),'units','normalized','position',...
    %     [0.04 0.06 0.5 0.7]);
    h1.regionArea.ax(1) = uiaxes(h1.regionArea.f(1),'units','pixels','position',...
        [49.6800 36.7600 608.5000 417.2000]);
    h1.regionArea.ax(1).XLabel.String = 'Frequency (ppm)';
    h1.regionArea.ax(1).YLabel.String = 'Magnitude';
    h1.regionArea.ax(1).ButtonDownFcn = @axes1_ButtonDownFcn;
    legend
    
    h1.button(1) = uibutton(h1.regionArea.f(1),'push','Text','GET AREA',...
        'Position',[700 150 100 100],'FontSize',16,'ButtonPushedFcn',@getArea);
    h1.button(2) = uibutton(h1.regionArea.f(1),'push','Text','ZOOM IN',...
        'Position',[850 150 100 100],'FontSize',16,'ButtonPushedFcn',@zoomIN);
    h1.button(3) = uibutton(h1.regionArea.f(1),'push','Text','ZOOM OUT',...
        'Position',[1000 150 100 100],'FontSize',16,'ButtonPushedFcn',@zoomOUT);
    h1.button(4) = uibutton(h1.regionArea.f(1),'push','Text','DONE',...
        'Position',[700 80 400 50],'FontSize',16,'ButtonPushedFcn',...
        @areaDone,'Enable','off');
    
    h1.text(1) = uilabel(h1.regionArea.f(1),'Position',[670 400 500 50],...
        'FontSize',17,'Text',{'Choose region by selecting, with two clicks on the plot, its bounds.'});
    
    h1.text(2) = uilabel(h1.regionArea.f(1),'Position',[670 350 500 50],...
        'FontSize',17,'Text',{['Selected Bounds : ',...
        '[                   ppm ,                   ppm ]']});
    h1.text(3) = uilabel(h1.regionArea.f(1),'Position',[835 365 60 25],...
        'FontSize',17,'Text',{' '},'BackgroundColor',[1 1 1],'HorizontalAlignment','center');
    h1.text(4) = uilabel(h1.regionArea.f(1),'Position',[965 365 60 25],...
        'FontSize',17,'Text',{' '},'BackgroundColor',[1 1 1],'HorizontalAlignment','center');
    h1.text(5) = uilabel(h1.regionArea.f(1),'Position',[670 300 500 50],...
        'FontSize',17,'Text',{'Area arround : '});
    h1.text(6) = uilabel(h1.regionArea.f(1),'Position',[790 315 100 25],...
        'FontSize',17,'Text',{' '},'BackgroundColor',[1 1 1],'HorizontalAlignment','center');
    
    h1.regionArea.goingOnce = 1;
    newExp2Plot_ind = [];
    h1.regionArea.LIM = [];
    
    clc
    fprintf('here...')
    pause(1)
    if target_set
        event.Indices = 1;
        UITableCellSelection(1, event)
    end
    pause(1)

    uiwait(h1.regionArea.f(1))
    AreaRegion = h1.regionArea.results.LIM;
%     ind = double(h1.regionArea.results.ExpNoRef.ExpNo{1});
%     AreaValue = h1.regionArea.results.ExpNo_Areas.Areas{ind==double(cell2mat(h1.regionArea.results.ExpNo_Areas.ExpNo))};
    AreaValue = h1.regionArea.results.ExpNo_Areas.Areas;
    ExpInd = d;
%     % Dialog print
%     clc
%     disp(h1.regionArea.results.ExpNo_Areas)
%     fprintf('\n Region bounds : [ %.2f , %.2f ] ppm.\n',h1.regionArea.results.LIM(1),h1.regionArea.results.LIM(2))
else
%     clc
%     disp(bounds)
    % Table for completed experiments
%     [~,a] = ismember(cell2mat(h1.status.st(:,4)),1);
%     [~,b] = ismember(cell2mat(h1.status.errorR),1);
%     [~,c] = ismember(cell2mat(h1.status.st(:,5)),1);
%     completed_experiments = find(a);
%     noError_experiments = find(~b);
%     Error_experiments = find(b);
%     noDeleted_experiments = find(~c);
%     d = intersect(noError_experiments,completed_experiments);
%     d = intersect(d,noDeleted_experiments);
    d = (1:size(h1.status.st))';
%     e = setdiff(union(d,Error_experiments),DoOnly);
    e = setdiff(d,DoOnly);
    Areas(1:length(d),1) = {[]};
%     Areas(1:size(h1.status.st,1),1) = {[]};
    if refArea
        Areas(e) = num2cell(cell2mat(h1.status.uit.Data.Area(e))./cell2mat(h1.status.uit.Data.RelativeArea(e)));
    else
        Areas(e) = h1.status.uit.Data.Area(e);
    end
    h1.regionArea.t0 = [h1.status.uit.Data(d,1:6),table(Areas)];
    newExp2Plot = double(cell2mat(h1.regionArea.t0.ExpNo));
    newExp2Plot_ind = find(ismember(double(cell2mat(h1.regionArea.t0.ExpNo)),newExp2Plot));
    h1.regionArea.plt(1:size(h1.status.st,1),1) = {struct};
    h1.regionArea.plt(DoOnly) = plot_for_area_selection(h1.regionArea.t0,newExp2Plot(DoOnly),newExp2Plot_ind(DoOnly),autoFct);
    %%
    for i = 1:length(DoOnly)%1:size(h1.regionArea.plt,1)
        if ~isempty(bounds)
            areaCalculation(newExp2Plot_ind(DoOnly(i)))
        else
            break
        end
    end
    %%
    if ~isempty(bounds)
        h1.regionArea.results.LIM = bounds;
        h1.regionArea.results.ExpNo_Areas = h1.regionArea.t0(:,[3,end]);
        h1.regionArea.results.ExpNoRef = newExp2Plot_ind(1);
        
        AreaRegion = h1.regionArea.results.LIM;
        %     ind = h1.regionArea.results.ExpNoRef;
        %     AreaValue = h1.regionArea.results.ExpNo_Areas.Areas{ind==double(cell2mat(h1.regionArea.results.ExpNo_Areas.ExpNo))};
        AreaValue = h1.regionArea.results.ExpNo_Areas.Areas;
        ExpInd = d;
%         % Dialog print
%         clc
%         disp(h1.regionArea.results.ExpNo_Areas)
%         fprintf('\n Region bounds : [ %.2f , %.2f ] ppm.\n',h1.regionArea.results.LIM(1),h1.regionArea.results.LIM(2))
    else
        AreaRegion = [];
        AreaValue = [];
        ExpInd = [];
    end
end
end

%% used functions

% Display spectrum for the selected experiment row
function UITableCellSelection(~, event)
global h1 newExp2Plot_ind autoFct
stt = h1.regionArea;
selectedCell = event.Indices;
% display(selectedCell)
newExp2Plot = double(stt.uit.Data.ExpNo{selectedCell(1)});
newExp2Plot_ind = selectedCell(1);
stt.plt(newExp2Plot_ind).plt = plot_for_area_selection(stt,newExp2Plot,newExp2Plot_ind,autoFct);
clc
h1.regionArea = stt;
if isempty(h1.regionArea.LIM)
    LIM = [min(h1.regionArea.ax(1).XLim),max(h1.regionArea.ax(1).XLim)];
    h1.regionArea.LIM = LIM;
    h1.regionArea.X1 = xline(LIM(1),'LineStyle',':','HandleVisibility','off');
    h1.regionArea.X2 = xline(LIM(2),'LineStyle',':','HandleVisibility','off');
else
    LIM = [h1.regionArea.X1.Value h1.regionArea.X2.Value];
end
h1.text(3).Text = num2str(round(LIM(1),2));
h1.text(4).Text = num2str(round(LIM(2),2));
% areaCalculation
% apply2all
end

% Click on the plot to select the area region bounds (2 consecutif clicks)
function axes1_ButtonDownFcn(objectHandle,~)
% function axes1_ButtonDownFcn ( objectHandle , eventData )
global coordinates h1 newExp2Plot_ind
if ~isempty(newExp2Plot_ind)
    axesHandle  = get(objectHandle,'Parent');
    coordinates = get(axesHandle,'CurrentPoint');
    coordinates = coordinates(1,1:2);
    d = h1.regionArea.ax(1).InnerPosition;
    xlim0 = h1.regionArea.ax(1).XLim;
    a = xlim0(2)+(xlim0(1)-xlim0(2))*(coordinates(1)-d(1))/d(3);
    if h1.regionArea.goingOnce==1
        h1.button(1).Enable = 'off';
        h1.button(2).Enable = 'off';
        h1.button(3).Enable = 'off';
        h1.button(4).Enable = 'off';
        h1.regionArea.X2.Value = a;
        h1.regionArea.X1.Value = xlim0(1);
        h1.regionArea.goingOnce  = 0;
        h1.text(6).Text = ' ';
        setBounds
        drawnow
    else
        h1.regionArea.X1.Value = a;
        h1.regionArea.goingOnce  = 1;
        if h1.regionArea.X1.Value>h1.regionArea.X2.Value
            a = h1.regionArea.X1.Value;
            b = h1.regionArea.X2.Value;
            h1.regionArea.X1.Value = b;
            h1.regionArea.X2.Value = a;
        end
        setBounds
        drawnow
%         return
%         areaCalculation
%         apply2all
        h1.button(1).Enable = 'on';
        h1.button(2).Enable = 'on';
        h1.button(3).Enable = 'on';
        h1.button(4).Enable = 'on';
    end
    clc
else
    clc
    fprintf('No plot available')
end
end

% Display the bounds in the window
function setBounds(varargin)
global h1
LIM = [h1.regionArea.X1.Value h1.regionArea.X2.Value];
h1.text(3).Text = num2str(round(LIM(1),2));
h1.text(4).Text = num2str(round(LIM(2),2));
end

% Area calculation using two integral methods
function areaCalculation(varargin)
global h1 newExp2Plot_ind autoFct bounds
if ~(size(varargin,2)==0)
    % Apply to all
    newExp2Plot_ind0 = varargin{1};
else
    newExp2Plot_ind0 = newExp2Plot_ind;
end
if autoFct==0
    % Dataset
    X = h1.regionArea.plt(newExp2Plot_ind0).plt{1}.XData; X = fliplr(X);
    Y = h1.regionArea.plt(newExp2Plot_ind0).plt{1}.YData; Y = fliplr(Y);
    
    % Initial Integration
    Int = cumtrapz(X,Y);
    h1.regionArea.Intv = @(a,b) max(Int(X<=b)) - min(Int(X>=a));
    
    % Bounds
    LIM = [h1.regionArea.X1.Value,h1.regionArea.X2.Value];
    
    % Area Calculation version 1
    h1.regionArea.Int_Val(newExp2Plot_ind0,1) = h1.regionArea.Intv(LIM(1),LIM(2));
    % Area Calculation version 2
    idx = X>LIM(1) & X<LIM(2);
    h1.regionArea.Int_Val(newExp2Plot_ind0,2) = trapz(X(idx),Y(idx));
    
    % Display in window
    area_i = round(h1.regionArea.Int_Val(newExp2Plot_ind0,2));
    h1.text(6).Text = num2str(area_i,'%.3d');
    h1.regionArea.uit.Data.Areas{newExp2Plot_ind0} = area_i;
else
    % Dataset
    X = h1.regionArea.plt{newExp2Plot_ind0}.XAxis; X = flipud(X);
    Y = h1.regionArea.plt{newExp2Plot_ind0}.Data; Y = flipud(Y);
    
    % Initial Integration
    Int = cumtrapz(X,Y);
    h1.regionArea.Intv = @(a,b) max(Int(X<=b)) - min(Int(X>=a));
    
    % Bounds
    LIM = bounds;
    
    % Check bounds
    go = 1;
    if (LIM(1)<min(X) || LIM(2)>max(X))
        clc
        if (LIM(1)<min(X))
            minn = 999;
            for i = 1:length(h1.regionArea.plt)
                minn = min(minn,h1.regionArea.plt{i}.XAxis(end));
            end
            if h1.autoMode==0
                err = ['The lower bound is too low. Please choose one larger than '...
                    num2str(minn) ' ppm.\n'];
                fprintf(err)
                nes_msgbox = msgbox(err);
                waitfor(nes_msgbox)
            end
            l1 = 1;
        else
            minn = min(X);
            l1 = 0;
        end
        if (LIM(2)>max(X))
            maxx = -1;
            for i = 1:length(h1.regionArea.plt)
                maxx = max(maxx,h1.regionArea.plt{i}.XAxis(1));
            end
            if h1.autoMode==0
                err = ['The larger bound is too large. Please choose one lower than '...
                    num2str(maxx) ' ppm.\n'];
                fprintf(err)
                nes_msgbox = msgbox(err);
                waitfor(nes_msgbox)
            end
            l2 = 1;
        else
            maxx = max(X);
            l2 = 0;
        end
        go = 0;
    end
    if go==0
        if h1.autoMode
            ask = 1;
            while (ask)
                % User's Choice :  change this bound?
                quest = {'Lower bound','Larger bound'};
                % Default answers
                if l1
                    answrs{1} = '';
                    % Dialog print
                    err = ['The lower bound is too low. Please choose one larger than '...
                        num2str(minn) ' ppm.\n'];
                    fprintf(err)
                    nes_msgbox = msgbox(err);
                    waitfor(nes_msgbox)
                    fprintf('Input another low bound. (press ENTER key for a quick OK)\n')
                else
                    answrs{1} = num2str(LIM(1));
                end
                if l2
                    answrs{2} = '';
                    % Dialog print
                    err = ['The larger bound is too large. Please choose one lower than '...
                        num2str(maxx) ' ppm.\n'];
                    fprintf(err)
                    nes_msgbox = msgbox(err);
                    waitfor(nes_msgbox)
                    fprintf('Input another large bound. (press ENTER key for a quick OK)\n')
                else
                    answrs{2} = num2str(LIM(2));
                end
                
                % Input dialog window
                answer0 = inputdlg(quest,'Input bounds',[1 40],answrs);
                answer(1) = str2double(answer0{1});
                answer(2) = str2double(answer0{2});
                if ~isempty(answer(1))
                    if answer(1)>=minn
                        ask1 = 0;
                        l1 = 0;
                    else
                        ask1 = 1;
                        l1 = 1;
                    end
                else
                    ask1 = 1;
                    l1 = 1;
                end
                if ~isempty(answer(1))
                    if ((answer(2)<=maxx) && (answer(2)~=answer(1)))
                        ask2 = 0;
                        l2 = 0;
                    else
                        ask2 = 1;
                        l2 = 1;
                    end
                else
                    ask2 = 1;
                    l2 = 1;
                end
                ask = ask1+ask2;
            end
            bounds = [answer(1),answer(2)];
            h1.AreaRegion = [answer(1),answer(2)];
            areaCalculation(newExp2Plot_ind0)
        else
            bounds = [];
        end
        return
    end
    % Area Calculation version 1
    h1.regionArea.Int_Val(newExp2Plot_ind0,1) = h1.regionArea.Intv(LIM(1),LIM(2));
    % Area Calculation version 2
    idx = X>LIM(1) & X<LIM(2);
    h1.regionArea.Int_Val(newExp2Plot_ind0,2) = trapz(X(idx),Y(idx));
    
    % Display in window
    area_i = round(h1.regionArea.Int_Val(newExp2Plot_ind0,2));
    h1.regionArea.t0.Areas{newExp2Plot_ind0} = area_i;
end
end

% Area calculation for all other plot for the chosen bounds
function apply2all(varargin)
global h1 newExp2Plot_ind autoFct
stt = h1.regionArea;
ind = 1:size(stt.uit.Data,1);
for i = find(ind~=newExp2Plot_ind)
    newExp2Plot = double(stt.uit.Data.ExpNo{ind(i)});
    newExp2Plot_ind0 = ind(i);
    stt.plt(newExp2Plot_ind0).plt = plot_for_area_selection(stt,newExp2Plot,newExp2Plot_ind0,autoFct);
    clc
    h1.regionArea = stt;
    LIM = [h1.regionArea.X1.Value h1.regionArea.X2.Value];
    h1.text(3).Text = num2str(round(LIM(1),2));
    h1.text(4).Text = num2str(round(LIM(2),2));
    areaCalculation(newExp2Plot_ind0)
end
newExp2Plot = double(stt.uit.Data.ExpNo{newExp2Plot_ind});
stt.plt(newExp2Plot_ind).plt = plot_for_area_selection(stt,newExp2Plot,newExp2Plot_ind,autoFct);
clc
h1.regionArea = stt;
h1.text(6).Text = num2str(h1.regionArea.uit.Data.Areas{newExp2Plot_ind},'%.3d');
end

% Get Area of the selected region
function getArea(varargin)
global h1
h1.button(1).Enable = 'off';
h1.button(2).Enable = 'off';
h1.button(3).Enable = 'off';
h1.button(4).Enable = 'off';
drawnow
areaCalculation
apply2all
h1.button(1).Enable = 'on';
h1.button(2).Enable = 'on';
h1.button(3).Enable = 'on';
h1.button(4).Enable = 'on';
drawnow
end

% Zoom in to the selected region
function zoomIN(varargin)
global h1 newExp2Plot_ind
if ~isempty(newExp2Plot_ind)
    yy = h1.regionArea.ax(1).YLim;
    LIM = [h1.regionArea.X1.Value,h1.regionArea.X2.Value];
    h1.regionArea.ax(1).XLim = LIM;
    h1.regionArea.ax(1).YLim = yy;
else
    clc
    fprintf('No plot available.')
end
end

% Zoom out to the original spectrum limits
function zoomOUT(varargin)
global h1 newExp2Plot_ind
if ~isempty(newExp2Plot_ind)
    yy = h1.regionArea.ax(1).YLim;
    p = h1.regionArea.ax(1).Children;
    h1.regionArea.ax(1).XLim = [min(p.XData) max(p.XData)];
    h1.regionArea.ax(1).YLim = yy;
else
    clc
    fprintf('No plot available.')
end
end

% Area calculation is done
function areaDone(varargin)
global h1 newExp2Plot_ind
if ~isempty(newExp2Plot_ind)
    a = h1.regionArea.uit.Data.Areas;
    b = 1;
    for i = 1:length(a)
        if isempty(a{i})
            b = 0;
            break
        end
    end
    if b
        LIM = [h1.regionArea.X1.Value,h1.regionArea.X2.Value];
        ExpNo_Areas = h1.regionArea.uit.Data(:,[3,end]);
        h1.regionArea.results.LIM = LIM;
        h1.regionArea.results.ExpNo_Areas = ExpNo_Areas;
        h1.regionArea.results.ExpNoRef = ExpNo_Areas(newExp2Plot_ind,1);
        close(h1.regionArea.f(1))
    else
        clc
        fprintf('Area is not calculated for all spectra.')
    end
else
    clc
    fprintf('No plot available.')
end
end






