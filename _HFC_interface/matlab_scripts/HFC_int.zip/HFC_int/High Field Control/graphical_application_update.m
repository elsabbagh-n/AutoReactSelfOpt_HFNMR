function status = graphical_application_update(status,screen)
% This funcion generates the tab for the graphical update in the status
% window.
%
%
% Input
%   status          handles of the status figure already generated.
%   (required)
%
%   screen          number of Monitor screens available.
%   (required)
%
%
% Output
%   status          the additionnal handles of the created figure.
%   (required)
%
% Nour EL SABBAGH - 2022


%% Check for TAB
if ~isfield(status,'F')
    return
else
    % The status window contains tabs
    G = status.F.Children;
    for i = 1:length(G.Children)
        if strcmp(G.Children(i).Title,'Status table & Area setup')
            TAB(1) = G.Children(i);
        elseif strcmp(G.Children(i).Title,'Graphical Application Update')
            TAB(2) = G.Children(i);
        end
    end
end

G.SelectedTab = TAB(2);
status.graphical_application_update.f(1) = TAB(2);

%% MATLAB block

% Panel
status.graphical_application_update.panel(1) = uipanel(...
    status.graphical_application_update.f(1),'units','normalized','Position',...
    [0.03 0.1 0.3 0.8],'Title','MATLAB','Tag','MATLAB');

% Labels
% Create Experiments
status.graphical_application_update.text(1) = uilabel(...
    status.graphical_application_update.panel(1),'Position',[81 160 175 25],...
    'FontSize',17,'Text','Create Experiments','Tag','MATLAB_1',...
    'HorizontalAlignment','center','BackgroundColor',[0.8,0.8,0.8]);
% Start Automation
status.graphical_application_update.text(2) = uilabel(...
    status.graphical_application_update.panel(1),'Position',[81 125 175 25],...
    'FontSize',17,'Text','Start Automation','Tag','MATLAB_2',...
    'HorizontalAlignment','center','BackgroundColor',[0.8,0.8,0.8]);
% Stop Automation
status.graphical_application_update.text(3) = uilabel(...
    status.graphical_application_update.panel(1),'Position',[81 90 175 25],...
    'FontSize',17,'Text','Stop Automation','Tag','MATLAB_3',...
    'HorizontalAlignment','center','BackgroundColor',[0.8,0.8,0.8]);
% Area calculation
status.graphical_application_update.text(4) = uilabel(...
    status.graphical_application_update.panel(1),'Position',[81 15 175 25],...
    'FontSize',17,'Text','Area Calculation','Tag','MATLAB_4',...
    'HorizontalAlignment','center','BackgroundColor',[0.8,0.8,0.8]);
drawnow
%% IconNMR block
% Panel
status.graphical_application_update.panel(2) = uipanel(...
    status.graphical_application_update.f(1),'units','normalized','Position',...
    [0.67 0.1 0.3 0.8],'Title','IconNMR','Tag','IconNMR');

% Labels
% Add Experiments
status.graphical_application_update.text(5) = uilabel(...
    status.graphical_application_update.panel(2),'Position',[81 160 175 25],...
    'FontSize',17,'Text','Add Experiments','Tag','IconNMR_1',...
    'HorizontalAlignment','center','BackgroundColor',[0.8,0.8,0.8]);
% Automation launch
status.graphical_application_update.text(6) = uilabel(...
    status.graphical_application_update.panel(2),'Position',[81 125 175 25],...
    'FontSize',17,'Text','Automation Launch','Tag','IconNMR_2',...
    'HorizontalAlignment','center','BackgroundColor',[0.8,0.8,0.8]);
% Automation stop
status.graphical_application_update.text(7) = uilabel(...
    status.graphical_application_update.panel(2),'Position',[81 90 175 25],...
    'FontSize',17,'Text','Automation Stop','Tag','IconNMR_3',...
    'HorizontalAlignment','center','BackgroundColor',[0.8,0.8,0.8]);
% Acquisition in progress
status.graphical_application_update.text(8) = uilabel(...
    status.graphical_application_update.panel(2),'Position',[81 45 175 20],...
    'FontSize',17,'Text','Acquisition','Tag','IconNMR_4',...
    'HorizontalAlignment','center','BackgroundColor','none');
% Acquisition in progress
status.graphical_application_update.text(9) = uilabel(...
    status.graphical_application_update.panel(2),'Position',[193 15 100 25],...
    'FontSize',17,'Text','In Progress','Tag','IconNMR_5',...
    'HorizontalAlignment','center','BackgroundColor',[0.8,0.8,0.8]);
% Acquisition finished
status.graphical_application_update.text(10) = uilabel(...
    status.graphical_application_update.panel(2),'Position',[40 15 100 25],...
    'FontSize',17,'Text','Finished','Tag','IconNMR_6',...
    'HorizontalAlignment','center','BackgroundColor',[0.8,0.8,0.8]);
drawnow
%% Request block
% % Panel
% h.graphical_application_update.panel(3) = uipanel(...
%     h.graphical_application_update.f(1),'units','normalized','Position',...
%     [0.36 0.55 0.28 0.35],'Title','Transfer Request','Tag','Request');

% Labels
status.graphical_application_update.text(11) = uilabel(...
    status.graphical_application_update.f(1),'Position',[470 215 175 25],...
    'FontSize',17,'Text','Request Transfer','Tag','Request',...
    'HorizontalAlignment','center','BackgroundColor',[0.8,0.8,0.8]);
drawnow
%% Pathways between MATLAB and IconNMR
status.graphical_application_update.panel(1).Position = [0.13 0.1 0.2 0.8];
status.graphical_application_update.panel(2).Position = [0.67 0.1 0.2 0.8];
% Create
status.graphical_application_update.pathway(1) = annotation(...
    status.graphical_application_update.f(1),'arrow',[0.33 0.67],[0.73 0.73],...
    'Tag','Request_Arrow_1');

% Start
status.graphical_application_update.pathway(2) = annotation(...
    status.graphical_application_update.f(1),'arrow',[0.33 0.67],[0.61 0.61],...
    'Tag','Request_Arrow_2');

% Stop
status.graphical_application_update.pathway(3) = annotation(...
    status.graphical_application_update.f(1),'arrow',[0.33 0.67],[0.48 0.48],...
    'Tag','Request_Arrow_3');
drawnow
%% Pathways in IconNMR
% Add
status.graphical_application_update.pathway(4) = annotation(...
    status.graphical_application_update.panel(2),'line',[0.85 0.95],[0.87 0.87],...
    'Tag','IconNMR_Line_1');

% Launch
status.graphical_application_update.pathway(5) = annotation(...
    status.graphical_application_update.panel(2),'line',[0.85 0.95],[0.69 0.69],...
    'Tag','IconNMR_Line_2');

% between Add/Launch & In progress
status.graphical_application_update.pathway(6) = annotation(...
    status.graphical_application_update.panel(2),'line',[0.95 0.95],[0.87 0.15],...
    'Tag','IconNMR_Line_3','Color',[1.00,0.41,0.41]);

% between In progress & Finished
status.graphical_application_update.pathway(7) = annotation(...
    status.graphical_application_update.panel(2),'line',[0.45 0.55],[0.13 0.13],...
    'Tag','IconNMR_Line_4');
drawnow
%% Dataset block
% % Panel
% h.graphical_application_update.panel(4) = uipanel(...
%     h.graphical_application_update.f(1),'units','normalized','Position',...
%     [0.36 0.1 0.28 0.42],'Title','Transfer Dataset','Tag','Dataset');

% Labels
status.graphical_application_update.text(12) = uilabel(...
    status.graphical_application_update.f(1),'Position',[470 70 175 25],...
    'FontSize',17,'Text','Dataset Transfer','Tag','Dataset',...
    'HorizontalAlignment','center','BackgroundColor',[0.8,0.8,0.8]);
drawnow
%% Pathways between IconNMR and MATLAB
% Area
status.graphical_application_update.pathway(8) = annotation(...
    status.graphical_application_update.f(1),'arrow',[0.67 0.33],[0.2 0.2],...
    'Tag','Dataset_Arrow_4');
drawnow
%% Automation ON or OFF
% Labels
if screen==1
    status.graphical_application_update.text(13) = uilabel(...
        status.graphical_application_update.f(1),'Position',[1060 145 100 40],...
        'FontSize',17,'Text',{'Automation','-ON-'},'Tag','Automation_ON',...
        'HorizontalAlignment','center','BackgroundColor',[0.8,0.8,0.8]);
    status.graphical_application_update.text(14) = uilabel(...
        status.graphical_application_update.f(1),'Position',[1060 90 100 40],...
        'FontSize',17,'Text',{'Automation','-OFF-'},'Tag','Automation_ON',...
        'HorizontalAlignment','center','BackgroundColor',[1.00,0.41,0.41]);
else
    status.graphical_application_update.text(13) = uilabel(...
        status.graphical_application_update.f(1),'Position',[1000 145 100 40],...
        'FontSize',17,'Text',{'Automation','-ON-'},'Tag','Automation_ON',...
        'HorizontalAlignment','center','BackgroundColor',[0.8,0.8,0.8]);
    status.graphical_application_update.text(14) = uilabel(...
        status.graphical_application_update.f(1),'Position',[1000 90 100 40],...
        'FontSize',17,'Text',{'Automation','-OFF-'},'Tag','Automation_ON',...
        'HorizontalAlignment','center','BackgroundColor',[1.00,0.41,0.41]);
end
drawnow
%% Update
return
figure(status.F)
% Package_tags = {'MATLAB','IconNMR'};
% Action_tags = {'MATLAB_1','MATLAB_2','MATLAB_3','MATLAB_4','IconNMR_1',...
%     'IconNMR_2','IconNMR_3','IconNMR_5','IconNMR_6','Request','Dataset'};%'IconNMR_4'
% Arrow_tags = {'Request_Arrow_1','Request_Arrow_2','Request_Arrow_3',...
%     'Dataset_Arrow_4'};
% Line_tags = {'IconNMR_Line_1','IconNMR_Line_2','IconNMR_Line_3','IconNMR_Line_4'};

% BackgroundColor
Package_On  = [0.89,1.00,0.89];
Package_Off = [0.94,0.94,0.94];
Action_On  = [0.51,1.00,0.51];
Action_Off = [0.80,0.80,0.80];
Arrow_On  = [0.19,1.00,0.19];
Arrow_Off = [0,0,0];
Automation_OFF = [1.00,0.41,0.41];
% Line_On  = [0.19,1.00,0.19];
% Line_Off = [0,0,0];

status.running = 0;

% Requested graphical updates
drawnow
for stage = 1:14
        pause(2)
    if status.running
        status.graphical_application_update.text(13).BackgroundColor = Action_On;
        status.graphical_application_update.text(14).BackgroundColor = Action_Off;
        status.graphical_application_update.pathway(6).Color = Arrow_On;
    else
        status.graphical_application_update.text(13).BackgroundColor = Action_Off;
        status.graphical_application_update.text(14).BackgroundColor = Automation_OFF;
        status.graphical_application_update.pathway(6).Color = Automation_OFF;
    end
    
    % Create experiment in Matlab
    if stage==1
        status.graphical_application_update.panel(1).BackgroundColor = Package_On; % MATLAB package
        status.graphical_application_update.text(1).BackgroundColor = Action_On; % Creation action
        continue
    else
        status.graphical_application_update.panel(1).BackgroundColor = Package_Off; % MATLAB package
        status.graphical_application_update.text(1).BackgroundColor = Action_Off; % Creation action
    end
    
    % Transfer list of created experiment in Matlab
    if stage==2
        status.graphical_application_update.text(11).BackgroundColor = Action_On; % Request Transfer
        status.graphical_application_update.pathway(1).Color = Arrow_On; % Transfer Creation arrow
        continue
    else
        status.graphical_application_update.text(11).BackgroundColor = Action_Off; % Request Transfer
        status.graphical_application_update.pathway(1).Color = Arrow_Off; % Transfer Creation arrow
    end
    
    % Add experiment in IconNMR
    if stage==3
        status.graphical_application_update.panel(2).BackgroundColor = Package_On; % IconNMR package
        status.graphical_application_update.text(5).BackgroundColor = Action_On; % Add experiment
        status.graphical_application_update.pathway(4).Color = Arrow_On; % Add experiment line
        continue
    else
        status.graphical_application_update.panel(2).BackgroundColor = Package_Off; % IconNMR package
        status.graphical_application_update.text(5).BackgroundColor = Action_Off; % Add experiment
        status.graphical_application_update.pathway(4).Color = Arrow_Off; % Add experiment line
    end
    
    % Start automation in MATLAB
    if stage==4
        status.graphical_application_update.panel(1).BackgroundColor = Package_On; % IconNMR package
        status.graphical_application_update.text(2).BackgroundColor = Action_On; % Start automation
        continue
    else
        status.graphical_application_update.panel(1).BackgroundColor = Package_Off; % IconNMR package
        status.graphical_application_update.text(2).BackgroundColor = Action_Off; % Start automation
    end
    
    % Transfer Start requested in MATLAB
    if stage==5
        status.graphical_application_update.text(11).BackgroundColor = Action_On; % Request Transfer
        status.graphical_application_update.pathway(2).Color = Arrow_On; % Transfer start arrow
        continue
    else
        status.graphical_application_update.text(11).BackgroundColor = Action_Off; % Request Transfer
        status.graphical_application_update.pathway(2).Color = Arrow_Off; % Transfer start arrow
    end
    
    % Automation launched in IconNMR
    if stage==6
        status.graphical_application_update.panel(2).BackgroundColor = Package_On; % IconNMR package
        status.graphical_application_update.text(6).BackgroundColor = Action_On; % Automation launched
        status.graphical_application_update.pathway(5).Color = Arrow_On; % Automation launched line
        status.running = 1; % Automation ON
        continue
    else
        status.graphical_application_update.panel(2).BackgroundColor = Package_Off; % IconNMR package
        status.graphical_application_update.text(6).BackgroundColor = Action_Off; % Automation launched
        status.graphical_application_update.pathway(5).Color = Arrow_Off; % Automation launched line
    end
    
    % Acquisition in progress in IconNMR
    if stage==7
        status.graphical_application_update.panel(2).BackgroundColor = Package_On; % IconNMR package
        status.graphical_application_update.text(9).BackgroundColor = Action_On; % Acquisition in progress
        status.graphical_application_update.pathway(7).Color = Arrow_On; % Acquisition in progress line
        continue
    else
        status.graphical_application_update.panel(2).BackgroundColor = Package_Off; % IconNMR package
        status.graphical_application_update.text(9).BackgroundColor = Action_Off; % Acquisition in progress
        status.graphical_application_update.pathway(7).Color = Arrow_Off; % Acquisition in progress line
    end

    % Acquisition finished in IconNMR
    if stage==8
        status.graphical_application_update.panel(2).BackgroundColor = Package_On; % IconNMR package
        status.graphical_application_update.text(10).BackgroundColor = Action_On; % Acquisition finished
        continue
    else
        status.graphical_application_update.panel(2).BackgroundColor = Package_Off; % IconNMR package
        status.graphical_application_update.text(10).BackgroundColor = Action_Off; % Acquisition finished
    end
    
    % Transfer Dataset 
    if stage==9
        status.graphical_application_update.text(12).BackgroundColor = Action_On; % Dataset Transfer
        status.graphical_application_update.pathway(8).Color = Arrow_On; % Transfer Dataset arrow
        continue
    else
        status.graphical_application_update.text(12).BackgroundColor = Action_Off; % Dataset package
        status.graphical_application_update.pathway(8).Color = Arrow_Off; % Transfer Dataset arrow
    end

    % Area calculation in MATLAB
    if stage==10
        status.graphical_application_update.panel(1).BackgroundColor = Package_On; % IconNMR package
        status.graphical_application_update.text(4).BackgroundColor = Action_On; % Area calculation
        continue
    else
        status.graphical_application_update.panel(1).BackgroundColor = Package_Off; % IconNMR package
        status.graphical_application_update.text(4).BackgroundColor = Action_Off; % Area calculation
    end
    
    % Stop automation in MATLAB
    if stage==11
        status.graphical_application_update.panel(1).BackgroundColor = Package_On; % IconNMR package
        status.graphical_application_update.text(3).BackgroundColor = Automation_OFF; % Stop automation
        continue
    else
        status.graphical_application_update.panel(1).BackgroundColor = Package_Off; % IconNMR package
        status.graphical_application_update.text(3).BackgroundColor = Action_Off; % Stop automation
    end
    
    % Transfer Stop requested in MATLAB
    if stage==12
        status.graphical_application_update.text(11).BackgroundColor = Action_On; % Request Transfer
        status.graphical_application_update.pathway(3).Color = Automation_OFF; % Transfer stopp arrow
        continue
    else
        status.graphical_application_update.text(11).BackgroundColor = Action_Off; % Request Transfer
        status.graphical_application_update.pathway(3).Color = Arrow_Off; % Transfer stopp arrow
    end
    
    % Automation stopped in IconNMR
    if stage==13
        status.graphical_application_update.panel(2).BackgroundColor = Package_On; % IconNMR package
        status.graphical_application_update.text(7).BackgroundColor = Automation_OFF; % Automation stopped
        status.running = 0; % Automation OFF
        continue
    else
        status.graphical_application_update.panel(2).BackgroundColor = Package_Off; % IconNMR package
        status.graphical_application_update.text(7).BackgroundColor = Action_Off; % Automation stopped
    end
end

end













