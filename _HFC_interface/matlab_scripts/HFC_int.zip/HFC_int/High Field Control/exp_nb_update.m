function h = exp_nb_update(h,varargin)
% This function updates the number of the experiment (ExpNo). If no value
% is inserted by the user, it gives the currently inserted experiment a
% not taken number. If the user chooses to insert one, this function
% updates it to the smallest not taken one.

% h = tag_update(h);
if ~isempty(varargin)
    beginning = 1;
else
    beginning = 0;
end
    
[~,b]=ismember({'expno'},lower(h.checkList(:,1)));
if b
    check = cell2mat(h.checkList(b,2:end));
    if beginning
        nb = 1;
    else
        nb = str2double(h.editable_text_field(check(2)).String);
        if ~nb
            nb = 1;
        end
        if find(h.Experiment_Table.ExpNo==nb)
            nb = 1;
        end
    end
    list = [h.archive;h.Experiment_Table.ExpNo];
    while (find(list==nb))
        nb = nb+1;
    end
    h.editable_text_field(check(2)).String = num2str(nb);
end
end
