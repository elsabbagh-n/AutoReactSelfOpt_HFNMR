function Tr = get_procs_from_spectro500(expPath,folderName,desiredPath,sub,virt)
% This function transfer files from a remonte PC to this PC. Hostname,
% Username and Password are set to the those of Spectro500. It transfers
% file of the selected folder, and files from its subfolders indicated. If
% the transfer is done successfully, it returns a value 1; if there were no
% transfer or the folderName didn't exist, it returns a nil value.
%
% Input
% expPath      Path of the file to be downloaded from the remote PC
% folderName      Name of the file to be downloaded from the remote PC
% desiredPath   Path to which the file will be download on this PC

global f l folderName2 command_output

%% User Input

% Required information about the remote PC (spectro 500MHz)
Hostname = '172.16.77.57';
Hostname = 'RMN500-1525.ceisam.sciences.univ-nantes.prive';
Username = 'nmr';
Password = 'topspin';


%% Folder Upload

if virt
    command = ['cd ' expPath 'user/ ; ls'];
    command_output = ssh2_simple_command(Hostname, Username, Password,command);
    command = ['cd ' expPath ' ; ls'];
    command_output = [command_output ; ssh2_simple_command(Hostname, Username, Password,command)];
    [i,~] = strnearest({folderName},command_output);
    folderName0 = folderName;
    f = figure;
    uicontrol('style','text','units','normalized',...
        'string',['Experiment ' folderName ' is a virtual parameter set. Select its original experiment:'],...
        'FontName','Arial','FontSize',14,...
        'BackgroundColor',[0.94,0.94,0.94],'Parent',f,...
        'Position',[0.05 0.8 0.9 0.14]);
    l = uicontrol('style','listbox','units','normalized',...
        'Parent',f,'Visible','on','FontSize',11,...
        'Position',[0.05 0.2 0.9 0.6],'String',command_output(i{1}),...
        'FontName','Arial');
    uicontrol('style','pushbutton','units','normalized',...
        'BackgroundColor',[0.94,0.94,0.94],'string','Select','FontName','Arial',...
        'Parent',f,'callback',@callback01,'Position',...
        [0.05 0.06 0.425 0.1],'Value',0,'FontSize',20,...
        'ForegroundColor',[0.05,0.65,0.12]);
    uicontrol('style','pushbutton','units','normalized',...
        'BackgroundColor',[0.94,0.94,0.94],'string','Not here','FontName','Arial',...
        'Parent',f,'callback',@callback02,'Position',...
        [0.525 0.06 0.425 0.1],'Value',0,'FontSize',20,...
        'ForegroundColor',[0.78,0.22,0.32]);
    uiwait(f)
    folderName = folderName2;
end

command = ['cd ' expPath folderName ' ; ls'];
command_output = ssh2_simple_command(Hostname, Username, Password,command);
filename = 'proc';
if sub==0 && virt==1 && ~ismember({filename},command_output)
    expPath = [expPath 'user/'];
    command = ['cd ' expPath folderName ' ; ls'];
    command_output = ssh2_simple_command(Hostname, Username, Password,command);
end
if ismember({filename},command_output) % Topspin exp
%     clc
    % get the acqu file of the experiment
    ssh2_conn = scp_simple_get(Hostname, Username, Password,filename,desiredPath,[expPath folderName]);
    ssh2_close(ssh2_conn); %close connection when done
    % rename it for clear attribution
    if virt
        movefile([desiredPath '\proc'],[desiredPath '\' filename '_' folderName0])
    else
        movefile([desiredPath '\proc'],[desiredPath '\' filename '_' folderName])
    end
    Tr = 1;
%     clc
    if ~virt
%         fprintf('\nTopSpin experiment')
    end
else % User exp
    if sub==1 && virt==0
        expPath2 = [expPath 'user/'];
        Tr = get_procs_from_spectro500(expPath2,folderName,desiredPath,0,0);
        if Tr==1
%             clc
%             fprintf('\nUser experiment')
        else
%             clc
%             fprintf('\nVirtual Parameter experiment')
            Tr = get_procs_from_spectro500(expPath,folderName,desiredPath,0,1);
        end
    else
        Tr = 0;
    end
end


end

function callback01(varargin)
global f l folderName2
folderName2 = l.String{l.Value};
close(f)
end

function callback02(varargin)
global f l command_output
l.Value = 1;
l.String = command_output;
for i = 1:length(f.Children)
    if ismember({f.Children(i).Style},{'pushbutton'})
        if ismember({f.Children(i).String},{'Not here'})
            f.Children(i).Enable = 'off';
            break
        end
    end
end
end



