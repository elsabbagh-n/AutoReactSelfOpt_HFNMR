function h = intrng_generate(h)
% This function generates the intrng text file to be transfered once the
% dataset folder is created.
if isfield(h,'areaAdditionalList_Num')
    RegionsList = h.areaAdditionalList_Num;
else
    RegionsList = [];
end
RegionsList = [RegionsList;h.area.AreaRegion;h.area.AreaRegion2];
[~,ind] = sort(RegionsList(:,2),'descend');
RegionsList = RegionsList(ind,:);
h.ind_target = find(h.area.AreaRegion==RegionsList,1);
h.ind_reference = find(h.area.AreaRegion2==RegionsList,1);
h.intrng = ['A 1 #regions in PPM\n','# low_field   high_field   bias   slope'];
for i = 1:size(RegionsList,1)
    h.intrng = [h.intrng,'\n',num2str(RegionsList(i,2)),'      ',...
        num2str(RegionsList(i,1)),'   0   0 # for region ',num2str(i)];
end
h.intrng = [h.intrng,'\n'];
fId = fopen('C:\Users\Ceisam_Mimm\Documents\MATLAB\CurrentHFNMROptFolder\High Field Control\intrng0','w');
fprintf(fId, h.intrng);
fclose(fId);
end