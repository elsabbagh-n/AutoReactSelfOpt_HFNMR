function transfer_to_spectro500(filePath,fileName,desiredPath,desiredName)
% This function transfer files from this PC to a remonte PC. Hostname,
% Username and Password are set to the those of Spectro500.
%
% Input
% filePath      Path of the file to be uploaded to the remote PC
% fileName      Name of the file to be uploaded to the remote PC
% desiredPath   Path to which the file will be uploaded on the remote PC
% desiredName   New name of the transferred file on the remote PC


% Example :
% filePath = 'C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\Post_Doc_codes';
% fileName = 'extset01.txt';
% desiredPath = '/opt/topspin3.6.2/prog/tmp/';
% desiredPath = '/home/nmr/Documents/Nour/yy';
% desiredName = 'extset.txt';

%% User Input

% Required information about the remote PC (spectro 500MHz)
Hostname = '172.16.77.57';
Hostname = 'RMN500-1525.ceisam.sciences.univ-nantes.prive';
Username = 'nmr';
Password = 'topspin';


%% File Upload

if isfile(fullfile(filePath,fileName))
    try
        ssh2_struct_upload = scp_simple_put(Hostname, Username, Password,...
            fileName, desiredPath, filePath, desiredName);
        % close connection when done
        ssh2_struct_upload = ssh2_close(ssh2_struct_upload); %#ok<NASGU>
        clc
        fprintf('\nTransfer done successfully.\n')
    catch EX
        fprintf(EX.message)
        fprintf('\nBUT .... Continuing anyway? \n')
        opts.Interpreter = 'tex';
        opts.Default = 'Yes';
        quest = {'The above error occuried.','Continue anyway ?'};
        answer0 = questdlg(quest,'Error',...
            'Yes','No',opts);
        switch answer0
            case 'Yes'
                fprintf('\nContinue after this detected error !!\n')
            case 'No'
                % running the commands again. Codes stopping if error
                ssh2_struct_upload = scp_simple_put(Hostname, Username, Password,...
                    fileName, desiredPath, filePath, desiredName);
                % close connection when done
                ssh2_struct_upload = ssh2_close(ssh2_struct_upload); %#ok<NASGU>
                clc
                fprintf('\nTransfer done successfully.\n')
        end
    end
else
    clc
    fprintf('\nTransfer failed.\n')
end


end