


%%
close all
clearvars
clc
% File path of this script
pathname = 'C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\Post_Doc_codes\Automation User Interface v5';
addpath(genpath(pathname))
cd(pathname)
% File path of the SCP functions
addpath(genpath('C:\Users\elsabbagh-n\Documents\MATLAB\Freedman_ssh'))
% Varagins
% clc,varargin = {};nargin = 0;
% clc,varargin = {'C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\Post_Doc_codes\Automation User Interface v5\autoModeHandles.mat',0};nargin = 2;
% clc,varargin = {'C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\Post_Doc_codes\Automation User Interface v5\autoModeHandles.mat',0,[3 4],[2 3],'last'};nargin = 5;
% clc,varargin = {'C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\Post_Doc_codes\Automation User Interface v5\autoModeHandles.mat',0,[3 4],'last',[2 3]};nargin = 5;
% clc,varargin = {'list'};
%%
close all;clearvars;clc
load('testingToMax01.mat')
h.status.uit.Data =h.status.table;
drawnow
%%
x = datetime(cell2mat(h.status.table.Completed),'Format','HH:mm:ss');
y = double(cell2mat(h.status.table.Area));
x = x-x(1);
dy = diff(y);dy = dy/max(dy);
ind_max_dy = find(max(dy)==dy);
prctg = 0.2;
ind_threshhold_dy = ind_max_dy -1 + find(dy(ind_max_dy:end)<=prctg,1);
figure
yyaxis left
plot(x,y,'-o','DisplayName','y')
yyaxis right
hold on
plot(x(2:end),dy,'-o','DisplayName','dy')
yline(0.2,'HandleVisibility','off')
xline(x(ind_threshhold_dy+1),'HandleVisibility','off')
legend('Location','best')
%%
indmaxold = 1;
indmaxnew = 0;
count2max = 1;
figure('Position',[4.3333 270.3333 314 288])
yyaxis left
p1 = plot(0,'-o','DisplayName','y');
ylabel('Area')
yyaxis right
p2 = plot(0,'-o','DisplayName','dy');
yline(0.2,':','HandleVisibility','off')
ylabel('\partialArea normalized')
xlabel('Exp n°')
legend('Location','best')

for i = 1:length(y)
    pause(1)
    Y = y(1:i);
    yyaxis left
    p1.YData = Y;p1.XData = 1:length(Y);
    ylim([min(0,min(Y)) max(Y)+2])
    dY = diff(Y);dY = dY/max(dY);
    indmaxnew = find(dY==max(dY),1);
    if isempty(indmaxnew)
        continue
    else
        yyaxis right
        p2.YData = dY;p2.XData = 2:length(dY)+1;
    end
    legend('Location','best')
    if indmaxnew==1
        continue
    end
    % Zigzag effect
    if length(Y)>=3
        last3_Y = Y(end-2:end);
        [~,indx] = sort(last3_Y,'ascend');
        if ~isequal(indx',[1 2 3])
            % ZigZag effect detected
            continue
        end
    else
        continue
    end
    if isequal(indmaxnew,indmaxold)
        count2max = count2max+1;
    else
        indmaxold = indmaxnew;
        count2max = 0;
    end
    if dY(end)<=0.2
        break
    end
end

%%
dY = diff(Y);dY = dY/max(dY);
ind_max_dY = find(max(dY)==dY);
prctg = 0.2;
find(dy(ind_max_dY:end)<=prctg,1)
ind_threshhold_dY = ind_max_dY -1 + find(dy(ind_max_dY:end)<=prctg,1);



%%
clc
clearvars
close all
% ExtSet_GUI_function;return
% savedHandlepath = ExtSet_GUI_function('list');
[Area,Region] = ExtSet_GUI_function;return
% if isempty(Area) && isempty(Region)
%     return
% end
% return
savedHandlepath = ['C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\'...
    'Post_Doc_codes\Automation User Interface v5\autoModeHandles.mat'];
% [Area,Region] = ExtSet_GUI_function(savedHandlepath,0);
% [Area,Region] = ExtSet_GUI_function(savedHandlepath,1);%[2.5,3]
% [Area,Region] = ExtSet_GUI_function(savedHandlepath,1,[1.9 4]);%,'last'
        
%%

savedHandlepath = ['C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\'...
    'Post_Doc_codes\Automation User Interface v5\autoModeHandles.mat'];


load(savedHandlepath,'autoModeHandles')
nbOfExpPerIter = size(autoModeHandles.Table,1)-1;
% nbMaxOfIter = fix(7/nbOfExpPerIter);
nbMaxOfIter = 3;

if size(get(groot,'MonitorPositions'),1)==1
    % 1 screen
    f1 = figure;
else
    % 2 screens
    f1 = figure('position',[-1560 144 560 420]);
end

hold on
ylim('auto')
xlim('manual')
xlim([0 nbMaxOfIter*nbOfExpPerIter+1])
ylabel('Area value')
xlabel('Exp n°')

%%
switchL = 0;
L = {'-','--',':','-.'};
C = {[0 0.4470 0.7410],[0.8500 0.3250 0.0980],[0.9290 0.6940 0.1250],[0.4940 0.1840 0.5560],[0.4660 0.6740 0.1880]};
next = 1;
for i = 1:nbMaxOfIter
    fprintf('\n Pause before clearing the window.\n')
    pause(10)
    clc
    if i==1
        [Area,Region] = ExtSet_GUI_function(savedHandlepath,0);
        % nargin = 2;varargin = {'C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\Post_Doc_codes\Automation User Interface v5\autoModeHandles.mat',0};
    elseif i==nbMaxOfIter
        [Area,Region] = ExtSet_GUI_function(savedHandlepath,1,[1.9 4],'last');
        % varargin = {'C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\Post_Doc_codes\Automation User Interface v5\autoModeHandles.mat',1,'last'};
    else
        [Area,Region] = ExtSet_GUI_function(savedHandlepath,1);%[2.5,3]
        % varargin = {'C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\Post_Doc_codes\Automation User Interface v5\autoModeHandles.mat',1};
    end
    if isempty(Area) && isempty(Region)
        return
    end
    drawnow
    if size(Area,1)<=nbOfExpPerIter
        %     x = double(cell2mat(Area.ExpNo(1+(i-1)*nbOfExpPerIter:i*nbOfExpPerIter)));
        %     y = double(cell2mat(Area.Area(1+(i-1)*nbOfExpPerIter:i*nbOfExpPerIter)));
        x = double(cell2mat(Area.ExpNo));
        y = double(cell2mat(Area.Area));
        figure(f1)
        plot(x,y,L{next},'Color',C{next},'Marker','.','MarkerSize',25,'DisplayName',['[ ' num2str(round(Region(1)),1) ' , ' num2str(round(Region(2)),1) ' ] ppm']);
        drawnow
    else
        if next==4
            next = 1;
        else
            next = next+1;
        end
        for j = 1:size(Area,1)/nbOfExpPerIter
            x = double(cell2mat(Area.ExpNo(1+(j-1)*nbOfExpPerIter:j*nbOfExpPerIter)));
            y = double(cell2mat(Area.Area(1+(j-1)*nbOfExpPerIter:j*nbOfExpPerIter)));
            figure(f1)
            plot(x,y,L{next},'Color',C{next},'Marker','.','MarkerSize',25,'DisplayName',['[ ' num2str(round(Region(1)),1) ' , ' num2str(round(Region(2)),1) ' ] ppm']);
            drawnow
        end
    end
    label{i} = ['Iteration °' num2str(i)]; %#ok<SAGROW>
end

%%
figure(f1)
ylim0 = ylim;
ylim([min(ylim0(1),0) ylim0(2)])
legend(legendUnq(f1))

xline(nbOfExpPerIter*((1:nbMaxOfIter)-1)+0.5,':',label,'HandleVisibility','off')


pause(2)
ExtSet_GUI_function('stop');

%%



