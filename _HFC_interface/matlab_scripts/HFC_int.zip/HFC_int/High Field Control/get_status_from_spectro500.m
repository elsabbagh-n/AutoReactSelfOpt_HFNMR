function Name = get_status_from_spectro500(statusPath,fileName,desiredPath,first)
% This function transfer files from a remonte PC to this PC. Hostname,
% Username and Password are set to the those of Spectro500. It transfers
% file of the selected folder, and files from its subfolders indicated. If
% the transfer is done successfully, it returns a value 1; if there were no
% transfer or the folderName didn't exist, it returns a nil value.
%
% Input
% statusPath      Path of the file to be downloaded from the remote PC
% fileName      Name of the file to be downloaded from the remote PC
% desiredPath   Path to which the file will be download on this PC

%% User Input

% Required information about the remote PC (spectro 500MHz)
% Hostname = '172.16.77.57';
Hostname = 'RMN500-1525.ceisam.sciences.univ-nantes.prive';
Username = 'nmr';
Password = 'topspin';


%% File Upload
if first
    command = ['cd ' statusPath ' ; ls'];
    command_output = ssh2_simple_command(Hostname, Username, Password,command);
    s = startsWith(command_output,fileName);
    if length(find(s))>1
        command_output = command_output(s);
        clearvars t tm
        for i = 1:length(find(s))
            t(i) = textscan(command_output{i},[fileName '-%[^-]-%*s.set']); %#ok<AGROW>
            tm(i) = str2double(t{i}{1}); %#ok<AGROW>
        end
        ind = find(tm==max(tm));
        if length(ind)>1
            thisOneIsShorter = ind(1);
            for i = ind(2:end)
                if length(command_output{i-1})>length(command_output{i})
                    thisOneIsShorter = i;
                end
            end
        else
            thisOneIsShorter = ind;
        end
        fileName = command_output{thisOneIsShorter};
    else
        fileName = command_output{s};
    end
    err = 1;
    while(err)
        try
            % get the status file of the experiment
            ssh2_conn = scp_simple_get(Hostname, Username, Password,fileName,desiredPath,statusPath);
            ssh2_close(ssh2_conn); %close connection when done
        catch EX
            fprintf(EX.message)
            fprintf('\nBUT .... Repeat .... \n')
            continue
        end
        err = 0;
    end
else
    d = dir(desiredPath);
    s = startsWith({d.name},fileName);
    fileName = d(s).name;
    err = 1;
    while(err)
        try
            % get the status file of the experiment
            ssh2_conn = scp_simple_get(Hostname, Username, Password,fileName,desiredPath,statusPath);
            ssh2_close(ssh2_conn); %close connection when done
        catch EX
            fprintf(EX.message)
            fprintf('\nBUT .... Repeat .... \n')
            continue
        end
        err = 0;
    end
end
Name = fileName;
end






