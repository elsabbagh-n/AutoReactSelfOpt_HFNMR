function h = param_remove(h)
% This function removes the value inserted in the selected line in the
% list box of the Parameters Input (Optional) Panel.

if ~isempty(h.list_box(1).String)
    text_ParametersInput2 = split(h.list_box(1).String,' = ');
    [~,a] = ismember(text_ParametersInput2(h.list_box(1).Value,1),...
        h.Fixed_Parameter(:,1));
    h.Fixed_Parameter(a,2) = {[]};
    l2 = h.Fixed_Parameter;
    emptyCells2 = cellfun(@isempty,h.Fixed_Parameter(:,2));
    full_p2 = find(~emptyCells2);
    text_ParametersInput2 = cell(1,length(full_p2));
    for i2 = 1:length(full_p2)
        text_ParametersInput2(1,i2) = {[l2{full_p2(i2),1},' = ',...
            num2str(l2{full_p2(i2),2})]};
    end
    if h.list_box(1).Value~=1
        h.list_box(1).Value = h.list_box(1).Value-1;
    end
    h.list_box(1).String = text_ParametersInput2;
    h.editable_text_field(end).String = '';
end
% h = tag_update(h);
end
