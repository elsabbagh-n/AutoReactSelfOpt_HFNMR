function DONE = wait4TopspinExecution(cmd,t)
% This function waits for TOPSPIN to execute cmd line. It searches for it
% in the history log. Hostname, Username and Password are set to the those
% of Spectro500.
%
% No file transfer !
%
% Input
% cmd                Command line for TOPSPIN
% t                  0 to search the starting of the command, 1 to search
%                    for its termination and 2 for both
% Output
% DONE               1 if cmd executed, 0 if the launch or the termination
%                    not executed
% cmd = 'atma';t = 2;

%% Make sure that the corresponding cmd is valid
if isempty(cmd)
    return
end
if isempty(t)
    t = 2; % search for start and termination by default
end

%% Get the content of the history file

% nmr history file path on remote PC
hist_path = '/opt/topspin3.6.2/prog/curdir/nmr/';
hist_filename = 'history';
% nmr history file path on this PC
desiredPath = 'C:\Users\elsabbagh-n\Documents\DataSet\history\';
% no file transfer
hist_lines_orig = get_history_from_spectro500(hist_filename,hist_path,...
    desiredPath,1);
% hist_lines_orig = regexp(fileread('C:\Bruker\TopSpin4.0.7\prog\curdir\elsabbagh-n\history'),'\n','split')'; % on this PC
%% Separate lines according to dates

TopSpin_date = find(contains(hist_lines_orig,'+0200    JD'));
if isempty(TopSpin_date)
    pat = '+0' + digitsPattern(1) + '00    JD';
    TopSpin_date = find(contains(hist_lines_orig,pat));
end
% Last date fixed
hist_date_ind = length(TopSpin_date);
% Index of lines of a specific date
TopSpin_date1 = TopSpin_date(hist_date_ind);
if hist_date_ind==length(TopSpin_date)
    TopSpin_date2 = length(hist_lines_orig);
else
    TopSpin_date2 = TopSpin_date(hist_date_ind+1);
end
% History text lines from a specific date X
hist_lines_dateX = hist_lines_orig(TopSpin_date1:TopSpin_date2);

%% Search for cmd launch on TOPSPIN

% Specifying the starting command corresponding to cmd
if contains(cmd,'lock ')
    cmd0 = insertAfter(cmd,'lock','n');
else
    cmd0 = cmd;
end
if t~=1
    whichlineStart = find(contains(hist_lines_dateX,['cmd enter: ' cmd0]));
    if isempty(whichlineStart)
        startcmd = 0;
    else
        whichlineStart = whichlineStart(end); % latest command
        % verification
        whichlineStartV = find(contains(hist_lines_dateX(whichlineStart:end),'cmd sent: '),1);
        whichlineStartV2 = find(contains(hist_lines_dateX(whichlineStart:end),'cmd(o) sent: '),1);
        if isempty(whichlineStartV)
            if isempty(whichlineStartV2)
                startcmd = 0;
            else
                if whichlineStartV2==2 || whichlineStartV2==3
                    startcmd = 1;
                else
                    startcmd = 0;
                end
            end
        else
            if whichlineStartV==2 || whichlineStartV==3
                startcmd = 1;
            else
                startcmd = 0;
            end
        end
    end
end

%% Search for cmd termination on TOPSPIN

% Specifying the termination command corresponding to cmd
if contains(cmd,'lock ')
    cmd0 = 'term: lockn;';
elseif contains(cmd,'topshim ')
    cmd0 = 'term: topshim;';
elseif contains(cmd,'dosy ')
    cmd0 = 'sent: checklockshift final';
else    
    cmd0 = ['term: ' cmd];
end
if t~=0
    whichlineTerm = find(contains(hist_lines_dateX(whichlineStart:end),['cmd ' cmd0]),1);
    if isempty(whichlineTerm)
        termcmd = 0;
    else
        termcmd = 1;
    end
end

%% Output

DONE = 0;
if t==0 %search for cmd launch only
    if startcmd
        DONE = 1;
    end
elseif t==1 %search for cmd termination only
    if termcmd
        DONE = 1;
    end
elseif t==2 %search for cmd launch and termination
    if startcmd && termcmd
        DONE = 1;
    end
end

end




