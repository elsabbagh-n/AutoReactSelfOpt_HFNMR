function Sh = readShim(datasetPath,filename)
% This function reads the shimming values saved during an experiment on
% TopSpin.
%
% Input
%   datasetPath     Path of the experiment folder on this PC
%   filename        Name of the shim file, 'shimvalues' by default
% Output
%   Sh              Structure containing all shim values

%% Make sure the folder exists
% Check if the main dataset folder exists
filename = fullfile(datasetPath,filename);
if exist(filename, 'file')==2
    fileContent = regexp(fileread(filename),'\n','split')';
    
    % Active Shim Gradients
    whichline1 = find(contains(fileContent,'Active Shim Gradients'));
    whichline2 = find(contains(fileContent,'Lock Parameter'));
    out = join(fileContent(whichline1+2:whichline2-2)); % only take a look at lines in between "Active Shim Gradients" and "Lock Parameter"
    out = textscan(out{1},'%s %f'); % general template across the lines : [ string(%s) float(%f)]
    for i = 1:length(out{1})
        fld = out{1}{i};
        fld = replace(fld,'-','_');
        fld = replace(fld,'(','p_');
        fld = replace(fld,')','_p');
        val = out{2}(i);
        eval(['Shim.' fld ' = ' num2str(val) ';'])
    end
    
    % Active Shim Gradients
    whichline1 = find(contains(fileContent,'Lock Parameter'));
    whichline2 = find(contains(fileContent,'IEEE64_VERSION_CODE'));
    out = join(fileContent(whichline1+2:whichline2-2)); % only take a look at lines in between "Lock Parameter" and "IEEE64_VERSION_CODE"
    out = textscan(out{1},'%s %f'); % general template across the lines : [ string(%s) float(%f)]
    for i = 1:length(out{1})
        fld = out{1}{i};
        fld = replace(fld,'-','_');
        fld = replace(fld,'(','p_');
        fld = replace(fld,')','_p');
        val = out{2}(i);
        eval(['Shim.' fld ' = ' num2str(val) ';'])
    end
    
    % Active Shim Gradients
    whichline1 = find(contains(fileContent,'Shim currents'));
    out = join(fileContent(whichline1+2:end)); % only take a look at lines after "Shim currents"
    out = textscan(out{1},'%s [%d] %f'); % general template across the lines : [ string(%s) [double(%d)] float(%f)]
    for i = 1:length(out{1})
        fld = [out{1}{i} '_' num2str(out{2}(i))];
        fld = replace(fld,'-','_');
        fld = replace(fld,'(','p_');
        fld = replace(fld,')','_p');
        val = out{3}(i);
        eval(['Shim.' fld ' = ' num2str(val) ';'])
    end
    
    % Date
    out = fileContent(1); % only take the first line
    out = textscan(out{1},'# %*s %s');
    ind = regexp(fileContent(1),out{1});
    out = fileContent{1}(ind{1}:end);
    Shim.DateTime = datetime(out,'Format','MMM dd HH:mm:ss uuuu');
    Shim.DateTime.Format = 'dd/MM/uuuu HH:mm:ss';
    
    % Shim ID
    whichline1 = find(contains(fileContent,'SHIMID'),1);
    out = fileContent(whichline1); % only take this line
    out = textscan(out{1},'#$$SHIMID=%f');
    Shim.ID = out{1};
    
    Sh = Shim;
    
else
    error('File does not exist !')
end





