function exp_in_status = check_if_exp_added_to_status_file_spectro500(FileName,statusPath,...
    expList,waitCheck,varargin)
% This function checks if the request experiment list is added to the
% status file (exp_in_status_updated=1) by IconNMR or not
% (exp_in_status_updated=0). Hostname, Username and Password are set to the
% those of Spectro500.
%
% No file transfer ! if status file transfer is desired, use function
% called "track_exp.m" instead.
%
% Input
% FileName                Name of the file to be checked
% statusPath              Path of the file to be downloaded from the remote PC
% expList                 List of experiments to be checked
% waitCheck               =1 to wait until updated, =0 check once
% Output
% exp_in_status           =1 if expList was added in the status file or =0 not

% FileName = h.fileName;
% statusPath = '/opt/topspin3.6.2/prog/curdir/changer';
% expList = h.Experiment_Table.ExpNo(2:end);
% waitCheck = 1;
%% User Input

% Required information about the remote PC (spectro 500MHz)
Hostname = '172.16.77.57';
Hostname = 'RMN500-1525.ceisam.sciences.univ-nantes.prive';
Username = 'nmr';
Password = 'topspin';

%% Evaluate the input argument
tic
if waitCheck==1 && length(varargin)>=1
    iteration_time = varargin{1};
    printText = varargin{2};
end

%% Experiment in status file update check

command = ['cd ' statusPath '; cat ' FileName ' ;'];
command_output = ssh2_simple_command(Hostname, Username, Password,command);
whichlines = find(contains(command_output,'##Holder##'));
nbExpFound = length(whichlines);
ExpInStatusFound = double.empty(nbExpFound,0);
for i = 1:nbExpFound
    ExpInStatusFound(i,1) = cell2mat(textscan(command_output{whichlines(i)},...
        '##Holder## %*f %*s %*s %f'));
end
exp_in_status = ismember(expList,ExpInStatusFound);
if sum(exp_in_status)~=length(expList)
    % Not all experiment were added
    if waitCheck~=0
        % Check until all desired experiment were added
        if length(varargin)>=1
            iteration_time = iteration_time + toc;
        else
            iteration_time = 0;
        end
        if iteration_time>5
            if iteration_time>20
                warning('\nThis is the last check!\n')
                exp_in_status = check_if_exp_added_to_status_file_spectro500(FileName,statusPath,...
                    expList,0);
            else
                if printText==1
                    warning('\nStatus file updating by IconNMR is taking too long!\n')
                end
                exp_in_status = check_if_exp_added_to_status_file_spectro500(FileName,statusPath,...
                    expList,1,iteration_time,0);
            end
        else
            exp_in_status = check_if_exp_added_to_status_file_spectro500(FileName,statusPath,...
                expList,1,iteration_time,1);
        end
    end
end
end


