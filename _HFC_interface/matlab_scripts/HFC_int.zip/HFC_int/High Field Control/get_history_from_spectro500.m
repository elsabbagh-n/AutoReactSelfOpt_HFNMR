function command_output = get_history_from_spectro500...
    (hist_filename,hist_path,desiredPath,quickCheck)
% This function transfer files from a remonte PC to this PC. Hostname,
% Username and Password are set to the those of Spectro500. It transfers
% file of the selected folder, and files from its subfolders indicated. If
% the transfer is done successfully, it returns a value 1; if there were no
% transfer or the folderName didn't exist, it returns a nil value.
%
% Input
% hist_filename  File name to be downloaded from the remote PC
% hist_path      Path of the file to be downloaded from the remote PC
% desiredPath    Path to which the file will be download on this PC
% quickCheck     =0 for transferred, =1 for checking the content
%% User Input

% Required information about the remote PC (spectro 500MHz)
Hostname = '172.16.77.57';
Hostname = 'RMN500-1525.ceisam.sciences.univ-nantes.prive';
Username = 'nmr';
Password = 'topspin';


%% Folder Upload
if quickCheck==0
% get the status file of the experiment
ssh2_conn = scp_simple_get(Hostname, Username, Password,hist_filename,desiredPath,hist_path);
ssh2_close(ssh2_conn); %close connection when done
else
%% No transfer check
command = ['cd ' hist_path ' ;cat history ;'];
command_output = ssh2_simple_command(Hostname, Username, Password,command);
end
end






