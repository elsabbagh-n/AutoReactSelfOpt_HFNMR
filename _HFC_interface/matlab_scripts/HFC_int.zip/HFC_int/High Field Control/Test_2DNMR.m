%% Initiation

close all force
clearvars
clc
cd('C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\Post_Doc_codes\Automation User Interface v5')

% Nb of 2D experiments to run
% Nb_2D = 1;
% % NMR experiment handles paths
% P_1D_short_long = ['C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\Post_Doc_codes\'...
%     'Automation User Interface v5\autoModeHandles_1H_fast_long.mat'];
% P_2D = ['C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\Post_Doc_codes\'...
%     'Automation User Interface v5\autoModeHandles_2D_test.mat'];
% P_D30_Opt = ['C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\Post_Doc_codes\'...
%     'Automation User Interface v5\autoModeHandles_2D_D30_Opt.mat'];
P_YH = ['C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\Post_Doc_codes\'...
    'Automation User Interface v5\autoModeHandles_YH.mat'];
%% Conitunous experiment request - YH

% Preparing handles
if ~exist('P_YH','var')
    P_YH = ExtSet_GUI_function('list');
else
    if ~exist(P_YH,'file')
        P_YH = ExtSet_GUI_function('list');
    end
end
load('Tables_YH.mat','Table3','Param')
% save('Tables_YH.mat','Table0','Table1','Table2','Table3','Param')
load(P_YH);
% Table3 = autoModeHandles.Table;
% Param = autoModeHandles.Table.Parameters;
autoModeHandles.Table = Table3;
autoModeHandles.archive = [];
save(P_YH,'autoModeHandles');
clearvars autoModeHandles ans
[ExpN,~,~,ExpDurations,UncompleteExp] = ExtSet_GUI_function(P_YH,0,'exprequest');
drawnow
%%
NewD30 = "D30,0.0012";
load(P_YH);
autoModeHandles.Table.Parameters(3) = NewD30;
autoModeHandles.Table.Parameters(5) = NewD30;
autoModeHandles.Table.Parameters(7) = NewD30;
autoModeHandles.Table.Parameters(9) = NewD30;
autoModeHandles.Table.Parameters(11) = NewD30;
save(P_YH,'autoModeHandles');
clearvars autoModeHandles ans

%%
go = 1;cnt = 2;
while(go)
    if cnt==1
        [ExpN,~,~,ExpDurations,UncompleteExp] = ExtSet_GUI_function(P_YH,0,'exprequest');
    else
        [ExpN,~,~,ExpDurations,UncompleteExp] = ExtSet_GUI_function(P_YH,1,'exprequest');
    end
    cnt = cnt+1;
    clc
    D = sum(ExpDurations(UncompleteExp));
    N = datetime('now','Format','dd/MM/yyyy HH:mm:ss');
    BusyUntil = N+D;
    fprintf(['\nIf started ' char(N) '\nBusy until ' char(BusyUntil)...
        '\n' num2str(length(ExpDurations)) ' experiments running for ' char(D) '\n'])
    drawnow;
    go = check_user_for_new_experiments(2);

end

return

%% Conitunous experiment request - Prepare handles

% Nb of exp list request
Nb_list = 6;
% Preparing handles
if ~exist('P_1D_short_long','var')
    P_1D_short_long = ExtSet_GUI_function('list');
else
    if ~exist(P_1D_short_long,'file')
        P_1D_short_long = ExtSet_GUI_function('list');
    end
end
load(P_1D_short_long);
% autoModeHandles.archive = [];autoModeHandles.Table.ExpNo(2) = 0;
% autoModeHandles.Table.ExpNo(2) = autoModeHandles.Table.ExpNo(2) +1;
autoModeHandles.fileName = 'Test01-2022-0000-Nour.set';
autoModeHandles.status = [];
autoModeHandles.archive = []; autoModeHandles.Table.ExpNo(2) = 1;autoModeHandles.Table.ExpNo(3) = 2;
autoModeHandles.Table.Name(1:3) = ['NES_' char(datetime('now','Format','yyMMdd'))];
autoModeHandles.Table.Experiment(2:3) = "N - PROTON_Nour";
autoModeHandles.Table.Parameters(2) = "D1,600";
autoModeHandles.Table.Parameters(3) = "D1,1800";
autoModeHandles.area = [3.3027    3.3508];
autoModeHandles.areaRef = [3.7576    3.8306];
save(P_1D_short_long,'autoModeHandles');
clearvars autoModeHandles ans
cnt = 1;
E = datetime('18/01/2024 18:00:00','Format','dd/MM/yyyy HH:mm:ss');
still = 1;

%% Conitunous experiment request - Run Experiments

% while(still)
for cnt = 1:10
    if cnt==1
        [ExpN,~,~,ExpDurations,UncompleteExp] = ExtSet_GUI_function(P_1D_short_long,0,'exprequest');
    else
        load(P_1D_short_long);
        %autoModeHandles.archive = [autoModeHandles.archive;ExpN];
        save(P_1D_short_long,'autoModeHandles');
        [ExpN,~,~,ExpDurations,UncompleteExp] = ExtSet_GUI_function(P_1D_short_long,1,'exprequest');
    end
%     cnt = cnt+1;
    clc
    D = sum(ExpDurations(UncompleteExp));
    N = datetime('now','Format','dd/MM/yyyy HH:mm:ss');
    BusyUntil = N+D;
    fprintf(['\nIf started ' char(N) '\nBusy until ' char(BusyUntil)...
        '\n' num2str(length(ExpDurations)) ' experiments running for ' char(D) '\n'])
    if (E-BusyUntil)<0*seconds
        still = 0;
    end
    drawnow;pause(0.5)
end
return

%% Test 1D 1H long short experiments

% Preparing handles
if ~exist('P_1D_short_long','var')
    P_1D_short_long = ExtSet_GUI_function('list');
else
    if ~exist(P_1D_short_long,'file')
        P_1D_short_long = ExtSet_GUI_function('list');
    end
end
load(P_1D_short_long);
% autoModeHandles.archive = [];autoModeHandles.Table.ExpNo(2) = 0;
% autoModeHandles.Table.ExpNo(2) = autoModeHandles.Table.ExpNo(2) +1;
autoModeHandles.archive = []; autoModeHandles.Table.ExpNo(2) = 1;autoModeHandles.Table.ExpNo(3) = 2;
autoModeHandles.Table.Name(2) = ['NES_' char(datetime('now','Format','yyMMdd'))];
autoModeHandles.Table.Name(3) = ['NES_' char(datetime('now','Format','yyMMdd'))];
autoModeHandles.Table.Experiment(2) = "N - PROTON_Nour";
autoModeHandles.Table.Experiment(3) = "N - PROTON_Nour";
autoModeHandles.Table.Parameters(2) = "D1,3";
autoModeHandles.Table.Parameters(3) = "D1,15";
autoModeHandles.area = [3.3027    3.3508];
autoModeHandles.areaRef = [3.7576    3.8306];
save(P_1D_short_long,'autoModeHandles');
clearvars autoModeHandles ans
cnt = 1;

if cnt==1
    [~,~,pathLatestExp] = ExtSet_GUI_function(P_1D_short_long,0,'exprequest');
else
    [~,~,pathLatestExp] = ExtSet_GUI_function(P_1D_short_long,1,'exprequest');
end
return

%% Semi-Auto D30 optimization

D30_search = [0.0005 0.001];
D30_try = 0.0009;
D30_Exploration = [];

% Preparing handles
if ~exist('P_D30_Opt','var')
    P_D30_Opt = ExtSet_GUI_function('list');
else
    if ~exist(P_D30_Opt,'file')
        P_D30_Opt = ExtSet_GUI_function('list');
    end
end

load(P_D30_Opt);
% autoModeHandles.archive = [];autoModeHandles.Table.ExpNo(2) = 0;
% autoModeHandles.Table.ExpNo(2) = autoModeHandles.Table.ExpNo(2) +1;
autoModeHandles.archive = []; autoModeHandles.Table.ExpNo(2) = 1;
autoModeHandles.Table.Name(2) = ['NES_' char(datetime('now','Format','yyMMdd')) '_2D_D30'];
autoModeHandles.Table.Experiment(2) = "N - ONESHOTDSTE_YH_NES_D30";
autoModeHandles.Table.Parameters(2) = string(['D30,' num2str(D30_try)]);
autoModeHandles.area = [3.3027    3.3508];
autoModeHandles.areaRef = [3.7576    3.8306];
save(P_D30_Opt,'autoModeHandles');
clearvars autoModeHandles ans
cnt = 1;
D30_optimized = 0;

while (D30_optimized==0)
    % Running Nb 2D NMR experiment(s)
    if cnt==1
        [~,~,pathLatestExp] = ExtSet_GUI_function(P_D30_Opt,0);
    else
        [~,~,pathLatestExp] = ExtSet_GUI_function(P_D30_Opt,1);
    end
    
    % Read the dataset acquired
    [FileName,ExpNum] = fileparts(pathLatestExp);
    [filePath,folderName] = fileparts(FileName);
    filePath = [filePath '/']; %#ok<AGROW>
    cmd = ['re ' folderName ' ' ExpNum ' 1 ' filePath];
    sendCommand2Topspin(cmd,0);pause(0.5)
    
    % Do dosy experiment with only 2 incriments
    cmd = 'dosy 10 90 2 l y';
    sendCommand2Topspin(cmd,1)
    cmd = 'xaup';
    sendCommand2Topspin(cmd,0);pause(0.5)
    
    % Read the 1st increment
    cmd = 'rsr 1 11';
    sendCommand2Topspin(cmd,0);pause(0.5)
    cmd = 'apk';
    sendCommand2Topspin(cmd,0);pause(0.5)
    cmd = 'apk0';
    sendCommand2Topspin(cmd,0);pause(0.5)
    
    cmd = ['re ' folderName ' ' ExpNum ' 1 ' filePath];
    sendCommand2Topspin(cmd,0);pause(0.5)
    cmd = 'rsr 2 12';
    sendCommand2Topspin(cmd,0);pause(0.5)
    cmd = 'apk';
    sendCommand2Topspin(cmd,0);pause(0.5)
    cmd = 'apk0';
    sendCommand2Topspin(cmd,0);pause(0.5)
    
    % Transfer data
    desiredPath = 'C:\Users\elsabbagh-n\Documents\DataSet\';
    Tr = transfer_folder_from_spectro500([filePath folderName '/'],num2str(ExpNum),...
        [desiredPath folderName '\' num2str(ExpNum) '\']);
    
    % Compare the two acquired incriments according to a specific region of the
    % spectrum
    Reg = [7.2 7.34];
    A = rbnmr([desiredPath folderName '\' num2str(ExpNum) '\'],1);
    
    p1.XData = A{2}.XAxis;
    p1.YData = A{2}.Data;
    p2.XData = A{3}.XAxis;
    p2.YData = A{3}.Data;
    
    ind1 = p1.XData>=Reg(1);
    ind2 = p1.XData<=Reg(2);
    ind = (ind1+ind2)==2;
    fct = max(p2.YData(ind))./max(p1.YData(ind))*100;

    D30_Exploration(cnt,1:3) = [str2double(ExpNum) D30_try*1000 fct]; %#ok<SAGROW>
    pause(1)

    if fct>=4.4 && fct<=10
        D30_optimized = 1;
        ExtSet_GUI_function('stop');
    else
        % prepare for next experiment
        load(P_D30_Opt);
        % autoModeHandles.Table.ExpNo(2) = autoModeHandles.Table.ExpNo(2) +1;
        if fct<4.4
            D30_try = D30_try-0.00005;
            autoModeHandles.Table.Parameters(2) = string(['D30,' num2str(D30_try)]);
        elseif fct>10
            D30_try = D30_try+0.00005;
            autoModeHandles.Table.Parameters(2) = string(['D30,' num2str(D30_try)]);
        end
        save(P_D30_Opt,'autoModeHandles');
        clearvars autoModeHandles ans
        cnt = cnt+1;
    end
    disp(D30_Exploration)
    pause(1)
end

%% Preparing handles for 2D data acquisition

if ~exist('P_2D','var')
    P_2D = ExtSet_GUI_function('list');
else
    if ~exist(P_2D,'file')
        P_2D = ExtSet_GUI_function('list');
    end
end
load(P_2D);
% autoModeHandles.archive = [];autoModeHandles.Table.ExpNo(2) = 0;
% autoModeHandles.Table.ExpNo(2) = autoModeHandles.Table.ExpNo(2) +1;
autoModeHandles.archive = []; autoModeHandles.Table.ExpNo(2) = 1;
autoModeHandles.Table.Name(2) = ['NES_' char(datetime('now','Format','yyMMdd')) '_2D'];
autoModeHandles.area = [3.3027    3.3508];
autoModeHandles.areaRef = [3.7576    3.8306];
save(P_2D,'autoModeHandles');
clearvars autoModeHandles ans

%% Running Nb 2D NMR experiment(s)

Results_pathLatestExp = cell(Nb_2D,1);
Time_ = cell(Nb_2D,1);
tic
for i = 1:Nb_2D
    if i==1 && i~=Nb_2D
        % First run
        [~,~,pathLatestExp] = ExtSet_GUI_function(P_2D,0);
    elseif i==1 && i==Nb_2D
        % First and last run
        [~,~,pathLatestExp] = ExtSet_GUI_function(P_2D,0,'last');
    elseif i==Nb_2D
        % Last run
        [~,~,pathLatestExp] = ExtSet_GUI_function(P_2D,1,'last');
    else
        % in between run
        [~,~,pathLatestExp] = ExtSet_GUI_function(P_2D,1);
    end
    Time_{i,1} = toc/60;
    Results_pathLatestExp{i,1} = pathLatestExp;
end

%% Transfer dataset

% close all force
% clearvars
% clc
% Nb = 10;
% fileName = ['NES_' char(datetime('now','Format','yyMMdd')) '_2D'];
% filePath = '/opt/nmrdata/user/nmr/Nour/';

desiredPath = 'C:\Users\elsabbagh-n\Documents\DataSet\';
[FileName,~] = fileparts(Results_pathLatestExp{1,1});
[filePath,folderName] = fileparts(FileName);
filePath = [filePath '/'];
for i = 1:Nb_2D
    Tr = transfer_folder_from_spectro500([filePath folderName '/'],num2str(i),...
        [desiredPath folderName '\' num2str(i) '\']);
end

%% Call GNAT automatically

clc
close all force
clearvars
varargin = [];nargin = 0;

desiredPath = 'C:\Users\elsabbagh-n\Documents\MATLAB\GNAT';
folderName = '230929-YH-BBI-reaction-TBSi-DIPEA-AcOH5-3mm';
addpath(genpath(desiredPath))

GNAT

NES_dir_dataset = [desiredPath '\' folderName];
G = dir(NES_dir_dataset);
I = ismember({'.','..','difflist'},{G.name});
Nb_2D = 2:2:(size(G,1)-length(find(I)));Nb_2D = Nb_2D(end);

% GradCorrectionWorking
int_f = 0.64; %integral factor for the sine shape of the gradient
Gcc = 4.7; %use the calibrattion constant for the appropriate axis (x=4.7 G/mm, y=4.82 G/mm, z=6.3 G/mm)
% Change name
for expnum = 1:Nb_2D
    Filepath1 = [NES_dir_dataset '\'];
    Filepath2 = num2str(expnum);
    Filepathcombined = fullfile([Filepath1,Filepath2]);
    cd(Filepathcombined)
    expno = 1;
    if exist('acqus','file')
        % % Read the contents of the file
        fileContents = fileread("acqus");
        %
        % % Find and replace the specific text
        oldText = '##$PULPROG= <YHdsteosgc_gradX_phycy>';
        newText = '##$PULPROG= <YHdstebpgp_gradX_phycy>';
        fileContents = strrep(fileContents, oldText, newText);
        %
        % % Open the same file for writing
        fileID = fopen('acqus', 'w');
        
        % % Write the modified contents back to the file
        fwrite(fileID, fileContents);
        
        % % Close the file
        fclose(fileID);
    end
    % GradCorrectionWorking
    B = load('C:\Users\elsabbagh-n\Documents\MATLAB\GNAT\230929-YH-BBI-reaction-TBSi-DIPEA-AcOH5-3mm\difflist'); %to load difframp file
    M = B(:,:)*Gcc*10*int_f;
    fileID = fopen('difflist','w');
    fprintf(fileID,'%f\n',B);
    fclose(fileID);
end

[hMainFigure,pMainFigure,nes_msgbox] = GNAT('ABS_Order',2,...
    'ImportData_BrukerArrayProcessed',NES_dir_dataset,...
    'ImportData_BrukerArray_indx',[2,2,Nb_2D],...
    'PARAFAC_Components',2,...
    'PARAFAC_Plots',[1 0 0],...
    'SaveData_Matlab',[NES_dir_dataset '\here.mat'],...
    'SpectralRange_Limits',[7.4 3.2]);

return

%% Call GNAT automatically


close all force
clc
clearvars
ImportData_BrukerArray_indx = [14 2 80];
PARAFAC_Components = 2:5;
ConstMode1 = 0:3;
ConstMode2 = 0:3;
ConstMode3 = 0:3;
ConstMode4 = 0:3;
RefDeconv_LimitsCenter = [6.2 6.05 6.12];
SpectralRange_Limits = [5.8 4.2];%[6.5 4.2];%[6.5 3.5];
addpath(genpath('C:\Users\elsabbagh-n\Documents\MATLAB\GNAT'))
cd('C:\Users\elsabbagh-n\Documents\MATLAB\GNAT\GNAT_13\Import_Export')
% NES_dir_dataset = 'C:\Users\elsabbagh-n\Documents\MATLAB\GNAT\230929-YH-BBI-reaction-TBSi-DIPEA-AcOH5-3mm';
NES_dir_dataset = 'C:\Users\elsabbagh-n\Documents\MATLAB\GNAT\230929-YH-BBI-reaction-TBSi-DIPEA-AcOH5-3mm';

Analysis_Check_Mode1 = zeros(4,4);
Analysis_Check_Mode2 = zeros(4,4);
Analysis_Check_Mode3 = zeros(4,4);
Analysis_Check_Mode4 = zeros(4,4);
i = 1;j=1;k=1;l=1;m=1;
% [hMainFigure,pMainFigure,nes_msgbox] = GNAT('ABS_Order',2,...
%     'ImportData_BrukerArrayProcessed',NES_dir_dataset,...
%     'ImportData_BrukerArray_indx',ImportData_BrukerArray_indx,...
%     'PARAFAC_Components',PARAFAC_Components(i),...
%     'PARAFAC_Plots',[1 0 0],...
%     ...'SaveData_Matlab',[NES_dir_dataset '\here.mat'],...
%     'ReferenceDeconvolution_LimitsCenter',RefDeconv_LimitsCenter,...
%     'ReferenceDeconvolution_LW_Lineshape',2.5,...
%     'ReferenceDeconvolution_Peak',1,...
%     'SpectralRange_Limits',SpectralRange_Limits,...
%     'ConstMode1',ConstMode1(j),...
%     'ConstMode2',ConstMode2(k),...
%     'ConstMode3',ConstMode3(l),...
%     'ConstMode4',ConstMode4(m));

for i = 2%:4
    for j = 2%:3%4
        for k = 1%:4
            for l = 1%:4
                for m = 1%:4
                    clearvars E
                    clc
                    try
                        [hMainFigure,pMainFigure,nes_msgbox] = GNAT('ABS_Order',2,...
                            'ImportData_BrukerArrayProcessed',NES_dir_dataset,...
                            'ImportData_BrukerArray_indx',ImportData_BrukerArray_indx,...
                            'PARAFAC_Components',PARAFAC_Components(i),...
                            'PARAFAC_Plots',[1 0 0],...
                            ...'SaveData_Matlab',[NES_dir_dataset '\here.mat'],...
                            'ReferenceDeconvolution_LimitsCenter',RefDeconv_LimitsCenter,...
                            'ReferenceDeconvolution_LW_Lineshape',2.5,...
                            'ReferenceDeconvolution_Peak',1,...
                            'SpectralRange_Limits',SpectralRange_Limits,...
                            'ConstMode1',ConstMode1(j),...
                            'ConstMode2',ConstMode2(k),...
                            'ConstMode3',ConstMode3(l),...
                            'ConstMode4',ConstMode4(m));
                        return
                        delete(nes_msgbox);clearvars nes_msgbox
                        close(hMainFigure)
                        Analysis_Check_Mode1(i,j) = Analysis_Check_Mode1(i,j)+1;
                        Analysis_Check_Mode2(i,k) = Analysis_Check_Mode2(i,k)+1;
                        Analysis_Check_Mode3(i,l) = Analysis_Check_Mode3(i,l)+1;
                        Analysis_Check_Mode4(i,m) = Analysis_Check_Mode4(i,m)+1;
                    catch E
                        close force
                        close force
                        pMainFigure = figure(...
                            'Color',[0.9 0.9 0.9],...
                            'MenuBar','none',...
                            'Toolbar','Figure',...
                            'NumberTitle','Off',...
                            'Name','Mode 1 - All and Separate components');
                        if size(get(groot,'MonitorPositions'),1)==1
                            % 1 screen
                            pMainFigure.Position = [1 41 1280 607.3333];
                            movegui(gcf,'center');
                        else
                            % 2 screens
                            pMainFigure.Position = [-1919 393 1280 603];
                        end
                        warning(['Error catched for ' num2str(PARAFAC_Components(i))...
                            ' components  Mode1=' num2str(ConstMode1(j)) ...
                            '  Mode2=' num2str(ConstMode2(k)) ...
                            '  Mode3=' num2str(ConstMode3(l)) ...
                            '  Mode4=' num2str(ConstMode4(m))])
                        Analysis_Check_Mode1(i,j) = Analysis_Check_Mode1(i,j)-1;
                        Analysis_Check_Mode2(i,k) = Analysis_Check_Mode2(i,k)-1;
                        Analysis_Check_Mode3(i,l) = Analysis_Check_Mode3(i,l)-1;
                        Analysis_Check_Mode4(i,m) = Analysis_Check_Mode4(i,m)-1;
                    end
                    pMainFigure.Name = ['Comp=' num2str(PARAFAC_Components(i)) ...
                        '  Mode1=' num2str(ConstMode1(j)) ...
                        '  Mode2=' num2str(ConstMode2(k)) ...
                        '  Mode3=' num2str(ConstMode3(l)) ...
                        '  Mode4=' num2str(ConstMode4(m))];
                    clc
                    disp([Analysis_Check_Mode1 zeros(4,2) Analysis_Check_Mode2 zeros(4,2) Analysis_Check_Mode3 zeros(4,2) Analysis_Check_Mode4])
                    drawnow
                    pause(1)
                end
            end
        end
    end
end

clc
disp([Analysis_Check_Mode1 zeros(4,2) Analysis_Check_Mode2 zeros(4,2) Analysis_Check_Mode3 zeros(4,2) Analysis_Check_Mode4])
% Prune
% Contrain









%% new experiment 2D yuliia check

figure,plot([0.0122/0.731 0.0512/0.6974 0.097/0.6533 0.7312/0.0232 0.7342/0.0221])
figure,plot([0.0122 0.0512 0.097 0.7312 0.7342;0.731 0.6974 0.6533 0.0232 0.0221]','.-')






