function [Tr1,Tr2] = get_au_prog_from_spectro500(expPath,folderName,desiredPath)
% This function transfer files from a remonte PC to this PC. Hostname,
% Username and Password are set to the those of Spectro500. It transfers
% file of the selected folder, and files from its subfolders indicated. If
% the transfer is done successfully, it returns a value 1; if there were no
% transfer or the folderName didn't exist, it returns a nil value.
%
% Input
% expPath      Path of the file to be downloaded from the remote PC
% folderName      Name of the file to be downloaded from the remote PC
% desiredPath   Path to which the file will be download on this PC

%% User Input

% Required information about the remote PC (spectro 500MHz)
Hostname = '172.16.77.57';
Hostname = 'RMN500-1525.ceisam.sciences.univ-nantes.prive';
Username = 'nmr';
Password = 'topspin';

%% Get AU PROGs name from already available parameter sets in path
if strcmp(folderName,'all')
    command = ['cd ' expPath ' ; ls'];
    command_output = ssh2_simple_command(Hostname, Username, Password,command);
    [a,b] = ismember({'user'},command_output);
    if a
        command_output(b) = [];
    end
    scp_simple_get(Hostname, Username, Password,command_output,desiredPath,expPath);
    if a
        command = ['cd ' expPath '/user ; ls'];
        command_output = ssh2_simple_command(Hostname, Username, Password,command);
        ssh2_conn = scp_simple_get(Hostname, Username, Password,command_output,desiredPath,[expPath '/user']);
    end
    ssh2_close(ssh2_conn);
else
    % AU prog for acqu
    acqu_file = [desiredPath '\..\acqu\acqu_' folderName];
    if exist(acqu_file,'file')==2
        acquFile = regexp(fileread(acqu_file),'\n','split')';
        whichline = find(contains(acquFile,'##$AUNM='),1);
        if whichline
            out = textscan(acquFile{whichline},'##$AUNM= <%[^>]>');
            if ~isempty(out{1})
                au_acqu = out{1}{1};
                command = ['cd ' expPath ' ; ls'];
                command_output = ssh2_simple_command(Hostname, Username, Password,command);
                if ismember({au_acqu},command_output)
                    % get the au acqu file of the experiment
                    ssh2_conn = scp_simple_get(Hostname, Username, Password,au_acqu,desiredPath,expPath);
                    ssh2_close(ssh2_conn); %close connection when done
                else
                    command = ['cd ' expPath '/user ; ls'];
                    command_output = ssh2_simple_command(Hostname, Username, Password,command);
                    if ismember({au_acqu},command_output)
                        % get the au acqu file of the experiment
                        ssh2_conn = scp_simple_get(Hostname, Username, Password,au_acqu,desiredPath,[expPath '/user/']);
                        ssh2_close(ssh2_conn); %close connection when done
                    end
                end
                Tr1 = 1;
            else
                Tr1 = 0;
                fprintf(['\nThe acquisition file for parameter set "' folderName '" does not have an au program file saved.\n'])
            end
        end
    else
        fprintf(['\nThe acquisition file for parameter set "' folderName '" not found in path !\n'])
        Tr1 = 0;
        return
    end
    % AU prog for proc
    proc_file = [desiredPath '\..\proc\proc_' folderName];
    if exist(proc_file,'file')==2
        procFile = regexp(fileread(proc_file),'\n','split')';
        whichline = find(contains(procFile,'##$AUNMP='),1);
        if whichline
            out = textscan(procFile{whichline},'##$AUNMP= <%[^>]>');
            if ~isempty(out{1})
                au_proc = out{1}{1};
                command = ['cd ' expPath ' ; ls'];
                command_output = ssh2_simple_command(Hostname, Username, Password,command);
                if ismember({au_proc},command_output)
                    % get the au proc file of the experiment
                    ssh2_conn = scp_simple_get(Hostname, Username, Password,au_proc,desiredPath,expPath);
                    ssh2_close(ssh2_conn); %close connection when done
                else
                    command = ['cd ' expPath '/user ; ls'];
                    command_output = ssh2_simple_command(Hostname, Username, Password,command);
                    if ismember({au_proc},command_output)
                        % get the au proc file of the experiment
                        ssh2_conn = scp_simple_get(Hostname, Username, Password,au_proc,desiredPath,[expPath '/user/']);
                        ssh2_close(ssh2_conn); %close connection when done
                    end
                end
                Tr2 = 1;
            else
                Tr2 = 0;
                fprintf(['\nThe processing file for parameter set "' folderName '" does not have an au program file saved.\n'])
            end
        end
    else
        fprintf(['\nThe processing file for parameter set "' folderName '" not found in path !\n'])
        Tr2 = 0;
        return
    end
end

end




