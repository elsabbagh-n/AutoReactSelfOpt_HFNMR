function h = fixed_input_delete(h)
% This function let the user delete the line of a fixed input directly in
% the extset file by selecting their lines in the list box of the Display
% Extset Text File Panel.

S = h.list_box(3).String;
fixed = {'SUBMIT_HOLDER','NO_SUBMIT','STOP_RUN','START_RUN'};
fixed_inTable = {'SubmitHolder','NoSubmit','StopRun','StartRun'};
if ~isempty(S)
    ind = h.list_box(3).Value;
    s = S(ind,:);
    if ~isempty(s)
        [~,a] = ismember({s(~isspace(s))},fixed);
        if a
            if ind==size(S,1)
                h.list_box(3).Value = ind-1;
            end
            S(ind,:)='';
            eval(['h.Experiment_Table.' fixed_inTable{a} '(1:size(h.Experiment_Table,1))'...
                   ' = zeros(size(h.Experiment_Table,1),1);'])
            h = extset_generate(h);
            h.list_box(3).String = S;
        end
    end
end
end