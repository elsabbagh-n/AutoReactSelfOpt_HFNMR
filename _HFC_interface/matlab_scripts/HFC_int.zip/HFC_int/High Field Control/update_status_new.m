function status = update_status_new(fileName,Exp,screen,autoMode,varargin)
% This function gets the status of the experiments and updates the user if
% whether the experiment is available(1), submitted(2), running(3),
% completed(4) or deleted(0).

% The Status update are gathered in the following directory
% '/opt/topspin3.6.2/prog/curdir/changer/inmrchanger'
% and named in the following format: MMMdd-yyyy-HHmm-User where the time
% corresponds to the first submission. If the submission is cancled, the
% file is deleted.
% ex : 'Mar01-2022-1322-Nour.set'
% Note that, once the extset file is transferred, the experiments are
% directly submitted.

% User choice
tab = 1+0;
creation = 0;
nbAdditionalArea = 0;
if ~(size(varargin,2)==0)
    if size(varargin,2)==1
        % Continue update
        status = varargin{1};
        go = 1;
        creation = 0; % creation not needed when continue
    else
        if isempty(varargin{1})
            % New udpate starting
            go = 0;
        else
            % Continue update
            status = varargin{1};
            go = 1;
            creation = 0; % creation not needed when continue
        end
        if size(varargin,2)>=2
            nbAdditionalArea = varargin{2};
        end
    end
else
    % New udpate starting
    go = 0;
end

% Path where the handles are or will be saved
saveHere = 'C:\Users\Ceisam_Mimm\Documents\MATLAB\ichem\CurrentHFNMROptFolder\High Field Control';
if ~go
    if tab
        if ~isfile([saveHere '\autoModeHandles_fig_screen' num2str(screen) '_tab.fig'])
            creation = 1; % creation required when new update starting and no saved handles available
        end
    else
        if ~isfile([saveHere '\autoModeHandles_fig_screen' num2str(screen) '.fig'])
            creation = 1; % creation required when new update starting and no saved handles available
        end
    end
end

if creation
    status = initialize_figures(2,screen,autoMode,saveHere); % with tabs
    figure(status.F)
    
    % Variable to check if all submitted experiments are completed
    status.done = 0;
else
    if ~go
        if ~autoMode
            if tab
                openfig([saveHere '\autoModeHandles_fig_screen' num2str(screen) '_tab.fig']);
            else
                openfig([saveHere '\autoModeHandles_fig_screen' num2str(screen) '.fig']);
            end
        end
        
        % Get handles
        FigureHandle = get(0, 'Children');
        for i = 1:length(FigureHandle)
            if strcmp(FigureHandle(i).Name,'Status')
                FigureHandle = FigureHandle(i);
                break
            end
        end
        c = class(FigureHandle.Children);
        c = split(c,'.'); c = c(end);
        if ismember(lower(c),{'tabgroup'})
            % The status window contains tabs
            status.F = FigureHandle;
            
            % The status window contains tabs
            G = status.F.Children;
            for i = 1:length(G.Children)
                if strcmp(G.Children(i).Title,'Status table & Area setup')
                    TAB(1) = G.Children(i);
                elseif strcmp(G.Children(i).Title,'Graphical Application Update')
                    TAB(2) = G.Children(i);
                end
            end
            
            % Status table Tab
            status.F.Children.SelectedTab = TAB(1);
            if strcmp(FigureHandle.Children.Children(1).Title,'Status table & Area setup')
                status.f(1) = FigureHandle.Children.Children(1);
            elseif strcmp(FigureHandle.Children.Children(2).Title,'Status table & Area setup')
                status.f(1) = FigureHandle.Children.Children(2);
            end
            status.F.Children.SelectedTab = status.f(1);
        else
            status.f(1) = FigureHandle;
        end
        
        typeChildren = {'button','textarea','label','table','buttongroup'};
        buttonText = {'Set area region','Area calculation','DONE'};
        labelText = {'Target  ','Max area','Or inser','of ExpNo','Referenc','Busy unt'};
        textareaPosition = [213;284;375];
        for i = 1:length(status.f(1).Children)
            c = class(status.f(1).Children(i));
            c = split(c,'.'); c = c(end);
            [~,a] = ismember(lower(c),typeChildren);
            if a==1 % children is a button
                t = {status.f(1).Children(i).Text};
                [~,b] = ismember(t,buttonText);
                status.button(b) = status.f(1).Children(i);
                if ~autoMode
                    status.button(b).Enable = 'on';
                else
                    status.button(b).Enable = 'off';
                end
            elseif a==2 % children is a textarea
                p = status.f(1).Children(i).Position(1);
                [~,b] = ismember(p,textareaPosition);
                status.uitextarea(b) = status.f(1).Children(i);
                if ~autoMode
                    status.uitextarea(b).Enable = 'on';
                else
                    status.uitextarea(b).Enable = 'off';
                end
            elseif a==3 % children is a label
                t = {status.f(1).Children(i).Text};
                if isa(t{1},'char')
                    continue
                end
                [~,b] = ismember({t{1}{1}(1:8)},labelText);
                status.text(b) = status.f(1).Children(i);
                if ~autoMode
                    status.text(b).Enable = 'on';
                else
                    status.text(b).Enable = 'off';
                end
            elseif a==4 % children is a table
                status.uit = status.f(1).Children(i);
            elseif a==5 % children is a buttongroup
                status.radiobuttonGroup(1) = status.f(1).Children(i);
                if ~autoMode
                    status.radiobuttonGroup(1).Enable = 'on';
                else
                    status.radiobuttonGroup(1).Enable = 'off';
                end
                subChild = status.f(1).Children(i).Children;
                for j = 1:length(subChild)
                    if strcmp(subChild(j).Text,'Target')
                        status.radiobutton(1) = subChild(j);
                        status.radiobutton(1).Enable = 'on';
                    elseif strcmp(subChild(j).Text,'Reference')
                        status.radiobutton(2) = subChild(j);
                        status.radiobutton(2).Enable = 'on';
                    end
                end
            end
        end
        
        % Set style for uitable
        status.colorGrad = colorGradient([1 1 0],[0.04,0.74,0.00],4);
        status.sHiLite(1:5) = uistyle;
        status.sHiLite(1).BackgroundColor = status.colorGrad(1,:);
        status.sHiLite(2).BackgroundColor = status.colorGrad(2,:);
        status.sHiLite(3).BackgroundColor = status.colorGrad(3,:);
        status.sHiLite(4).BackgroundColor = status.colorGrad(4,:);
        status.sHiLite(5).BackgroundColor = [0.8500 0.3250 0.0980];
        % status.sHiLite(6).HorizontalAlignment = 'center';
        % addStyle(status.uit,status.sHiLite(6))
        
        % Variable to check if all submitted experiments are completed
        status.done = 0;
    else
        if autoMode
            % Get handles
            FigureHandle = get(0, 'Children');
            for i = 1:length(FigureHandle)
                if strcmp(FigureHandle(i).Name,'Status')
                    FigureHandle = FigureHandle(i);
                    break
                end
            end
            c = class(FigureHandle.Children);
            c = split(c,'.'); c = c(end);
            if ismember(lower(c),{'tabgroup'})
                % The status window contains tabs
                status.F = FigureHandle;
                
                % The status window contains tabs
                G = status.F.Children;
                for i = 1:length(G.Children)
                    if strcmp(G.Children(i).Title,'Status table & Area setup')
                        TAB(1) = G.Children(i);
                    elseif strcmp(G.Children(i).Title,'Graphical Application Update')
                        TAB(2) = G.Children(i);
                    end
                end
                
                % Status table Tab
                status.F.Children.SelectedTab = TAB(1);
                if strcmp(FigureHandle.Children.Children(1).Title,'Status table & Area setup')
                    status.f(1) = FigureHandle.Children.Children(1);
                elseif strcmp(FigureHandle.Children.Children(2).Title,'Status table & Area setup')
                    status.f(1) = FigureHandle.Children.Children(2);
                end
                status.F.Children.SelectedTab = status.f(1);
            else
                status.f(1) = FigureHandle;
            end
            
            typeChildren = {'button','textarea','label','table','buttongroup'};
            buttonText = {'Set area region','Area calculation','DONE'};
            labelText = {'Target  ','Max area','Or inser','of ExpNo','Referenc','Busy unt'};
            textareaPosition = [213;284;375];
            for i = 1:length(status.f(1).Children)
                c = class(status.f(1).Children(i));
                c = split(c,'.'); c = c(end);
                [~,a] = ismember(lower(c),typeChildren);
                if a==1 % children is a button
                    t = {status.f(1).Children(i).Text};
                    [~,b] = ismember(t,buttonText);
                    status.button(b) = status.f(1).Children(i);
                    if ~autoMode
                        status.button(b).Enable = 'on';
                    else
                        status.button(b).Enable = 'off';
                    end
                elseif a==2 % children is a textarea
                    p = status.f(1).Children(i).Position(1);
                    [~,b] = ismember(p,textareaPosition);
                    status.uitextarea(b) = status.f(1).Children(i);
                    if ~autoMode
                        status.uitextarea(b).Enable = 'on';
                    else
                        status.uitextarea(b).Enable = 'off';
                    end
                elseif a==3 % children is a label
                    t = {status.f(1).Children(i).Text};
                    if isa(t{1},'char')
                        continue
                    end
                    [~,b] = ismember({t{1}{1}(1:8)},labelText);
                    status.text(b) = status.f(1).Children(i);
                    if ~autoMode
                        status.text(b).Enable = 'on';
                    else
                        status.text(b).Enable = 'off';
                    end
                elseif a==4 % children is a table
                    status.uit = status.f(1).Children(i);
                elseif a==5 % children is a buttongroup
                    status.radiobuttonGroup(1) = status.f(1).Children(i);
                    if ~autoMode
                        status.radiobuttonGroup(1).Enable = 'on';
                    else
                        status.radiobuttonGroup(1).Enable = 'off';
                    end
                    subChild = status.f(1).Children(i).Children;
                    for j = 1:length(subChild)
                        if strcmp(subChild(j).Text,'Target')
                            status.radiobutton(1) = subChild(j);
                            if ~autoMode
                                status.radiobutton(1).Enable = 'on';
                            else
                                status.radiobutton(1).Enable = 'off';
                            end
                        elseif strcmp(subChild(j).Text,'Reference')
                            status.radiobutton(2) = subChild(j);
                            if ~autoMode
                                status.radiobutton(2).Enable = 'on';
                            else
                                status.radiobutton(2).Enable = 'off';
                            end
                        end
                    end
                end
            end
            
            % Set style for uitable
            status.colorGrad = colorGradient([1 1 0],[0.04,0.74,0.00],4);
            status.sHiLite(1:5) = uistyle;
            status.sHiLite(1).BackgroundColor = status.colorGrad(1,:);
            status.sHiLite(2).BackgroundColor = status.colorGrad(2,:);
            status.sHiLite(3).BackgroundColor = status.colorGrad(3,:);
            status.sHiLite(4).BackgroundColor = status.colorGrad(4,:);
            status.sHiLite(5).BackgroundColor = [0.8500 0.3250 0.0980];
            % status.sHiLite(6).HorizontalAlignment = 'center';
            % addStyle(status.uit,status.sHiLite(6))
            
            % Variable to check if all submitted experiments are completed
            status.done = 0;
        else
            if tab
                figure(status.F)
            else
                figure(status.f(1))
            end
        end
    end
end

% Path of the updated IconNMR status file
filePath = ['C:\Users\Ceisam_Mimm\Documents\MATLAB\status\' fileName];

if exist(filePath, 'file')==2
    % Date and time of the updated status file
    D = dir(filePath);
    status.T = D.date(end-7:end);
    
    % Read the status file
    text = regexp(fileread(filePath),'\n','split')';
    whichline = find(contains(text,'##Holder##'));
    
    % The number of the submitted experiments
    nb = length(whichline);
    
    % Gather information about the submitted experiments writtin in the
    % following order :
    % Holder Status Date ExpNo Solvent Experiment DataDirectory AcquTime
    out = cell(nb,14);
    name = char(zeros(nb,20));
    text_format = '##Holder## %d%s%s%d {%[^{}]} {%[^{}]} %s %s';
    for i = 1:nb
        out(i,1:8) = textscan(text{whichline(i)},text_format);
        name(i,1:length(char(out{i,3}))) = char(out{i,3});
        simple = 0;
    end
    % If the text format is wrong, then
    if isempty(out{i,5})
        simple = 1;
        text_format = '##Holder## %d%s%s%d %s %s %s %s';
        for i = 1:nb
            out(i,1:8) = textscan(text{whichline(i)},text_format);
            name(i,1:length(char(out{i,3}))) = char(out{i,3});
            out{i,8} = out{i,8}{1};
        end
    end
    % Join the two titles for each experiment, if available (the length/2 
    % of this variable is equal to the submitted experiments)
    whichline2 = find(contains(text,'##Title#')); % 
    ind = 1;
    for i = 1:length(whichline2)
        if mod(i,2)
            if whichline2(i+1)~=(whichline2(i)+1)
                ttle = textscan(text{whichline2(i)+1},'%s');
                out(ind,9) = join(ttle{1});
            else
                out(ind,9) = {''};
            end
        else
            if whichline2(i)~=length(text)
                if ~ismember((whichline2(i)+1),whichline) ...
                        && ~isempty(text{whichline2(i)+1})
                    title2 = textscan(text{whichline2(i)+1},'%s');
                    out{ind,9} = [out{ind,9}{1}...
                        ' - ' title2{1}{1}];
                end
            end
            ind = ind +1;
        end
    end
    
    % Adjust output format of the gathered informaton
    for i = 1:nb
        % Status
        out(i,2) = out{i,2};
        if strcmp(out{i,2},'Available')
            out(i,10:14) = {1 0 0 0 0};
        else
            if strcmp(out{i,2},'Submitted')
                out(i,10:14) = {1 1 0 0 0};
            else
                if strcmp(out{i,2},'Running')
                    out(i,10:14) = {1 1 1 0 0};
                else
                    if strcmp(out{i,2},'Completed')
                        out(i,10:14) = {1 1 1 1 0};
                    else
                        if strcmp(out{i,2},'Error')
                            out(i,10:14) = {0 0 0 0 1};
                        end
                    end
                end
            end
        end
        % Date or Name
        out(i,3) = out{i,3};
        % Solvent
        solv = textscan(out{i,5}{1},'%s%*s');
        out(i,5) = solv{1};
        if simple
            % Experiment
            out(i,6) = out{i,6};
        else
            % Experiment
            exp = textscan(out{i,6}{1},'%*s%s%*s%*s%*s%*s%*s');
            out(i,6) = exp{1};
        end
        % Title
        if isempty(out{i,9})
            out(i,9) = {'no title'};
        else
            out(i,9) = out(i,9);
        end
    end
    Holder = out(:,1);
    available = out(:,10);
    submitted = out(:,11);
    running = out(:,12);
    completed = out(:,13);
    durations = duration(out(:,8)); %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    Date = out(:,3);
    ExpNo = out(:,4);
    Solvent = out(:,5);
    Experiment = out(:,6);
    Title = out(:,9);
    errorR = out(:,14);
    %nb=1;Holder={1};available=1;submitted=1;running=1;completed=1;
    %Date={'230207_BBI_ChemReact_PeakID'};ExpNo={13};Solvent={'CH3CN'};Experiment={'WET'};Title={'wet'};errorR={0};
    Available = cellstr(char(zeros(nb,1)));
    Submitted = cellstr(char(zeros(nb,1)));
    Running = cellstr(char(zeros(nb,1)));
    Completed = cellstr(char(zeros(nb,1)));
    Deleted = cellstr(char(zeros(nb,1)));
    deleted = num2cell(zeros(nb,1));
    for i = 1:nb
        if errorR{i,1}==1
            Running{i,1} = 'Error';
        end
    end
    
    Area = num2cell(zeros(nb,1));
    RelativeArea = num2cell(zeros(nb,1));
    ind = 2;
    str = [];
    if isempty(nbAdditionalArea)
        AdditionalArea = 0;
        RelativeAdditionalArea = 0;
    elseif nbAdditionalArea==0
        AdditionalArea = num2cell(zeros(nb,1));
        RelativeAdditionalArea = num2cell(zeros(nb,1));
    else
        for i = 1:nbAdditionalArea
            ind = ind+1;
            eval(['Area_' num2str(ind) ' = num2cell(zeros(nb,1));'])
            str = [str,',Area_' num2str(ind)]; %#ok<AGROW>
        end
        str = str(2:end);%remove the first comma
        eval(['AdditionalArea = [' str '];'])
        eval(['RelativeAdditionalArea = [' str '];'])
    end
    % Gather information in a table
    tab = table(Date,Holder,ExpNo,Experiment,Solvent,Title,...
        Available,Submitted,Running,Completed,Deleted,Area,RelativeArea,...
        AdditionalArea,RelativeAdditionalArea);
    % Status matrix for later table style
    st = [available submitted running completed deleted];
    
    % Index of the target experiments in the new updated status file
    if isempty(Exp)
        Exp = cell2mat(ExpNo);
    elseif isa(Exp,'char')
        Exp = cell2mat(ExpNo);
    end
    [~,bb] = ismember(Exp,cell2mat(ExpNo));
    [~,bbb] = ismember(cell2mat(ExpNo),Exp);
    bbb = find(bbb);
    ind = find(bb==0);
    if ind
        bb_ = bb(find(bb~=0)); %#ok<FNDSB>
    else
        bb_ = bb;
    end
    if length(bbb)~=length(find(bb_))
        % Suspect that 2 experiments have the same number, like in a new
        % dataset folder
        % Only consider the lastest one
        for i = 1:length(Exp)
            [~,bb__] = ismember(Exp(i),cell2mat(ExpNo));
            [~,bbb_] = ismember(cell2mat(ExpNo),Exp(i));
            bbb_ = find(bbb_);
            if length(bbb_)~=length(find(bb__))
                bb_(i) = bbb_(end);
            end
        end
        if ind
            bb(1:length(bb_)) = bb_;
        else
            bb = bb_;
        end
    end
    % If status file of IconNMR is not yet updated and does not contains
    % the target experiments
    if autoMode==0 || autoMode==1
        if go % Continue update
            if ~(length(find(bb))==length(bb)) % Target experiments not found
                if bb==zeros(size(bb))
                    % Transfer again the updated status file
                    statusPath = '/opt/topspin3.6.2/prog/curdir/changer';
                    desiredPath = 'C:\Users\elsabbagh-n\Documents\DataSet\status\';
                    fileName = get_status_from_spectro500(statusPath,fileName,desiredPath,0);
                    status = update_status_new(fileName,Exp,screen,autoMode,status);
                    return
                end
            end
        end
    end
    
    % Gather only the target experiments
    tab = tab(bb,:);
    st = st(bb,:);
    nb = length(bb);
    out = out(bb,:);
    name = name(bb,:);
    errorR = errorR(bb);
    durations = durations(bb);
    completed = completed(bb);

    if ~go % New update
        status.errorR = errorR;
        status.st = st;
        status.table = tab;
        status.output = out;
        status.name = name;
    else % Continue update
        % Check for old experiments if they have been deleted (not target)
        [~,a] = ismember(cell2mat(status.table.ExpNo),cell2mat(ExpNo));
        % Index in status.table of the missing experiment(s)
        old_exp_missing = find(~a);
        % Index in status.table of the kept old experiment(s)
        kept_old_exp = find(a);
        %where kept_old_exp(bb):is the indices in the big table of the experiment(s) present in the status new table
        
        % Check and/or update for error status
        for i = 1:length(bb)
            if bb(i)<=length(kept_old_exp)
                % Target experiment is an old one
                status.errorR(kept_old_exp(bb(i))) = errorR(i);
            else
                % Target experiment is a new one
                status.errorR(size(status.errorR,1)+1,1) = errorR(i);
            end
        end
        
        % Update 'Delete' status for old deleted experiments
        if ~isempty(old_exp_missing)
            for i = 1:length(old_exp_missing)
                if ~(status.st{old_exp_missing(i),5})
                    status.st{old_exp_missing(i),5} = 1;
                    status.table.Deleted{old_exp_missing(i)} = status.T;
                end
            end
        end
                
        % Update status table for the target experiments (new or old)
        for i = 1:nb
            [~,b] = ismember(cell2mat(tab.ExpNo(i)),...
                double(cell2mat(status.table.ExpNo))+1000*cell2mat(status.st(:,5)));
            if b && ~status.st{b,5} % old target experiment not deleted
                if ~status.st{b,4} % experiment still not completed in the previous file
                    % Update status
                    status.st(b,:) = st(i,:);
                    if status.st{b,4}
                        % Specify the time if has just been completed
                        status.table.Completed{b} = status.T;
                    end
                end
            else % new target experiment
                sz = size(status.table,1);
                status.table(sz+1,:) = tab(i,:);
                status.st(sz+1,:) = st(i,:);
                status.name(sz+1,:) = name(i,:);
            end
        end
    end
    
    % Update table in the status window
    status.uit.Data = status.table;
    
    % Remove old status colored cell
    if size(status.uit.StyleConfigurations,1)>1
        removeStyle(status.uit,2:size(status.uit.StyleConfigurations,1))
    end
    
    % Color cell according to the new status of experiments
    % 'Available' status
    ix = find(cell2mat(status.st(:,1)));
    ix_y = ix;%find(ix~=0);
    if ix_y
        addStyle(status.uit,status.sHiLite(1),'cell',[ix_y,7*ones(size(ix_y))])
    end
    % 'Submitted' status
    ix = find(cell2mat(status.st(:,2)));
    ix_y = ix;%find(ix~=0);
    if ix_y
        addStyle(status.uit,status.sHiLite(2),'cell',[ix_y,8*ones(size(ix_y))])
    end
    % 'Running' status
    ix = find(cell2mat(status.st(:,3)));
    ix_y = ix;%find(ix~=0);
    if ix_y
        addStyle(status.uit,status.sHiLite(3),'cell',[ix_y,9*ones(size(ix_y))])
    end
    % 'Completed' status
    ix = find(cell2mat(status.st(:,4)));
    ix_y = ix;%find(ix~=0);
    if ix_y
        addStyle(status.uit,status.sHiLite(4),'cell',[ix_y,10*ones(size(ix_y))])
    end
    % 'Deleted' status
    ix = find(cell2mat(status.st(:,5)));
    ix_y = ix;%find(ix~=0);
    if ix_y
        addStyle(status.uit,status.sHiLite(5),'cell',[ix_y,11*ones(size(ix_y))])
    end
    
    % Index of the target experiments in the window status table 
    [~,indd] = ismember(Exp,double(cell2mat(status.table.ExpNo)));
    % Check if all experiments are completed
    if size(find(indd),1)==size(indd,1)
        if size(indd,1)<=size(status.st,1)
            % The experiment is concederred done if completed or stopped
            % due to error
            matrix = cell2mat(status.st(:,4));%+cell2mat(status.errorR); %%% NES 2023
            if matrix(indd)
                status.done = 1;
            else
                status.done = 0;
            end
        else
            status.done = 0;
        end
    else
        status.done = 0;
    end
    
    % Duration of each experiment(s)
    if isfield(status,'Durations')
        status.Durations = [status.Durations;durations];
        status.Completed = [status.Completed;completed];
    else
        status.Durations = durations;
        status.Completed = completed;
    end
end

end





