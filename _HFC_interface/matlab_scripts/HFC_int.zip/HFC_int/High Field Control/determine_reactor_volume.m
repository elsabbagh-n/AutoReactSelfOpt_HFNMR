function Reactor_Volume = determine_reactor_volume(varargin)
% This function determines the volume of a reactor between a pump, or
% several ones, and a high-field spectrometer. The pump(s) should be primed
% and ready to pump new solvent, other than the one already filling the
% reactor and the flowtube unit. The peak of interest, of the new solvent,
% should be indicated in the autoModeHandles created to search for a
% plateau. After the plateau is reached, and knowing the time when the
% pump(s) was(were) launched and the flowrate value, the reactor volume is
% then determined.
%% Initial values
varargin = {1};
close all force
clearvars -except varargin
clc
% File path of the HF-NMR interface script
addpath(genpath('C:\Users\Ceisam_Mimm\Documents\MATLAB\CurrentHFNMROptFolder\High Field Control'))
% File path of the SCP functions
addpath(genpath('C:\Users\Ceisam_Mimm\Documents\MATLAB\CurrentHFNMROptFolder\Freedman_ssh'))
% Flowrate mL/min
if  ~isempty(varargin)
    HPLC_pumps = 1;
    % FR = [0.4 0.1 0.1];
    FR = [0.4 0.8];
else
    HPLC_pumps = 0;
    FR = 0.6;
end
%% Delete all existing connection links
if isempty(instrfind) ~= 1
    delete(instrfind);
end
%% Connect to the Vapourtec pump
if HPLC_pumps
    Pump_A = serial('COM20','BaudRate', 4800,'DataBits', 8,'Parity', 'none','StopBits', 2,'Terminator', {'CR/LF', 'CR'},'TimeOut', 2); %#ok<SERIAL>
    Pump_B = serial('COM16','BaudRate', 4800,'DataBits', 8,'Parity', 'none','StopBits', 2,'Terminator', {'CR/LF', 'CR'},'TimeOut', 2); %#ok<SERIAL>
    % Pump_C = serial('COM5','BaudRate', 4800,'DataBits', 8,'Parity', 'none','StopBits', 2,'Terminator', {'CR/LF', 'CR'},'TimeOut', 2); %#ok<SERIAL>
    fopen(Pump_A);pause(0.2)
    fopen(Pump_B);pause(0.2)
    % fopen(Pump_C);pause(0.2)
else
    LienCommunication = serial('COM10','BaudRate', 9600,'DataBits', 8,'Parity', 'none','StopBits', 1,'Terminator', {'CR/LF', 'CR'},'TimeOut', 2); %#ok<SERIAL>
    fopen(LienCommunication);pause(0.2)
end
%% Set flowrate on pump
if HPLC_pumps
    f = [num2str(FR(1)) ' flowrate set'];
    fprintf(Pump_A,f);pause(0.2);
    f = [num2str(FR(2)) ' flowrate set'];
    fprintf(Pump_B,f);pause(0.2);
    % f = [num2str(FR(3)) ' flowrate set'];
    % fprintf(Pump_C,f);pause(0.2);
else
    fprintf(LienCommunication,['SETFLOW ' num2str(FR)]);pause(0.2)
    Reponse = fscanf(LienCommunication);
    fprintf('Voici la réponse : ')
    fprintf(Reponse);
    fprintf('\n')
end
%% Start pump
if HPLC_pumps
    % Give the switch on order
    fprintf(Pump_A,'0 pump set');
    fprintf(Pump_B,'0 pump set');
    % fprintf(Pump_C,'0 pump set');
else
    fprintf(LienCommunication,'START');pause(0.2)
    Reponse = fscanf(LienCommunication);
    fprintf('Voici la réponse : ')
    fprintf(Reponse);
    fprintf('\n')
end
StartingTime = datetime('now','Format','HH:mm:ss');
%% Series of experiment to observe the filling
DetermineVolumeAutoHandlePath = ['C:\Users\Ceisam_Mimm\Documents\MATLAB\CurrentHFNMROptFolder\High Field Control\'...
    'autoModeHandles_1H_LoopToCheckReactorVolume.mat'];
load(DetermineVolumeAutoHandlePath,'autoModeHandles')
autoModeHandles.archive = [];
autoModeHandles.area = [1.05 1.231];%Taregt
autoModeHandles.areaRef = [3.238 3.452];%Reference
autoModeHandles.areaAdditionalList_Num = [];% [3.39 3.53]+0.17;%Addition
autoModeHandles.Table.ExpNo(2) = 1;
% autoModeHandles.Table.Parameters(2) = "D1,5,O1p,5,sw,19.9947,p1,10,plw1,14.414";
autoModeHandles.Table.Name(2) = string(['NES_' char(datetime('now','Format','yyyyMMdd')) '_ReactorVolume']);
autoModeHandles.Table.Title(2) = "Plateau 1H to calculate reactor volume";
save(DetermineVolumeAutoHandlePath,'autoModeHandles')
pause(0.1)
[Area,Region,pathLatestExp] = ExtSet_GUI_function(DetermineVolumeAutoHandlePath,0,'maxuc');
ExtSet_GUI_function('stop')
clc
display(Region)
display(pathLatestExp)
drawnow
%% Stop pump
if HPLC_pumps
    % Give the switch off order
    fprintf(Pump_A,'1 pump set');         pause(0.2);
    fprintf(Pump_B,'1 pump set');         pause(0.2);
    % fprintf(Pump_C,'1 pump set');         pause(0.2);
else
    fprintf(LienCommunication,'STOP');pause(0.2)
    Reponse = fscanf(LienCommunication);
    fprintf('Voici la réponse : ')
    fprintf(Reponse);
    fprintf('\n')
end
%% Close connection to the Vapourtec pump
if HPLC_pumps
    % Close the communication link
    fclose(Pump_A);         pause(0.2);
    fclose(Pump_B);         pause(0.2);
    % fclose(Pump_C);         pause(0.2);
else
    fclose(LienCommunication);
end
%% Get date/time
ExpNo = double(cell2mat(Area.ExpNo)); %1:14
[~,filename,~] = fileparts(fileparts(pathLatestExp));
[~,ExpTimes] = get_experiments_times_remote(ExpNo,filename);
% StartingTime = datetime('13:26:33','Format','HH:mm:ss');
% StartingTime.Day = ExpTimes(1).Day;
% StartingTime.Month = ExpTimes(1).Month;
% StartingTime.Year = ExpTimes(1).Year;
%% Data point
ind = ExpTimes>=StartingTime;
% x = ExpTimes(ind);
y = [Area.Area{ind}]';
yref = [Area.Area{ind}]'./[Area.RelativeArea{ind}]';
dy = diff(y);
D = ExpTimes-StartingTime;
[h,m,s] = hms(D);
D = h*60+m+s/60; %min
x = D;
figure
subplot(1,2,1)
plot(x,y,'-o')
hold on,plot(x,yref,'-o')
xlabel('min')
ylabel('Area')
subplot(1,2,2)
plot(x(2:end),dy,'-o')
xlabel('min')
ylabel('dArea')
while(1)
[BREAK,~]=ginput(1); %min
Reactor_Volume = BREAK*sum(FR) %mL %4.5mL
end
end













