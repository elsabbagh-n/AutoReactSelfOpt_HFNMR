function ParValues = get_AcquOrProc_ParValue_from_spectro500(FileName,datasetPath,...
    expNb,AcquOrProc,Parameter,varargin)
% This function returns the value of an acquisition or a processing
% parameter of an experiment in its dataset folder. Hostname, Username and
% Password are set to the those of Spectro500.
%
% No file transfer !
%
% Input
% FileName                Name of the folder to be checked
% datasetPath             Path of folder to be checked on the remote PC
% expNb                   Number of the experiment to be checked
% AcquOrProc              Type of the parameter, 'acqus' or 'procs'
% Parameter               Parameter label or cell of labels if multiple
% varargin                if AcquOrProc = 'procs', then varargin = PROCNO
% Output
% ParValues               Values of the parameter(s), if found/valid
%
% FileName = '221109_1';datasetPath = '/opt/nmrdata/user/nmr/Nour';expNb = 5;AcquOrProc = 'procs';Parameter = {'INTSCL','ISEN'};varargin = [];

%% User Input

% Check if procno number needed
if isempty(varargin) && strcmp(AcquOrProc,'procs')
    ProcnoCheck = 1;
else
    ProcnoCheck = 0;
end
% Required information about the remote PC (spectro 500MHz)
Hostname = '172.16.77.57';
Hostname = 'RMN500-1525.ceisam.sciences.univ-nantes.prive';
Username = 'nmr';
Password = 'topspin';
% File path of the SCP functions
addpath(genpath('C:\Users\elsabbagh-n\Documents\MATLAB\Freedman_ssh'))
if nargin<5
    error('Some input parameter are missing.')
end
% Search in experiment dataset folder or in /par
if isempty(expNb)
    % Search in /par
    SearchPar = 1;
    ProcnoCheck = 0;
    if strcmp(AcquOrProc,'acqus')
        % Change from acqus to acqu
        AcquOrProc = 'acqu';
    elseif strcmp(AcquOrProc,'procs')
        % Change from procs to proc
        AcquOrProc = 'proc';
    end
elseif length(expNb)>1
    error('This function only looks for parameters of a single experiment.')
else
    % Search in experiment dataset folder
    SearchPar = 0;
end
%% Make sure that the corresponding folder/files are valid

if ~SearchPar % Search in experiment dataset folder
    % Check if the main dataset folder is created
    command = ['cd ' datasetPath '/' FileName ' ; ls ;'];
    command_output = ssh2_simple_command(Hostname, Username, Password,command);
    expInFolder = zeros(length(command_output),1);
    for i = 1:length(command_output)
        expInFolder(i,1) = str2double(string(cell2mat(command_output(i))));
    end
    expInFolder = sort(expInFolder,'ascend');
    expFound = expNb(ismember(expNb,expInFolder));
    if isempty(expFound)
        error('Experiment number not found.')
    end
else % Search in /par
    % Check if the parameter set exits
    checkPath = datasetPath;
    command = ['cd ' checkPath ' ; ls ;'];
    command_output = ssh2_simple_command(Hostname, Username, Password,command);
    if  ~ismember({FileName},command_output)
        checkPath = [datasetPath '/user'];
        command = ['cd ' checkPath ' ; ls ;'];
        command_output = ssh2_simple_command(Hostname, Username, Password,command);
        if  ~ismember({FileName},command_output)
            warning(['Parameter set  ' FileName ' not found.'])
            ParValues = [];
            return
        end
    end
end
% Check if the file exists
if ~SearchPar % Search in experiment dataset folder
    if strcmp(AcquOrProc,'acqus')
        command = ['cd ' datasetPath '/' FileName '/' num2str(expFound) ' ; ls ;'];
        command_output = ssh2_simple_command(Hostname, Username, Password,command);
        if isempty(find(contains(command_output,AcquOrProc),1))
            error([AcquOrProc ' file not found.'])
        end
    elseif strcmp(AcquOrProc,'procs')
        if ProcnoCheck % continue only if one procno is available anyway
            command = ['cd ' datasetPath '/' FileName '/' num2str(expFound) '/pdata ; ls ;'];
            command_output = ssh2_simple_command(Hostname, Username, Password,command);
            if length(command_output)~=1
                error('The parameter to check is supposed to be a processing one. Yet, no procno was inputed.')
            else
                varargin{1} = str2double(command_output{1});
            end
        end
        command = ['cd ' datasetPath '/' FileName '/' num2str(expFound) '/pdata/' num2str(varargin{1}) '; ls ;'];
        command_output = ssh2_simple_command(Hostname, Username, Password,command);
        if isempty(find(contains(command_output,AcquOrProc),1))
            error([AcquOrProc ' file not found.'])
        end
    end
else % Search in /par
    command = ['cd ' checkPath '/' FileName ' ; ls ;'];
    command_output = ssh2_simple_command(Hostname, Username, Password,command);
    if strcmp(AcquOrProc,'acqu')
        if isempty(find(contains(command_output,AcquOrProc),1))
            error([AcquOrProc ' file not found.'])
        end
    elseif strcmp(AcquOrProc,'proc')
        if isempty(find(contains(command_output,AcquOrProc),1))
            error([AcquOrProc ' file not found.'])
        end
    end
end
%% Look for the parameter value

if isa(Parameter,'cell')
    if length(Parameter)==1
        Parameter = Parameter{1};
        listP = 0;
    else
        listP = 1;
    end
else
    listP = 0;
end

if ~SearchPar % Search in experiment dataset folder
    if listP % list of parameters to check
        if strcmp(AcquOrProc,'acqus')
            command = ['cd ' datasetPath '/' FileName '/' num2str(expFound) ' ; cat ' AcquOrProc ' ;'];
            command_output = ssh2_simple_command(Hostname, Username, Password,command);
            ParValue0 = cell(1,length(Parameter));
            for i = 1:length(Parameter)
                Parameter0 = Parameter{i};
                whichline = find(contains(command_output,['##$' Parameter0 '=']),1);
                if ~isempty(whichline)
                    ParValues = cell2mat(textscan(command_output{whichline},['##$' Parameter0 '=%f']));
                    if isempty(ParValues)
                        ParValues = textscan(command_output{whichline},['##$' Parameter0 '=%s']);
                        ParValues = ParValues{1}{1};
                        if ParValues(1)=='('
                            if command_output{whichline+1}(1)=='<'
                                ParValues = textscan(command_output{whichline+1},'%s');
                                ParValues = ParValues{1}';
                                nextLine = whichline+2;
                                while(~(command_output{nextLine}(1)=='#'))
                                    ParValue00 = textscan(command_output{nextLine},'%s');
                                    ParValues = [ParValues ParValue00{1}']; %#ok<AGROW>
                                    nextLine = nextLine+1;
                                end
                            else
                                ParValues = cell2mat(textscan(command_output{whichline+1},'%f'))';
                                nextLine = whichline+2;
                                while(~(command_output{nextLine}(1)=='#'))
                                    ParValues = [ParValues cell2mat(textscan(command_output{nextLine},'%f'))']; %#ok<AGROW>
                                    nextLine = nextLine+1;
                                end
                            end
                        elseif ParValues(1)=='<'
                            if ParValues(end)=='>'
                                ParValues = ParValues(2:end-1);
                            else
                                while(~(ParValues(end)=='>'))
                                    ParValue00 = textscan(command_output{whichline},['##$' Parameter0 '= ' ParValues '%s']);
                                    ParValues = [ParValues ' ' ParValue00{1}{1}]; %#ok<AGROW>
                                end
                                ParValues = ParValues(2:end-1);
                            end
                        end
                    end
                    ParValue0{i} = ParValues;
                else
                    warning(['Parameter ' Parameter ' not found.'])
                end
            end
            ParValues = ParValue0;
        elseif strcmp(AcquOrProc,'procs')
            command = ['cd ' datasetPath '/' FileName '/' num2str(expFound) '/pdata/' num2str(varargin{1}) '; cat ' AcquOrProc ' ;'];
            command_output = ssh2_simple_command(Hostname, Username, Password,command);
            ParValue0 = cell(1,length(Parameter));
            for i = 1:length(Parameter)
                Parameter0 = Parameter{i};
                whichline = find(contains(command_output,['##$' Parameter0 '=']),1);
                if ~isempty(whichline)
                    ParValues = cell2mat(textscan(command_output{whichline},['##$' Parameter0 '=%f']));
                    if isempty(ParValues)
                        ParValues = textscan(command_output{whichline},['##$' Parameter0 '=%s']);
                        ParValues = ParValues{1}{1};
                        if ParValues(1)=='('
                            if command_output{whichline+1}(1)=='<'
                                ParValues = textscan(command_output{whichline+1},'%s');
                                ParValues = ParValues{1}';
                                nextLine = whichline+2;
                                while(~(command_output{nextLine}(1)=='#'))
                                    ParValue00 = textscan(command_output{nextLine},'%s');
                                    ParValues = [ParValues ParValue00{1}']; %#ok<AGROW>
                                    nextLine = nextLine+1;
                                end
                            else
                                ParValues = cell2mat(textscan(command_output{whichline+1},'%f'))';
                                nextLine = whichline+2;
                                while(~(command_output{nextLine}(1)=='#'))
                                    ParValues = [ParValues cell2mat(textscan(command_output{nextLine},'%f'))']; %#ok<AGROW>
                                    nextLine = nextLine+1;
                                end
                            end
                        elseif ParValues(1)=='<'
                            if ParValues(end)=='>'
                                ParValues = ParValues(2:end-1);
                            else
                                while(~(ParValues(end)=='>'))
                                    ParValue00 = textscan(command_output{whichline},['##$' Parameter0 '= ' ParValues '%s']);
                                    ParValues = [ParValues ' ' ParValue00{1}{1}]; %#ok<AGROW>
                                end
                                ParValues = ParValues(2:end-1);
                            end
                        end
                    end
                    ParValue0{i} = ParValues;
                else
                    warning(['Parameter ' Parameter0 ' not found.'])
                end
            end
            ParValues = ParValue0;
        end
    else
        if strcmp(AcquOrProc,'acqus')
            command = ['cd ' datasetPath '/' FileName '/' num2str(expFound) ' ; cat ' AcquOrProc ' ;'];
            command_output = ssh2_simple_command(Hostname, Username, Password,command);
            whichline = find(contains(command_output,['##$' Parameter '=']),1);
            if ~isempty(whichline)
                ParValues = cell2mat(textscan(command_output{whichline},['##$' Parameter '=%f']));
                if isempty(ParValues)
                    ParValues = textscan(command_output{whichline},['##$' Parameter '=%s']);
                    ParValues = ParValues{1}{1};
                    if ParValues(1)=='('
                        if command_output{whichline+1}(1)=='<'
                            ParValues = textscan(command_output{whichline+1},'%s');
                            ParValues = ParValues{1}';
                            nextLine = whichline+2;
                            while(~(command_output{nextLine}(1)=='#'))
                                ParValue00 = textscan(command_output{nextLine},'%s');
                                ParValues = [ParValues ParValue00{1}']; %#ok<AGROW>
                                nextLine = nextLine+1;
                            end
                        else
                            ParValues = cell2mat(textscan(command_output{whichline+1},'%f'))';
                            nextLine = whichline+2;
                            while(~(command_output{nextLine}(1)=='#'))
                                ParValues = [ParValues cell2mat(textscan(command_output{nextLine},'%f'))']; %#ok<AGROW>
                                nextLine = nextLine+1;
                            end
                        end
                    elseif ParValues(1)=='<'
                        if ParValues(end)=='>'
                            ParValues = ParValues(2:end-1);
                        else
                            while(~(ParValues(end)=='>'))
                                ParValue00 = textscan(command_output{whichline},['##$' Parameter '= ' ParValues '%s']);
                                ParValues = [ParValues ' ' ParValue00{1}{1}]; %#ok<AGROW>
                            end
                            ParValues = ParValues(2:end-1);
                        end
                    end
                end
            else
                error(['Parameter ' Parameter ' not found.'])
            end
        elseif strcmp(AcquOrProc,'procs')
            command = ['cd ' datasetPath '/' FileName '/' num2str(expFound) '/pdata/' num2str(varargin{1}) '; cat ' AcquOrProc ' ;'];
            command_output = ssh2_simple_command(Hostname, Username, Password,command);
            whichline = find(contains(command_output,['##$' Parameter '=']),1);
            if ~isempty(whichline)
                ParValues = cell2mat(textscan(command_output{whichline},['##$' Parameter '=%f']));
                if isempty(ParValues)
                    ParValues = textscan(command_output{whichline},['##$' Parameter '=%s']);
                    ParValues = ParValues{1}{1};
                    if ParValues(1)=='('
                        if command_output{whichline+1}(1)=='<'
                            ParValues = textscan(command_output{whichline+1},'%s');
                            ParValues = ParValues{1}';
                            nextLine = whichline+2;
                            while(~(command_output{nextLine}(1)=='#'))
                                ParValue00 = textscan(command_output{nextLine},'%s');
                                ParValues = [ParValues ParValue00{1}']; %#ok<AGROW>
                                nextLine = nextLine+1;
                            end
                        else
                            ParValues = cell2mat(textscan(command_output{whichline+1},'%f'))';
                            nextLine = whichline+2;
                            while(~(command_output{nextLine}(1)=='#'))
                                ParValues = [ParValues cell2mat(textscan(command_output{nextLine},'%f'))']; %#ok<AGROW>
                                nextLine = nextLine+1;
                            end
                        end
                    elseif ParValues(1)=='<'
                        if ParValues(end)=='>'
                            ParValues = ParValues(2:end-1);
                        else
                            while(~(ParValues(end)=='>'))
                                ParValue00 = textscan(command_output{whichline},['##$' Parameter '= ' ParValues '%s']);
                                ParValues = [ParValues ' ' ParValue00{1}{1}]; %#ok<AGROW>
                            end
                            ParValues = ParValues(2:end-1);
                        end
                    end
                end
            else
                error(['Parameter ' Parameter ' not found.'])
            end
        end
    end
else % Search in /par
    if listP % list of parameters to check
        command = ['cd ' checkPath '/' FileName ' ; cat ' AcquOrProc ' ;'];
        command_output = ssh2_simple_command(Hostname, Username, Password,command);
        ParValue0 = cell(1,length(Parameter));
        for i = 1:length(Parameter)
            Parameter0 = Parameter{i};
            whichline = find(contains(command_output,['##$' Parameter0 '=']),1);
            if ~isempty(whichline)
                ParValues = cell2mat(textscan(command_output{whichline},['##$' Parameter0 '=%f']));
                if isempty(ParValues)
                    ParValues = textscan(command_output{whichline},['##$' Parameter0 '=%s']);
                    ParValues = ParValues{1}{1};
                    if ParValues(1)=='('
                        if command_output{whichline+1}(1)=='<'
                            ParValues = textscan(command_output{whichline+1},'%s');
                            ParValues = ParValues{1}';
                            nextLine = whichline+2;
                            while(~(command_output{nextLine}(1)=='#'))
                                ParValue00 = textscan(command_output{nextLine},'%s');
                                ParValues = [ParValues ParValue00{1}']; %#ok<AGROW>
                                nextLine = nextLine+1;
                            end
                        else
                            ParValues = cell2mat(textscan(command_output{whichline+1},'%f'))';
                            nextLine = whichline+2;
                            while(~(command_output{nextLine}(1)=='#'))
                                ParValues = [ParValues cell2mat(textscan(command_output{nextLine},'%f'))']; %#ok<AGROW>
                                nextLine = nextLine+1;
                            end
                        end
                    elseif ParValues(1)=='<'
                        if ParValues(end)=='>'
                            ParValues = ParValues(2:end-1);
                        else
                            while(~(ParValues(end)=='>'))
                                ParValue00 = textscan(command_output{whichline},['##$' Parameter0 '= ' ParValues '%s']);
                                ParValues = [ParValues ' ' ParValue00{1}{1}]; %#ok<AGROW>
                            end
                            ParValues = ParValues(2:end-1);
                        end
                    end
                end
                ParValue0{i} = ParValues;
            else
                error(['Parameter ' Parameter0 ' not found.'])
            end
        end
        ParValues = ParValue0;
    else
        command = ['cd ' checkPath '/' FileName ' ; cat ' AcquOrProc ' ;'];
        command_output = ssh2_simple_command(Hostname, Username, Password,command);
        whichline = find(contains(command_output,['##$' Parameter '=']),1);
        if ~isempty(whichline)
            ParValues = cell2mat(textscan(command_output{whichline},['##$' Parameter '=%f']));
            if isempty(ParValues)
                ParValues = textscan(command_output{whichline},['##$' Parameter '=%s']);
                ParValues = ParValues{1}{1};
                if ParValues(1)=='('
                    if command_output{whichline+1}(1)=='<'
                        ParValues = textscan(command_output{whichline+1},'%s');
                        ParValues = ParValues{1}';
                        nextLine = whichline+2;
                        while(~(command_output{nextLine}(1)=='#'))
                            ParValue00 = textscan(command_output{nextLine},'%s');
                            ParValues = [ParValues ParValue00{1}']; %#ok<AGROW>
                            nextLine = nextLine+1;
                        end
                    else
                        ParValues = cell2mat(textscan(command_output{whichline+1},'%f'))';
                        nextLine = whichline+2;
                        while(~(command_output{nextLine}(1)=='#'))
                            ParValues = [ParValues cell2mat(textscan(command_output{nextLine},'%f'))']; %#ok<AGROW>
                            nextLine = nextLine+1;
                        end
                    end
                elseif ParValues(1)=='<'
                    if ParValues(end)=='>'
                        ParValues = ParValues(2:end-1);
                    else
                        while(~(ParValues(end)=='>'))
                            ParValue00 = textscan(command_output{whichline},['##$' Parameter '= ' ParValues '%s']);
                            ParValues = [ParValues ' ' ParValue00{1}{1}]; %#ok<AGROW>
                        end
                        ParValues = ParValues(2:end-1);
                    end
                end
            end
        else
            error(['Parameter ' Parameter ' not found.'])
        end
    end
end
end


