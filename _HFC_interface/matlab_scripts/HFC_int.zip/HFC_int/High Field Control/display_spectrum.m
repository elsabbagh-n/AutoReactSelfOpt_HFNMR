function h = display_spectrum(h,t_transfer)
% This function displays the outcome spectrum of each experiment ordered.
% Once they are acquired, the dataset are transfered to this PC. If the
% dataset are not yet acquired, it waits until they are to display them.

output = h.Experiment_Table(2:end,:);
if size(output,1)>0
    for i = 1:size(output,1)
        filePath = ['/opt/nmrdata/user/nmr/Nour/' char(output.Name(i)) '/'...
            num2str(output.ExpNo(i)) '/'];
        fileName = 'fid';
        desiredPath = ['C:\Users\elsabbagh-n\Documents\DataSet\' ...
            char(output.Name(i)) '\' num2str(output.ExpNo(i)) '\'];
        parent_folder = ['C:\Users\elsabbagh-n\Documents\DataSet\' ...
            char(output.Name(i)) '\'];        
        if ~isfolder(parent_folder)
            % create folders
            eval(['mkdir ''C:\Users\elsabbagh-n\Documents\DataSet\'' ' char(output.Name(i))])
            eval(['mkdir ''' parent_folder ''' ' num2str(output.ExpNo(i))])
            % transfer dataset
            Tr = transfer_from_spectro500(filePath,fileName,desiredPath);
            if Tr
                text_update = h.displ.list_box.String;
                t = char(datetime('now','Format','[HH:mm:ss]'));
                h.displ.list_box.String = char(text_update,sprintf([t '     Dataset of experiment n°'...
                    num2str(output.ExpNo(i)) ' have been acquired.']));drawnow
            else
                text_update = h.displ.list_box.String;
                t = char(datetime('now','Format','[HH:mm:ss]'));
                h.displ.list_box.String = char(text_update,sprintf([t '     Experiment n°'...
                    num2str(output.ExpNo(i)) ' running...']));drawnow
                while(Tr==0)
                    pause(0.1)
                    Tr = transfer_from_spectro500(filePath,fileName,desiredPath);
                end
                text_update = h.displ.list_box.String;
                t = char(datetime('now','Format','[HH:mm:ss]'));
                h.displ.list_box.String = char(text_update,[t '             Done.']);drawnow
            end
        else
            if ~isfolder(desiredPath)
                eval(['mkdir ''' parent_folder ''' ' num2str(output.ExpNo(i))])
                % transfer dataset
                Tr = transfer_from_spectro500(filePath,fileName,desiredPath);
                if Tr
                    text_update = h.displ.list_box.String;
                    t = char(datetime('now','Format','[HH:mm:ss]'));
                    h.displ.list_box.String = char(text_update,sprintf([t '     Dataset of experiment n°'...
                        num2str(output.ExpNo(i)) ' have been acquired.']));drawnow
                else
                    text_update = h.displ.list_box.String;
                    t = char(datetime('now','Format','[HH:mm:ss]'));
                    h.displ.list_box.String = char(text_update,sprintf([t '     Experiment n°'...
                        num2str(output.ExpNo(i)) ' running...']));drawnow
                    while(Tr==0)
                        pause(0.1)
                        Tr = transfer_from_spectro500(filePath,fileName,desiredPath);
                    end
                    text_update = h.displ.list_box.String;
                    t = char(datetime('now','Format','[HH:mm:ss]'));
                    h.displ.list_box.String = char(text_update,[t '             Done.']);drawnow
                end
            else
                % File's modification date and time
                FileInfo = dir([desiredPath fileName]);
                TimeStamp = FileInfo.date;
                TimeStamp(TimeStamp=='.') = ' ';
                D = textscan(TimeStamp,'%f-%s -%f %s');
                modTime = [char(output.Name(i)) ' ' D{end}{1}];
                modTime = datetime(modTime,'Format','yyMMdd HH:mm:ss');
                t_transfer.Format = 'yyMMdd HH:mm:ss';
                if modTime<t_transfer
                    % transfer dataset
                    name = char(output.Name(i));
                    Tr = transfer_from_spectro500(name,filePath,fileName,desiredPath,t_transfer);
                    if Tr
                        text_update = h.displ.list_box.String;
                        t = char(datetime('now','Format','[HH:mm:ss]'));
                        h.displ.list_box.String = char(text_update,sprintf([t '     Dataset of experiment n°'...
                            num2str(output.ExpNo(i)) ' have been acquired.']));drawnow
                    else
                        text_update = h.displ.list_box.String;
                        t = char(datetime('now','Format','[HH:mm:ss]'));
                        h.displ.list_box.String = char(text_update,sprintf([t '     Experiment n°'...
                            num2str(output.ExpNo(i)) ' running...']));drawnow
                        while(Tr==0)
                            pause(0.1)
                            Tr = transfer_from_spectro500(filePath,fileName,desiredPath);
                        end
                        text_update = h.displ.list_box.String;
                        t = char(datetime('now','Format','[HH:mm:ss]'));
                        h.displ.list_box.String = char(text_update,[t '             Done.']);drawnow
                    end
                else
                    text_update = h.displ.list_box.String;
                    t = char(datetime('now','Format','[HH:mm:ss]'));
                    h.displ.list_box.String = char(text_update,sprintf([t '     Dataset of experiment n°'...
                        num2str(output.ExpNo(i)) ' have been acquired.']));drawnow
                end
            end
        end
        % DataSet plot
        figure(h.displ.f(2))
        A = rbnmr(desiredPath);
        p = plotbnmr(A);
        xlim0 = xlim;ylim0 = ylim;
        xlim([min(min(p.XData),xlim0(1)) max(max(p.XData),xlim0(2))])
        ylim([min(min(p.YData),ylim0(1)) max(max(p.YData),ylim0(2))])
        drawnow
    end
end
end
