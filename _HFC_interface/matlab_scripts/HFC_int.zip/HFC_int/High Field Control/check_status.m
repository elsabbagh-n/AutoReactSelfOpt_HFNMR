function h = check_status(h,first)
% This function keeps a loop check on the status of the launched
% experiments, while investigating updated status text files.
%
% New update: it transfer the intrng file to dataset folder once created.

statusPath = '/opt/topspin3.6.2/prog/curdir/changer';
desiredPath = 'C:\Users\Ceisam_Mimm\Documents\MATLAB\status\';
if h.autoMode %% as test_status3
    Exp = h.Experiment_Table.ExpNo(2:end);
    if h.TSarea==1
        % Transfer the intrng file to the created dataset folder
        expList = Exp;
        expList = expList(~ismember(expList,h.intrngArchive)); % Exp not found yet
        if ~isempty(expList)
            FileName_intrng = char(h.Experiment_Table.Name(2));
            datasetPath_intrng = '/opt/nmrdata/user/nmr/Nour';
            waitCheck = 0;
            [dataset_folder_ready,allFound] = check_if_dataset_folder_created_spectro500...
                (FileName_intrng,datasetPath_intrng,expList,waitCheck);
            % Send intrng once experimental dataset folder is created
            %             desiredName_intrng = 'intrng';
            for i = 1:length(dataset_folder_ready)
                % copy intrng files
                PathAndFile2copy = '/home/nmr/Documents/Nour/intrng';
                cp_spectro500(PathAndFile2copy,FileName_intrng,...
                    datasetPath_intrng,dataset_folder_ready(i))
                %                 % intrng file transfer
                %                 transfer_to_spectro500(...
                %                     'C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\Post_Doc_codes',...
                %                     'intrng0',[datasetPath_intrng '/' FileName_intrng '/' ...
                %                     num2str(dataset_folder_ready(i)) '/pdata/1/'],desiredName_intrng)
                % Archive of experiments to those the intrng file was transferred
                h.intrngArchive = [h.intrngArchive dataset_folder_ready(i)];
            end
        else
            allFound = 1;
        end
    end
    if first==1 % first call for update check
        % Get the first status text file
        if h.test==0
            % get the status text file
            h.fileName = char(datetime('now','Format','MMMdd-yyyy'));
            h.fileName = get_status_from_spectro500(statusPath,h.fileName,desiredPath,first);
        else
            % indicate the status text file on this PC for tests
            h.fileName = 'May23-2022-1436-Nour.set';
            h.fileName = 'Test01-2022-0000-Nour.set';
        end
        
        % Update experiments' status once changes detected
        if isfield(h,'areaAdditionalList_Num')
            h.status = update_status_new(h.fileName,Exp,h.screen,h.autoMode,[],size(h.areaAdditionalList_Num,1));
        else
            h.status = update_status_new(h.fileName,Exp,h.screen,h.autoMode);
        end
        %fileName = h.fileName;screen = h.screen;autoMode = h.autoMode;
        
        % Busy until
        % IND_current = ones(size(h.status.st,1),1);%~([h.status.st{:,4}]');
        % BusyUntil = datetime('now','Format','dd/MM/yyyy HH:mm:ss')+sum(h.status.Durations(find(IND_current),1));
        % if h.screen==1
        %     position_ = [950 4 500 20];
        % else
        %     position_ = [905 4 500 20];
        % end
        % h.status.BusyText = uilabel(h.status.f,'Position',position_,...
        %     'FontSize',15,'Text',{['Busy until ' char(BusyUntil)]},'Enable','off','FontWeight','bold');
        drawnow
        
        if h.TSarea==1
            if allFound==0
                % Transfer the intrng file to the created dataset folder
                expList = Exp;
                expList = expList(~ismember(expList,h.intrngArchive)); % Exp not found yet
                if ~isempty(expList)
                    FileName_intrng = char(h.Experiment_Table.Name(2));
                    datasetPath_intrng = '/opt/nmrdata/user/nmr/Nour';
                    waitCheck = 0;
                    [dataset_folder_ready,allFound] = check_if_dataset_folder_created_spectro500...
                        (FileName_intrng,datasetPath_intrng,expList,waitCheck);
                    % Send intrng once experimental dataset folder is created
                    %                     desiredName_intrng = 'intrng';
                    for i = 1:length(dataset_folder_ready)
                        % copy intrng files
                        PathAndFile2copy = '/home/nmr/Documents/Nour/intrng';
                        cp_spectro500(PathAndFile2copy,FileName_intrng,...
                            datasetPath_intrng,dataset_folder_ready(i))
                        %                         % intrng file transfer
                        %                         transfer_to_spectro500(...
                        %                             'C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\Post_Doc_codes',...
                        %                             'intrng0',[datasetPath_intrng '/' FileName_intrng '/' ...
                        %                             num2str(dataset_folder_ready(i)) '/pdata/1/'],desiredName_intrng)
                        % Archive of experiments to those the intrng file was transferred
                        h.intrngArchive = [h.intrngArchive dataset_folder_ready(i)];
                    end
                else
                    allFound = 1;
                end
            end
        end
    else
        % Look out for status text file update
        if h.test==0
            D = dir([desiredPath '\' h.fileName]); % date of modification of the latest version of the status text file
            T1 = D.date(end-7:end); % time of modification
            t_old = datetime(T1,'Format','HH:mm:ss'); % change time format
            
            % Maintain check for updated (last input = 1)
            if h.JustRequestExp==0
                status_updated = check_if_status_updated_spectro500(h.fileName,statusPath,...
                    t_old,1);
                if status_updated==1
                    fprintf('\nChanges in status file detected\n')
                    % get the updated status text file
                    h.fileName = get_status_from_spectro500(statusPath,h.fileName,desiredPath,first);
                else
                    fprintf('\nNo changes in status file detected\n')
                    return
                end
            else
                h.fileName = char(datetime('now','Format','MMMdd-yyyy'));
                h.fileName = get_status_from_spectro500(statusPath,h.fileName,desiredPath,1);
            end
        end
        
        % Update experiments' status once changes detected
        if isfield(h,'areaAdditionalList_Num')
            h.status = update_status_new(h.fileName,Exp,h.screen,h.autoMode,h.status,size(h.areaAdditionalList_Num,1));
        else
            if h.JustRequestExp
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                %%%%%%%%%%%%  this condition has to be removed %%%%%%%%%%%%
                % To verify first at which stage these parameter are
                % changed, even when they should not ! For now, the
                % following lines re-initialize them
%                 h.status.st = num2cell([ones(size(h.status.st,1),2) zeros(size(h.status.st,1),3)]);
%                 h.status.table.Completed = h.status.table.Deleted;
            end
            h.status = update_status_new(h.fileName,Exp,h.screen,h.autoMode,h.status);
        end
        
        % % Busy until
        % IND_current = ones(size(h.status.st,1),1);%~([h.status.st{:,4}]');
        % BusyUntil = datetime('now','Format','dd/MM/yyyy HH:mm:ss')+sum(h.status.Durations(find(IND_current),1));
        % h.status.BusyText = h.status.text(6);
        % h.status.BusyText.Text = {['Busy until ' char(BusyUntil)]};
        % drawnow
        
        if h.TSarea==1
            if allFound==0
                % Transfer the intrng file to the created dataset folder
                expList = Exp;
                expList = expList(~ismember(expList,h.intrngArchive)); % Exp not found yet
                if ~isempty(expList)
                    FileName_intrng = char(h.Experiment_Table.Name(2));
                    datasetPath_intrng = '/opt/nmrdata/user/nmr/Nour';
                    waitCheck = 0;
                    [dataset_folder_ready,allFound] = check_if_dataset_folder_created_spectro500...
                        (FileName_intrng,datasetPath_intrng,expList,waitCheck);
                    % Send intrng once experimental dataset folder is created
                    %                     desiredName_intrng = 'intrng';
                    for i = 1:length(dataset_folder_ready)
                        % copy intrng files
                        PathAndFile2copy = '/home/nmr/Documents/Nour/intrng';
                        cp_spectro500(PathAndFile2copy,FileName_intrng,...
                            datasetPath_intrng,dataset_folder_ready(i))
                        %                         % intrng file transfer
                        %                         transfer_to_spectro500(...
                        %                             'C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\Post_Doc_codes',...
                        %                             'intrng0',[datasetPath_intrng '/' FileName_intrng '/' ...
                        %                             num2str(dataset_folder_ready(i)) '/pdata/1/'],desiredName_intrng)
                        % Archive of experiments to those the intrng file was transferred
                        h.intrngArchive = [h.intrngArchive dataset_folder_ready(i)];
                    end
                end
            end
        end
    end
    
    drawnow
    if h.test==0 && h.JustRequestExp==0
        while ~h.status.done
            %             pause(0.5)
            if h.test==0
                h.fileName = get_status_from_spectro500(statusPath,h.fileName,desiredPath,0);
            end
            if isfield(h,'areaAdditionalList_Num')
                h.status = update_status_new(h.fileName,Exp,h.screen,h.autoMode,h.status,size(h.areaAdditionalList_Num,1));
            else
                h.status = update_status_new(h.fileName,Exp,h.screen,h.autoMode,h.status);
            end
            % fileName = h.fileName;screen = h.screen;autoMode = h.autoMode;status = h.status;
            
            % % Busy until
            % IND_new = ~([h.status.st{:,4}]');
            % drawnow
            % if  ~isempty(find(IND_new,1)) && length(find(IND_new))<length(find(IND_current))
            %     clc
            %     fprintf(['\n\nOld : ' h.status.BusyText.Text])
            %     IND_current = IND_new;
            %     BusyUntil = datetime('now','Format','dd/MM/yyyy HH:mm:ss')+sum(h.status.Durations(find(IND_current),1));
            %     h.status.BusyText = h.status.text(6);
            %     h.status.BusyText.Text = ['Busy until ' char(BusyUntil)];
            %     fprintf(['\nNew : ' h.status.BusyText.Text])
            % end
            drawnow
            
            if h.TSarea==1
                if allFound==0
                    % Transfer the intrng file to the created dataset folder
                    expList = Exp;
                    expList = expList(~ismember(expList,h.intrngArchive)); % Exp not found yet
                    if ~isempty(expList)
                        FileName_intrng = char(h.Experiment_Table.Name(2));
                        datasetPath_intrng = '/opt/nmrdata/user/nmr/Nour';
                        waitCheck = 0;
                        [dataset_folder_ready,allFound] = check_if_dataset_folder_created_spectro500...
                            (FileName_intrng,datasetPath_intrng,expList,waitCheck);
                        % Send intrng once experimental dataset folder is created
                        %                         desiredName_intrng = 'intrng';
                        for i = 1:length(dataset_folder_ready)
                            % copy intrng files
                            PathAndFile2copy = '/home/nmr/Documents/Nour/intrng';
                            cp_spectro500(PathAndFile2copy,FileName_intrng,...
                                datasetPath_intrng,dataset_folder_ready(i))
                            %                             % intrng file transfer
                            %                             transfer_to_spectro500(...
                            %                                 'C:\Users\elsabbagh-n\Documents\MATLAB\NEScode\Post_Doc_codes',...
                            %                                 'intrng0',[datasetPath_intrng '/' FileName_intrng '/' ...
                            %                                 num2str(dataset_folder_ready(i)) '/pdata/1/'],desiredName_intrng)
                            % Archive of experiments to those the intrng file was transferred
                            h.intrngArchive = [h.intrngArchive dataset_folder_ready(i)];
                        end
                    end
                end
            end
        end
    end
    if h.JustRequestExp==0
        % Dialog print
        fprintf('\nAll inserted experiments are completed.\n')
    else
        fprintf('\nAll inserted experiments are requested.\n')
    end
    
else %% as test_status2 %% manual mode
    % Experiments in question
    if h.runStopped==0
        Exp = h.Experiment_Table_HoldOn.ExpNo;
    else
        Exp = h.Experiment_Table.ExpNo(2:end);
    end
    
    if first==1 % first call for update check
        % Get the first status text file
        if h.test==0
            % get the status text file
            h.fileName = char(datetime('now','Format','MMMdd-yyyy'));
            h.fileName = get_status_from_spectro500(statusPath,h.fileName,desiredPath,first);
        else
            % indicate the status text file on this PC for tests
            %         h.fileName = 'test_Mar24-2022-1815-Nour.set';
            %         h.fileName = 'Mar30-2022-1233-Nour.set';
            %         h.fileName = 'Mar30-2022-1146-Nour.set';
            %         h.fileName = 'Mar30-2022-1233-Nour.set';
            %         h.fileName = 'May23-2022-1527-Nour.set';
            h.fileName = 'May23-2022-1436-Nour.set';
            h.fileName = 'Test01-2022-0000-Nour.set';
        end
        
        % Update experiments' status once changes detected
        if isfield(h,'areaAdditionalList_Num')
            h.status = update_status_new(h.fileName,Exp,h.screen,h.autoMode,[],size(h.areaAdditionalList_Num,1));
        else
            h.status = update_status_new(h.fileName,Exp,h.screen,h.autoMode);
        end
    else
        % Look out for status text file update
        if h.test==0
            D = dir([desiredPath '\' h.fileName]); % date of modification of the latest version of the status text file
            T1 = D.date(end-7:end); % time of modification
            t_old = datetime(T1,'Format','HH:mm:ss'); % change time format
            
            % Maintain check for updated (last input = 1)
            status_updated = check_if_status_updated_spectro500(h.fileName,statusPath,...
                t_old,1);
            if status_updated==1
                %                 clc
                fprintf('Changes detected')
                %                 pause(5)
                % get the updated status text file
                h.fileName = get_status_from_spectro500(statusPath,h.fileName,desiredPath,first);
            else
                return
            end
        end
        
        % Update experiments' status once changes detected
        if isfield(h,'areaAdditionalList_Num')
            h.status = update_status_new(h.fileName,Exp,h.screen,h.autoMode,h.status,size(h.areaAdditionalList_Num,1));
        else
            h.status = update_status_new(h.fileName,Exp,h.screen,h.autoMode,h.status);
        end
    end
    
    % Deactivation of the Status Window handles
    drawnow
    h.status.button(1).Enable = 'off'; %Set area region
    h.status.button(2).Enable = 'off'; %Area calculation
    h.status.button(3).Enable = 'off'; %DONE
    h.status.uitextarea(1).Enable = 'off'; % region's lower bound
    h.status.uitextarea(2).Enable = 'off'; % region's larger bound
    h.status.uitextarea(3).Enable = 'off'; % exp number for region bounds set
    drawnow
    
    while ~h.status.done
        %         pause(0.5)
        if h.test==0
            h.fileName = get_status_from_spectro500(statusPath,h.fileName,desiredPath,0);
        end
        if isfield(h,'areaAdditionalList_Num')
            h.status = update_status_new(h.fileName,Exp,h.screen,h.autoMode,h.status,size(h.areaAdditionalList_Num,1));
        else
            h.status = update_status_new(h.fileName,Exp,h.screen,h.autoMode,h.status);
        end
        drawnow
    end
    
    % Activation of the Status Window handles
    h.status.button(1).Enable = 'on'; %Set area region
    h.status.button(2).Enable = 'on'; %Area calculation
    h.status.button(3).Enable = 'on'; %DONE
    h.status.uitextarea(1).Enable = 'on'; % region's lower bound
    h.status.uitextarea(2).Enable = 'on'; % region's larger bound
    h.status.uitextarea(3).Enable = 'on'; % exp number for region bounds set
    drawnow
    
    % Dialog print
    fprintf('\nAll inserted experiments are completed.\n')
end
end