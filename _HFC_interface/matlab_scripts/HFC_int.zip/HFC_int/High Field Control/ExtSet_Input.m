classdef ExtSet_Input < handle
    properties
        Holder                  double%%
        User                    char  %%             % to be popupmenu
        Title                   char    %optional
        Name                    char    %optional
        ExpNo                   double  %optional
        Experiment              char               % to be popupmenu
        %Method                  char    %optional  % to be popupmenu
        Imported                logical
        Parameters              char    %optional  % to be popupmenu
        Solvent                 char   %%
        %Barcode                 char
        %Locked                  logical
        Priority                logical
        ShimProgram             char    %optional  % to be popupmenu
        Night                   logical
        StartRun                logical  %%
        StopRun                 logical  %%
        NoSubmit                logical %%
        SubmitHolder            logical  %%
        Delete                  logical
        StartTime               logical
        ReferencePeak           logical
        AreaCalculation         logical
    end
    methods
        function set.Holder(obj,c)
            if isa(c,'double')
                obj.Holder = c;
            end
        end
        function set.User(obj,c)
            if isa(c,'char')
                obj.User = c;
            end
        end
        function set.Title(obj,c)
            if isa(c,'char')
                obj.Title = c;
            end
        end
        function set.Name(obj,c)
            if isa(c,'char')
                obj.Name = c;
            end
        end
        function set.ExpNo(obj,c)
            if isa(c,'double')
                obj.ExpNo = c;
            end
        end
        function set.Experiment(obj,c)
            if isa(c,'char')
                obj.Experiment = c;
            end
        end
        function set.Parameters(obj,c)
            if isa(c,'char')
                obj.Parameters = c;
            end
        end
        function set.Solvent(obj,c)
            if isa(c,'char')
                obj.Solvent = c;
            end
        end
%         function set.Locked(obj,c)
%             if isa(c,'logical')
%                 obj.Locked = c;
%             end
%         end
        function set.Priority(obj,c)
            if isa(c,'logical')
                obj.Priority = c;
            end
        end
        function set.NoSubmit(obj,c)
            if isa(c,'logical')
                obj.NoSubmit = c;
            end
        end
        function set.ShimProgram(obj,c)
            if isa(c,'char')
                obj.ShimProgram = c;
            end
        end
        function set.StartTime(obj,c)
            if isa(c,'logical')
                obj.StartTime = c;
            end
        end
        function set.StartRun(obj,c)
            if isa(c,'logical')
                obj.StartRun = c;
            end
        end
        function set.StopRun(obj,c)
            if isa(c,'logical')
                obj.StopRun = c;
            end
        end
        function set.SubmitHolder(obj,c)
            if isa(c,'logical')
                obj.SubmitHolder = c;
            end
        end
        function set.Delete(obj,c)
            if isa(c,'logical')
                obj.Delete = c;
            end
        end
%         function set.Barcode(obj,c)
%             if isa(c,'char')
%                 obj.Barcode = c;
%             end
%         end
        function set.Imported(obj,c)
            if isa(c,'logical')
                obj.Imported = c;
            end
        end
%         function set.Method(obj,c)
%             if isa(c,'char')
%                 obj.Method = c;
%             end
%         end
        function set.Night(obj,c)
            if isa(c,'logical')
                obj.Night = c;
            end
        end
        function set.ReferencePeak(obj,c)
            if isa(c,'logical')
                obj.ReferencePeak = c;
            end
        end
        function set.AreaCalculation(obj,c)
            if isa(c,'logical')
                obj.AreaCalculation = c;
            end
        end
    end
end