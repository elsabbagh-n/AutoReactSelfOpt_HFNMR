function h = modify_entries(h)
% This function modifies the entries.

if ~isempty(h.list_box(2).String)
    ind = split(h.list_box(2).String{h.list_box(2).Value},filesep);
    ind = str2double(ind{1});
    n_table = find(h.Experiment_Table.Index==ind);
    delete_status_before = h.Experiment_Table.Delete(n_table);
    [~,d] = ismember({'delete'},lower(h.checkList(:,1)));
    if d
        if ~h.check_box(h.checkList{d,5}).Value...
                && delete_status_before
            h = exp_nb_update(h);
        else
            if ~h.check_box(h.checkList{d,5}).Value...
                    && ~delete_status_before
                [~,a] = ismember({'expno'},lower(h.checkList(:,1)));
                if a
                    h.editable_text_field(h.checkList{a,3}).String =...
                        num2str(h.Experiment_Table.ExpNo(n_table));
                end
            end
        end
        if h.check_box(h.checkList{d,5}).Value
            [~,a] = ismember({'expno'},lower(h.checkList(:,1)));
            if a
                h.editable_text_field(h.checkList{a,3}).String = '0';
            end
        end
    end
    for i = 2:size(h.Experiment_Table,2)-1
        if ismember(lower(h.Experiment_Table.Properties.VariableNames(i)),...
                {'parameters'})
            if ~isempty(h.list_box(1).String)
                if size(h.list_box(1).String,1)==1
                    param = split(h.list_box(1).String,' = ');
                    ind = find(param{1,1}=='[',1);
                    if ~isempty(ind)
                        param{1,1} = param{1,1}(1:ind-2);
                    end
                else
                    param = split(h.list_box(1).String,' = ');
                    for j = 1:size(param,1)
                        ind = find(param{j,1}=='[',1);
                        if ~isempty(ind)
                            param{j,1} = param{j,1}(1:ind-2);
                        end
                    end
                end
                h.Experiment_Table.Parameters(n_table) = join(join...
                    (string(param),','),',',1);
            else
                h.Experiment_Table.Parameters(n_table) = missing;
            end
            continue
        end
        if ismember(lower(h.Experiment_Table.Properties.VariableNames(i)),...
                {'starttime'})
            [~,d] = ismember(lower(...
                h.Experiment_Table.Properties.VariableNames(i)),...
                lower(h.checkList(:,1)));
            if d
                check = cell2mat(h.checkList(d,2:end));
                eval(['t = h.check_box('...
                    num2str(check(4)) ').Value;'])
                eval(['h.Experiment_Table.' h.checkList{d,1}...
                    '(n_table) = t;'])
                if t
                    h.Experiment_Table.Date(n_table) = ...
                        h.calendar.static_text_field(1).String;
                    %                     h.Experiment_Table.Date(n_table) = char(h.calendar.d(1).Value);
                else
                    h.Experiment_Table.Date(n_table) = '';
                end
            end
            continue
        end
        [~,d] = ismember(lower(...
            h.Experiment_Table.Properties.VariableNames(i)),...
            lower(h.checkList(:,1)));
        if d
            check = cell2mat(h.checkList(d,2:end));
            if check(4)==0
                if check(3)==0 %it is an insert text
                    eval(['h.Experiment_Table.' h.checkList{d,1}...
                        '(n_table) = string(h.editable_text_field('...
                        num2str(check(2)) ').String);'])
                else %it is a popup menu
                    popup_menu_list = h.popup_menu(check(3),1).String; %#ok<NASGU>
                    eval(['h.Experiment_Table.' h.checkList{d,1}...
                        '(n_table) = string(popup_menu_list(h.popup_menu('...
                        num2str(check(3)) ').Value));'])
                end
            else %it is a check box then
                eval(['h.Experiment_Table.' h.checkList{d,1}...
                    '(n_table) = h.check_box('...
                    num2str(check(4)) ').Value;'])
            end
        end
    end
    if h.Experiment_Table.Delete(n_table)
        h.Experiment_Table.ExpNo(n_table) = 0;
        h.Experiment_Table.StartRun(n_table) = 0;
        h.Experiment_Table.StopRun(n_table) = 0;
        tag = [num2str(h.Experiment_Table.Index(n_table))...
            '\Delete holder°',num2str(h.Experiment_Table.Holder(n_table))];
    else
        % 'Index\ExpNo\Solvent\Experiment\Parameters'
        tag = char(fullfile(num2str(h.Experiment_Table.Index(n_table)),...
            ['Exp°',num2str(h.Experiment_Table.ExpNo(n_table))],...
            h.Experiment_Table.Solvent(n_table),...
            h.Experiment_Table.Experiment(n_table),...
            h.Experiment_Table.Parameters(n_table)));
    end
    h.list_box(2).String{h.list_box(2).Value} = tag;
    h = prioriry_update(h);
    
end
end
