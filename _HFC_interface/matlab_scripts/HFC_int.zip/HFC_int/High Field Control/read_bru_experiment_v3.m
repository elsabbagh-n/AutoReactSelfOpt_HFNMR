function A = read_bru_experiment_v3(PathName,fidOK,spectOK)
%
% read bruker experiment and saved processed data
%

%% read various parameter files

%%%%% NES: lines below cannot be executed : 'mexldr' function does not exist
% jdxfiles = {'proc' 'procs' 'proc2' 'proc2s'...
%     'acqu' 'acqus' 'acqu2' 'acqu2s'...
%     'acqp' 'method' 'scon2' 'visu_pars'};

% for fn=jdxfiles
%     filename = [PathName '\' fn{1}];
%     if exist(filename, 'file')==2
%         % matlab is stupid, this expands tildes in filenames:
%         blah = fopen(filename);
%         filename = fopen(blah);
%         fclose(blah);
%         A.(fn{1}) = mexldr(filename);
%         %disp(sprintf('loaded %s', filename));
%     end
% end
%%%%% NES: lines above cannot be executed : 'mexldr' function does not exist

%%%%% NES: lines below are added by NES
% PathName = 'C:\Users\nelsabbagh\Desktop\Sodium\données 9.4T\210319_NES_DQF23Na_NaCl\20';
% PathName = [ePath,num2str(expNb_DQ_tau(1))];fidOK=1;spectOK=1;
% PathName = [ePath,num2str(expNb_SQ(stdy))];fidOK=1;spectOK=1;
% PathName = [ePath,num2str(expNb_CPMG(stdy))];fidOK=1;spectOK=1;

filename = [PathName '\proc2s'];
if exist(filename, 'file')==2
    AA = regexp(fileread(filename),'\n','split')';
    whichline = find(contains(AA,'##$SI='),1);
    A.SI      = cell2mat(textscan(AA{whichline},'##$TD=%f'));
else
    filename = [PathName '\pdata\1\proc2s'];
    if exist(filename, 'file')==2
        AA = regexp(fileread(filename),'\n','split')';
        whichline = find(contains(AA,'##$SI='),1);
        A.SI      = cell2mat(textscan(AA{whichline},'##$SI=%f'));
        whichline = find(contains(AA,'##$XDIM='),1);
        A.XDIM    = cell2mat(textscan(AA{whichline},'##$XDIM=%f'));
    end
end

filename = [PathName '\acqus'];
if exist(filename, 'file')==2
    AA = regexp(fileread(filename),'\n','split')';
    whichline = find(contains(AA,'##$TD='),1);
    A.TD(1)   = cell2mat(textscan(AA{whichline},'##$TD=%f'));
    whichline = find(contains(AA,'##$SW='),1);
    A.SW_ppm  = cell2mat(textscan(AA{whichline},'##$SW=%f'));
    whichline = find(contains(AA,'##$SW_h='),1);
    A.SW_Hz   = cell2mat(textscan(AA{whichline},'##$SW_h=%f'));
    whichline = find(contains(AA,'##$BF1='),1);
    A.BaseFreq_ppm = cell2mat(textscan(AA{whichline},'##$BF1=%f'));
    whichline = find(contains(AA,'##$NS='),1);
    A.NS = cell2mat(textscan(AA{whichline},'##$NS=%f'));
end

filename = [PathName '\procs'];
if exist(filename, 'file')==2
    AA = regexp(fileread(filename),'\n','split')';
    whichline = find(contains(AA,'##$NC_proc='),1);
    A.NC_proc = cell2mat(textscan(AA{whichline},'##$NC_proc=%f'));
    whichline = find(contains(AA,'##$TDeff='),1);
    A.TDeff = cell2mat(textscan(AA{whichline},'##$TDeff=%f'));
    whichline = find(contains(AA,'##$FTSIZE='),1);
    A.FTsize = cell2mat(textscan(AA{whichline},'##$FTSIZE=%f'));
%     whichline = find(contains(AA,'##$F1P='),1);
%     A.AxesLimitppm(1) = cell2mat(textscan(AA{whichline},'##$F1P=%f'));%low field limit of spectrum
%     whichline = find(contains(AA,'##$F2P='),1);
%     A.AxesLimitppm(2) = cell2mat(textscan(AA{whichline},'##$F2P=%f'));%high field limit of spectrum
    whichline = find(contains(AA,'##$OFFSET='),1);
    A.AxesLimitppm(1) = cell2mat(textscan(AA{whichline},'##$OFFSET=%f'));%High field limit of spectrum
    A.AxesLimitppm(2) = A.AxesLimitppm(1) - A.SW_ppm;%Low field limit of spectrum
else
    filename = [PathName '\pdata\1\procs'];
    if exist(filename, 'file')==2
        AA = regexp(fileread(filename),'\n','split')';
        whichline = find(contains(AA,'##$NC_proc='),1);
        A.NC_proc = cell2mat(textscan(AA{whichline},'##$NC_proc=%f'));
        whichline = find(contains(AA,'##$TDeff='),1);
        A.TDeff = cell2mat(textscan(AA{whichline},'##$TDeff=%f'));
        whichline = find(contains(AA,'##$FTSIZE='),1);
        A.FTsize = cell2mat(textscan(AA{whichline},'##$FTSIZE=%f'));
%         whichline = find(contains(AA,'##$F1P='),1);
%         A.AxesLimitppm(1) = cell2mat(textscan(AA{whichline},'##$F1P=%f'));%low field limit of spectrum
%         whichline = find(contains(AA,'##$F2P='),1);
%         A.AxesLimitppm(2) = cell2mat(textscan(AA{whichline},'##$F2P=%f'));%high field limit of spectrum
        whichline = find(contains(AA,'##$OFFSET='),1);
        A.AxesLimitppm(1) = cell2mat(textscan(AA{whichline},'##$OFFSET=%f'));%High field limit of spectrum
        A.AxesLimitppm(2) = A.AxesLimitppm(1) - A.SW_ppm;%Low field limit of spectrum
    end
end

filename = [PathName '\acqu2s'];
if exist(filename, 'file')==2
    AA = regexp(fileread(filename),'\n','split')';
    whichline = find(contains(AA,'##$TD='),1);
    A.TD(2)   = cell2mat(textscan(AA{whichline},'##$TD=%f'));
end

filename = [PathName '\acqu'];
if exist(filename, 'file')==2
    AA = regexp(fileread(filename),'\n','split')';
    whichline = find(contains(AA,'##$NS='),1);
    A.NS      = cell2mat(textscan(AA{whichline},'##$NS=%f'));

    whichline1 = find(contains(AA,'##$D='),1);
    whichline2 = find(contains(AA,'##$DATE='),1);
    A.D = 0;
    for i = whichline1+1:whichline2-1
        d = cell2mat(textscan(AA{i},'%f'));
        A.D(end+1:end+length(d),1) = d;
    end
    A.D = A.D(3:25);
    
    whichline1 = find(contains(AA,'##$L='),1);
    whichline2 = find(contains(AA,'##$LFILTER='),1);
    A.L = 0;
    for i = whichline1+1:whichline2-1
        l = cell2mat(textscan(AA{i},'%f'));
        A.L(end+1:end+length(l),1) = l;
    end
    A.L = A.L(3:15);
end
%%%%% NES: lines above are added by NES

%% read the processed data files\directoies

pdatapath = [PathName '\pdata\'];
pdatadirs = dir(pdatapath);

isOctave = exist('OCTAVE_VERSION', 'builtin') ~= 0;
if isOctave
    if compare_versions (version,'4.4.0','>=')
        hasContainers = 1;
    else
        hasContainers = 0;
    end
else
    hasContainers = 1;
end

if isempty(pdatadirs)==0
    if hasContainers
        A.pdata = containers.Map('KeyType','int32','ValueType','any');
    else
        A.pdata = struct();
    end
end

for jj=3:length(pdatadirs)
    % 1...N
    pdatanum = str2double(pdatadirs(jj).name);
    procpath = [pdatapath pdatadirs(jj).name];
    if ~isfolder(procpath) || isempty(pdatanum)
        continue;
    end
    try
        if hasContainers
            A.pdata(pdatanum) = read_bru_experiment_v2(procpath);
        else
            A.pdata.(num2str(pdatanum)) = read_bru_experiment_v2(procpath);
        end
    catch err
        %         fprintf('couldnt read %s\n', procpath);
        %         err;
                err.stack(:).file;
                err.stack(:).line;
        break;
    end
end

%% read the raw fid data

if fidOK
    if exist([PathName '\fid'],'file')
        fpre = fopen([PathName '\fid'],'r');
        A.fid = fread(fpre,'int32','l');
        A.fid = A.fid(1:2:end) - 1i * A.fid(2:2:end);
        fclose(fpre);
        % adding time axis values in seconds
        A.fidAxis = linspace(0,1/A.SW_Hz/2*A.TD(1),A.TD(1)/2);
    elseif exist([PathName '\ser'],'file')
        fpre = fopen([PathName '\ser'],'r');
        A.fid = fread(fpre,'int32','l');
        A.fid = A.fid(1:2:end) - 1i * A.fid(2:2:end);
        if isfield(A, 'TD')
            A.fid = reshape(A.fid, A.TD(1)/2, []);
        end
        fclose(fpre);
        % adding time axis values in seconds
        A.fidAxis = linspace(0,1/A.SW_Hz/2*A.TD(1),A.TD(1)/2)';
    end
end

%% read the raw spectra data

if spectOK
    % look for proc folder in pdata
    AvFol = dir([PathName '\pdata\']);%AvFol = {AvFol.name}';AvFol(1:2) = [];
    AvFolNum = zeros(length(AvFol)-2,1);
    ind = 1;
    for i = 1:length(AvFol)
        if ismember(AvFol(i).name,{'.','..'})
            continue
        end
        AvFolNum(ind) = str2double(AvFol(i).name);
        ind = ind+1;
    end
    AvFolNum = sort(AvFolNum,'ascend');
    for i = 1:length(AvFolNum)
        if exist([PathName '\pdata\' num2str(AvFolNum(i)) '\1r'],'file')
            fpre = fopen([PathName '\pdata\' num2str(AvFolNum(i)) '\1r'],'r');
            fpim = fopen([PathName '\pdata\' num2str(AvFolNum(i)) '\1i'],'r');
            Sp = fread(fpre,'int32') + 1i * fread(fpim,'int32');
            % scale the spectrum according to NC_proc (going from 32-bit int to 64-bit double anyway)
            Sp = Sp .* (2^A.NC_proc);
            fclose(fpre);
            fclose(fpim);
            % Store spectrum
            if ~isfield(A,'spec1D_proc')
                A.spec1D_proc = Sp;
                % adding frequency axis values
                A.spec1DAxis = linspace(A.AxesLimitppm(1),A.AxesLimitppm(2),A.FTsize)';%ppm
            else
                A.spec1D_proc(:,end+1) = Sp;
            end
        elseif exist([PathName '\pdata\' num2str(AvFolNum(i)) '\2rr'],'file')
            fpre = fopen([PathName '\pdata\' num2str(AvFolNum(i)) '\2rr'],'r');
            fpim = fopen([PathName '\pdata\' num2str(AvFolNum(i)) '\2ii'],'r');
            A.spec2D = fread(fpre,'int32') + 1i * fread(fpim,'int32');
            % scale the spectrum according to NC_proc (going from 32-bit int to 64-bit double anyway)
            A.spec2D = A.spec2D .* (2^A.NC_proc);
            fclose(fpre);
            fclose(fpim);
            %new
            clear S4
            S4 = zeros(A.FTsize,A.SI);
            if(A.XDIM/A.SI==1)
                for k = 1:A.XDIM
                    S4(:,k) = A.spec2D(1+(k-1)*A.FTsize:k*A.FTsize);
                end
                A.spec1D = S4(:,1:A.TD(2));
            else
                for k = 1:A.XDIM
                    SS  = A.spec2D(1+(k-1)*A.FTsize*A.XDIM:k*A.FTsize*A.XDIM);
                    pas = A.FTsize/A.XDIM;
                    for j = 1:A.XDIM
                        for i = 1:A.XDIM
                            S4(1+(j-1)*pas:j*pas,i+(k-1)*A.XDIM) = SS(1+(i-1+(j-1)*A.XDIM)*pas...
                                :((j-1)*A.XDIM+i)*pas,1);
                        end
                    end
                end
                A.spec2D = S4(:,1:A.TD(2));
            end
            % adding frequency axis values
            A.spec2DAxis = linspace(A.AxesLimitppm(1),A.AxesLimitppm(2),A.FTsize)';%ppm
        end
    end
end

if exist([PathName '\title'],'file')
    fp = fopen([PathName '\title'],'r');
    A.title = fread(fp, 'int8=>char')';
    fclose(fp);
end

if exist([PathName '\pulseprogram'],'file')
    fp = fopen([PathName '\pulseprogram'],'r');
    A.title = fread(fp, 'int8=>char')';
    fclose(fp);
end

if exist([PathName '\vdlist'],'file')
    A.vdlist = read_bru_delaylist([PathName '\vdlist']); %in s
end

if exist([PathName '\vclist'],'file')
    A.vclist = read_bru_delaylist([PathName '\vclist']); %counter
end

%%
%%%%% NES: lines below cannot be executed : 'mexldr' function does not exist
% for FILE = {'acqus' 'procs'}
%     if ~isfield(A,FILE{1}) || ~isfield(A,'DATE')
%         continue
%     end
%     %% Add acq-date
%     % Converts time given in UTC (base 1970, seconds) as matlab serial time
%     % (base 0000, days)
%     TZ = str2double(regexp(A.(FILE{1}).Stamp,'UT(.\d+)h','tokens','once'));
%     if isempty(TZ); TZ = 2; end;	% Assume UT+2h if not in stamp-field
%     A.Info.AcqSerialDate = A.(FILE{1}).DATE\(60*60*24)+datenum([1970 01 01])+TZ\24;
%     A.Info.AcqDateTime = datestr(A.Info.AcqSerialDate);
%     A.Info.AcqDate = datestr(A.Info.AcqSerialDate,'yyyy-mm-dd');
%     % Convert serial date to text to keep format
%     A.Info.AcqSerialDate = sprintf('%.12f',A.Info.AcqSerialDate);
%
%     %% Add plotlabel from A.(FILE{1}).Stamp-info
%     q = regexp(A.(FILE{1}).Stamp,'data[\\\].+[\\\]nmr[\\\](.+)[\\\](\d+)[\\\]acqus','tokens');
%     if isempty(q)	% New, more relaxed, data path
%         q = regexp(A.(FILE{1}).Stamp,'#.+[\\\](.+)[\\\](\d+)[\\\]acqus','tokens');
%     end
%     if isempty(q)
%         A.Info.PlotLabel = ['[',A.Info.FilePath,']'];
%     else
%         A.Info.PlotLabel = ['[',q{1}{1},':',q{1}{2},']'];
%     end
% end
%%%%% NES: lines above cannot be executed : 'mexldr' function does not exist



