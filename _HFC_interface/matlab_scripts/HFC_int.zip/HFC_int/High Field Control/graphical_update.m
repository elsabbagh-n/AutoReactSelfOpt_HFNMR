function status = graphical_update(status,stage,running)


%% Stage 1 & 2
% BackgroundColor
Package_On  = [0.89,1.00,0.89];
Package_Off = [0.94,0.94,0.94];
Action_On  = [0.51,1.00,0.51];
Action_Off = [0.80,0.80,0.80];
Arrow_On  = [0.19,1.00,0.19];
Arrow_Off = [0,0,0];
Automation_OFF = [1.00,0.41,0.41];

if ismember(stage(1),[1 2])
    % ON
    % Create experiment in Matlab
    status.graphical_application_update.panel(1).BackgroundColor = Package_On; % MATLAB package
    status.graphical_application_update.text(1).BackgroundColor = Action_On; % Creation action
    % Transfer list of created experiment in Matlab
    status.graphical_application_update.text(11).BackgroundColor = Action_On; % Request Transfer
    status.graphical_application_update.pathway(1).Color = Arrow_On; % Transfer Creation arrow
else
    % OFF
    % Create experiment in Matlab
    status.graphical_application_update.panel(1).BackgroundColor = Package_Off; % MATLAB package
    status.graphical_application_update.text(1).BackgroundColor = Action_Off; % Creation action
    % Transfer list of created experiment in Matlab
    status.graphical_application_update.text(11).BackgroundColor = Action_Off; % Request Transfer
    status.graphical_application_update.pathway(1).Color = Arrow_Off; % Transfer Creation arrow
end
%% Stage 3

if ismember(stage(1),3)
    % ON
    % Add experiment in IconNMR
    status.graphical_application_update.panel(2).BackgroundColor = Package_On; % IconNMR package
    status.graphical_application_update.text(5).BackgroundColor = Action_On; % Add experiment
    status.graphical_application_update.pathway(4).Color = Arrow_On; % Add experiment line
else
    % OFF
    % Add experiment in IconNMR
    status.graphical_application_update.panel(2).BackgroundColor = Package_Off; % IconNMR package
    status.graphical_application_update.text(5).BackgroundColor = Action_Off; % Add experiment
    status.graphical_application_update.pathway(4).Color = Arrow_Off; % Add experiment line
end
%% Stage 4 & 5

if ismember(stage(1),[4 5])
    % ON
    % Start automation in MATLAB
    status.graphical_application_update.panel(1).BackgroundColor = Package_On; % IconNMR package
    status.graphical_application_update.text(2).BackgroundColor = Action_On; % Start automation
    % Transfer Start requested in MATLAB
    status.graphical_application_update.text(11).BackgroundColor = Action_On; % Request Transfer
    status.graphical_application_update.pathway(2).Color = Arrow_On; % Transfer start arrow
else
    % OFF
    % Start automation in MATLAB
    status.graphical_application_update.panel(1).BackgroundColor = Package_Off; % IconNMR package
    status.graphical_application_update.text(2).BackgroundColor = Action_Off; % Start automation
    % Transfer Start requested in MATLAB
    status.graphical_application_update.text(11).BackgroundColor = Action_Off; % Request Transfer
    status.graphical_application_update.pathway(2).Color = Arrow_Off; % Transfer start arrow
end
%% Stage 6

if ismember(stage(1),6)
    % ON
    % Automation launched in IconNMRh.graphical_application_update.panel(2).BackgroundColor = Package_On; % IconNMR package
    status.graphical_application_update.text(6).BackgroundColor = Action_On; % Automation launched
    status.graphical_application_update.pathway(5).Color = Arrow_On; % Automation launched line
    status.running = 1; % Automation ON
else
    % OFF
    % Automation launched in IconNMRh.graphical_application_update.panel(2).BackgroundColor = Package_Off; % IconNMR package
    status.graphical_application_update.text(6).BackgroundColor = Action_Off; % Automation launched
    status.graphical_application_update.pathway(5).Color = Arrow_Off; % Automation launched line
end
%% Stage 7

if ismember(stage(1),7)
    % ON
    % Acquisition in progress in IconNMR
    status.graphical_application_update.panel(2).BackgroundColor = Package_On; % IconNMR package
    status.graphical_application_update.text(9).BackgroundColor = Action_On; % Acquisition in progress
    status.graphical_application_update.pathway(7).Color = Arrow_On; % Acquisition in progress line
else
    % OFF
    % Acquisition in progress in IconNMR
    status.graphical_application_update.panel(2).BackgroundColor = Package_Off; % IconNMR package
    status.graphical_application_update.text(9).BackgroundColor = Action_Off; % Acquisition in progress
    status.graphical_application_update.pathway(7).Color = Arrow_Off; % Acquisition in progress line
end
%% Stage 8

if ismember(stage(1),8)
    % ON
    % Acquisition finished in IconNMR
    status.graphical_application_update.panel(2).BackgroundColor = Package_On; % IconNMR package
    status.graphical_application_update.text(10).BackgroundColor = Action_On; % Acquisition finished
else
    % OFF
    % Acquisition finished in IconNMR
    status.graphical_application_update.panel(2).BackgroundColor = Package_Off; % IconNMR package
    status.graphical_application_update.text(10).BackgroundColor = Action_Off; % Acquisition finished
end
%% Stage 9

if ismember(stage(1),9)
    % ON
    % Transfer Dataset
    status.graphical_application_update.text(12).BackgroundColor = Action_On; % Dataset Transfer
    status.graphical_application_update.pathway(8).Color = Arrow_On; % Transfer Dataset arrow
else
    % OFF
    % Transfer Dataset
    status.graphical_application_update.text(12).BackgroundColor = Action_Off; % Dataset package
    status.graphical_application_update.pathway(8).Color = Arrow_Off; % Transfer Dataset arrow
end
%% Stage 10

if ismember(stage(1),10)
    % ON
    % Area calculation in MATLAB
    status.graphical_application_update.panel(1).BackgroundColor = Package_On; % IconNMR package
    status.graphical_application_update.text(4).BackgroundColor = Action_On; % Area calculation
else
    % OFF
    % Area calculation in MATLAB
    status.graphical_application_update.panel(1).BackgroundColor = Package_Off; % IconNMR package
    status.graphical_application_update.text(4).BackgroundColor = Action_Off; % Area calculation
end
%% Stage 11 & 12

if ismember(stage(1),[11 12])
    % ON
    % Stop automation in MATLAB
    status.graphical_application_update.panel(1).BackgroundColor = Package_On; % IconNMR package
    status.graphical_application_update.text(3).BackgroundColor = Automation_OFF; % Stop automation
    % Transfer Stop requested in MATLAB.
    status.graphical_application_update.text(11).BackgroundColor = Action_On; % Request Transfer
    status.graphical_application_update.pathway(3).Color = Automation_OFF; % Transfer stopp arrow
else
    % OFF
    % Stop automation in MATLAB
    status.graphical_application_update.panel(1).BackgroundColor = Package_Off; % IconNMR package
    status.graphical_application_update.text(3).BackgroundColor = Action_Off; % Stop automation
    % Transfer Stop requested in MATLAB
    status.graphical_application_update.text(11).BackgroundColor = Action_Off; % Request Transfer
    status.graphical_application_update.pathway(3).Color = Arrow_Off; % Transfer stopp arrow
end
%% Stage 13

if ismember(stage(1),13)
    % ON
    % Automation stopped in IconNMR
    status.graphical_application_update.panel(2).BackgroundColor = Package_On; % IconNMR package
    status.graphical_application_update.text(7).BackgroundColor = Automation_OFF; % Automation stopped
    status.running = 0; % Automation OFF
else
    % OFF
    % Automation stopped in IconNMR
    status.graphical_application_update.panel(2).BackgroundColor = Package_Off; % IconNMR package
    status.graphical_application_update.text(7).BackgroundColor = Action_Off; % Automation stopped
end

%%

if running
    status.graphical_application_update.text(13).BackgroundColor = Action_On;
    status.graphical_application_update.text(14).BackgroundColor = Action_Off;
    status.graphical_application_update.pathway(6).Color = Arrow_On;
else
    status.graphical_application_update.text(13).BackgroundColor = Action_Off;
    status.graphical_application_update.text(14).BackgroundColor = Automation_OFF;
    status.graphical_application_update.pathway(6).Color = Automation_OFF;
end


%% Stage

% ON


% OFF



%%