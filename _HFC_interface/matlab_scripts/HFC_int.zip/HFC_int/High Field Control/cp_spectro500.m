function cp_spectro500(PathAndFile2copy,FileName_intrng,datasetPath_intrng,expList)
% This function copies files on the remote computer.
% Hostname, Username and Password are set to the those of Spectro500.
%
% No file transfer !
%
% Input
% FileName                Name of the folder to be created
% datasetPath             Path of folder to be created on the remote PC
% expList                 Requested experiments list

% PathAndFile2copy = '/home/documents/Nour';
% FileName = char(h.Experiment_Table.Name(2));
% datasetPath = '/opt/nmrdata/user/nmr/Nour';
% expList = 1;
%% User Input

% Required information about the remote PC (spectro 500MHz)
Hostname = '172.16.77.57';
Hostname = 'RMN500-1525.ceisam.sciences.univ-nantes.prive';
Username = 'nmr';
Password = 'topspin';

%% Dataset folder creation check
% Copy file
[~,nme] = fileparts(PathAndFile2copy);
for i = 1:length(expList)
    command = ['cp ' PathAndFile2copy ' ' ...
        datasetPath_intrng '/' FileName_intrng '/' num2str(expList(i)) ...
        '/pdata/1/' nme ' ;'];
    ssh2_simple_command(Hostname, Username, Password,command);
end
fprintf('\nFile copy done successfully.\n')
pause(1)
end


