function h = prioriry_update(h)
% If a new experiment is created, using the button Update (Edit Input
% Panel) with the Priority box checked (Required Input Panel), this
% function makes sure that this experiment is on the head of the list, so
% that it is firstly run.

if ~isempty(h.list_box(2).String)
    n_table = size(h.Experiment_Table,1);
    if h.Experiment_Table.Priority(n_table)
        h.Experiment_Table.Priority =...
            zeros(size(h.Experiment_Table.Priority));
        h.Experiment_Table.Priority(n_table) = 1;
        while (find(h.Experiment_Table.Priority)~=2)
            h = exp_lift(h,1);
        end
    end
    if sum(h.Experiment_Table.Priority)==0
        h.Experiment_Table.Priority(2) = 1;
    end
end
end
