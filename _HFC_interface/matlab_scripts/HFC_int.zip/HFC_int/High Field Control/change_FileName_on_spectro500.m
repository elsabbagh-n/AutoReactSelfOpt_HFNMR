function change_FileName_on_spectro500(statusPath,old,new)
% This function only changes the name of files on a remote PC.
%
% Input
% statusPath      Path of the file to be renamed on the remote PC
% old             Old name on the remote PC
% new             Desired new name on the remote PC

%% User Input

% Required information about the remote PC (spectro 500MHz)
Hostname = '172.16.77.57';
Hostname = 'RMN500-1525.ceisam.sciences.univ-nantes.prive';
Username = 'nmr';
Password = 'topspin';

%% Make a copy of the status file

% Get the list of status files
command = ['cd ' statusPath ' ; ls'];
command_output = ssh2_simple_command(Hostname, Username, Password,command);
% Get the ones with the closest naming
s = startsWith(command_output,old(1:end-4));
command_output = command_output(s);
% Get the latest number
clearvars n
for i = 1:length(find(s))
    j = textscan(command_output{i},[old(1:end-4) '%[^.].set']);
    if ~isempty(j{1})
        n(i) = str2double(j{1}{1});
    else
        n(i) = 0;
    end
end
% Make a copy of the original status file and renaming it
if isempty(new)
    command = ['cd ' statusPath ' ; cp ' old ' ' old(1:end-4)...
        num2str(max(n+1)) '.set'];
else
    command = ['cd ' statusPath ' ; cp ' old ' ' new];
end
[~] = ssh2_simple_command(Hostname, Username, Password,command);
end






