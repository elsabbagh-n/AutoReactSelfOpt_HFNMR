function h = exp_create(varargin)
% This function creates the experiment with the inserted information. It is
% also called when the user wants to duplicate an already saved experiment.
% So it will display the information of the selected experiment to be 
% dubplicated, update the number of the experiment, and copy the other
% information.

if ~size(varargin,2)==0
    if size(varargin,2)==1
        if isa(varargin{1},'struct')
            h = varargin{1};
            go = 1; % Creating an experiment
        else
            warning('The fist input should be of type struct.')
            go = 0; % error input
        end
    else
        if isa(varargin{1},'struct') && isa(varargin{2},'double')
            h = varargin{1};
            ind = varargin{2};
            go = 2; % Duplicating an experiment
        else
            warning(['The input should be of type [struct,double] '...
                'respectively.'])
            go = 0; % error input
        end
    end
else
    warning(['No input detected. At least one input of type struct should '...
        'be given.'])
    go = -1; % error input
end
if go~=-1
    n_table = size(h.Experiment_Table,1)+1;
    if go==1
        if n_table>1
            h.Experiment_Table(n_table,:) = h.Experiment_Table(n_table-1,:);
            h.Experiment_Table.Index(n_table) = ...
                max(h.Experiment_Table.Index)+1;
        else
            h.Experiment_Table.Index(n_table) = 1;
        end
        h = exp_nb_update(h);
%         h = tag_update(h);
        for i = 2:size(h.Experiment_Table,2)-1
            if ismember(lower(h.Experiment_Table.Properties.VariableNames(i)),...
                    {'parameters'})
                % Add AU and PY program
                paramAUTO = '';
                if ~isempty(h.CurrentExperimental_AU_PY_Prog)
                    au_acqu = h.CurrentExperimental_AU_PY_Prog.("AU acqu"){2};
                    if ~isempty(au_acqu)
                        paramAUTO = [paramAUTO ',aunm,' au_acqu]; %#ok<AGROW>
                    end
                    % AU proc
                    au_proc = h.CurrentExperimental_AU_PY_Prog.("AU proc"){2};
                    if ~isempty(au_proc)
                        paramAUTO = [paramAUTO ',aunmp,' au_proc]; %#ok<AGROW>
                    end
                    % PY acqu
                    py_acqu = h.CurrentExperimental_AU_PY_Prog.("PY acqu"){2};
                    if ~isempty(py_acqu)
                        paramAUTO = [paramAUTO ',pynm,' py_acqu]; %#ok<AGROW>
                    end
                    % PY proc
                    py_proc = h.CurrentExperimental_AU_PY_Prog.("PY proc"){2};
                    if ~isempty(py_proc)
                        paramAUTO = [paramAUTO ',pynmp,' py_proc]; %#ok<AGROW>
                    end
                end
                if ~isempty(h.list_box(1).String)
                    if size(h.list_box(1).String,1)==1
                        param = split(h.list_box(1).String,' = ');
                        ind = find(param{1,1}=='[',1);
                        if ~isempty(ind)
                            param{1,1} = param{1,1}(1:ind-2);
                        end
                    else
                        param = split(h.list_box(1).String,' = ');
                        for j = 1:size(param,1)
                            ind = find(param{j,1}=='[',1);
                            if ~isempty(ind)
                                param{j,1} = param{j,1}(1:ind-2);
                            end
                        end
                    end
                    h.Experiment_Table.Parameters(n_table) = join(join...
                        (string(param),','),',',1);
                    % Add AU and PY program
                    if ~isempty(paramAUTO)
                        h.Experiment_Table.Parameters(n_table) = ...
                            join([h.Experiment_Table.Parameters(n_table) string(paramAUTO)]);
                    end
                else
                    % Add AU and PY program
                    if ~isempty(paramAUTO)
                        h.Experiment_Table.Parameters(n_table) = string(paramAUTO(2:end));
                    else
                        h.Experiment_Table.Parameters(n_table) = missing;
                    end
                end
                continue
            end
            if ismember(lower(h.Experiment_Table.Properties.VariableNames(i)),...
                    {'starttime'})
                [~,d] = ismember(lower(...
                    h.Experiment_Table.Properties.VariableNames(i)),...
                    lower(h.checkList(:,1)));
                if d
                    check = cell2mat(h.checkList(d,2:end));
                    eval(['t = h.check_box('...
                        num2str(check(4)) ').Value;'])
                    eval(['h.Experiment_Table.' h.checkList{d,1}...
                        '(n_table) = t;'])
                    if t
                        h.Experiment_Table.Date(n_table) = ...
                            h.calendar.static_text_field(1).String;
%                         h.Experiment_Table.Date(n_table) = char(h.calendar.d(1).Value);
                    else
                        h.Experiment_Table.Date(n_table) = '';
                    end
                end
                continue
            end
            [~,d] = ismember(lower(...
                h.Experiment_Table.Properties.VariableNames(i)),...
                lower(h.checkList(:,1)));
            if d
                check = cell2mat(h.checkList(d,2:end));
                if check(4)==0
                    if check(3)==0 %it is an insert text
                        eval(['h.Experiment_Table.' h.checkList{d,1}...
                            '(n_table) = string(h.editable_text_field('...
                            num2str(check(2)) ').String);'])
                    else %it is a popup menu
                        popup_menu_list = h.popup_menu(check(3),1).String; %#ok<NASGU>
                        eval(['h.Experiment_Table.' h.checkList{d,1}...
                            '(n_table) = string(popup_menu_list(h.popup_menu('...
                            num2str(check(3)) ').Value));'])
                    end
                else %it is a check box then
                    eval(['h.Experiment_Table.' h.checkList{d,1}...
                        '(n_table) = h.check_box('...
                        num2str(check(4)) ').Value;'])
                end
            end
        end
    else
        h = info_display(h);
        h.Experiment_Table(n_table,:) = h.Experiment_Table(...
            find(h.Experiment_Table.Index==ind),:);
        h.Experiment_Table.Index(n_table) = ...
            h.Experiment_Table.Index(n_table-1)+1;
        [~,b]=ismember({'expno'},lower(h.checkList(:,1)));
        if b
            check = cell2mat(h.checkList(b,2:end));
            h.editable_text_field(check(2)).String =...
                h.Experiment_Table.ExpNo(...
                find(h.Experiment_Table.Index==ind))+1;
            h = exp_nb_update(h);
%             h = tag_update(h);
            h.Experiment_Table.ExpNo(n_table) =...
                str2double(h.editable_text_field(check(2)).String);
        end
    end
    if h.Experiment_Table.Delete(n_table)
        h.Experiment_Table.ExpNo(n_table) = 0;
        h.Experiment_Table.StartRun(n_table) = 0;
        h.Experiment_Table.StopRun(n_table) = 0;
        tag = [num2str(h.Experiment_Table.Index(n_table))...
            '\Delete holder°',num2str(h.Experiment_Table.Holder(n_table))];
    else
        % 'Index\ExpNo\Solvent\Experiment\Parameters'
        tag = char(fullfile(num2str(h.Experiment_Table.Index(n_table)),...
            ['Exp°',num2str(h.Experiment_Table.ExpNo(n_table))],...
            h.Experiment_Table.Solvent(n_table),...
            h.Experiment_Table.Experiment(n_table),...
            h.Experiment_Table.Parameters(n_table)));
    end
    if isempty(h.list_box(2).String)
        h.list_box(2).String = {tag};
    else
        h.list_box(2).String (end+1) = {tag};
    end
    h.list_box(2).Value = size(h.list_box(2).String,1);
    h = prioriry_update(h);
end
end
