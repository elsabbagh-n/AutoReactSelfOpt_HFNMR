function h = fixed_input_drop(h)
% This function let the user increase the rank (index) of the position of
% the fixed input directly in the extset file by selecting their
% lines in the list box of the Display Extset Text File Panel.

S = h.list_box(3).String;
fixed = {'SUBMIT_HOLDER','NO_SUBMIT','STOP_RUN','START_RUN'};
if ~isempty(S)
    ind = h.list_box(3).Value;
    if ind~=size(S,1)
        s = S(ind,:);
        if ~isempty(s)
            [~,a] = ismember({s(~isspace(s))},fixed);
            if a
                S(ind,:) = S(ind+1,:);
                S(ind+1,:) = s;
                h.list_box(3).String = S;
                h.list_box(3).Value = ind+1;
                etst = join(cellstr(h.list_box(3).String)','\n');
                h.extset = etst{1};
            end
        end
    end
end
end