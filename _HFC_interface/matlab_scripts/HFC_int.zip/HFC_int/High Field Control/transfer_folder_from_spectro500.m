function Tr = transfer_folder_from_spectro500(folderPath,folderName,desiredPath,varargin)
% This function transfer folder from a remonte PC to this PC. Hostname,
% Username and Password are set to the those of Spectro500. It transfers
% file of the selected folder, and files from its subfolders indicated. If
% the transfer is done successfully, it returns a value 1; if there were no
% transfer or the fileName didn't exist, it returns a nil value.
%
% Input
% folderPath    Path of the folder to be downloaded from the remote PC
% folderName    Name of the folder to be downloaded from the remote PC
% desiredPath   Path to which the file will be download on this PC

% For test :
% folderPath = '/opt/nmrdata/user/nmr/Nour/NES_231010_2D/';
% folderName = '1';
% desiredPath = 'C:\Users\elsabbagh-n\Documents\DataSet\NES_231010_2D\1\';

%% User Input

% Required information about the remote PC (spectro 500MHz)
Hostname = '172.16.77.57';
Hostname = 'RMN500-1525.ceisam.sciences.univ-nantes.prive';
Username = 'nmr';
Password = 'topspin';


%% File Upload

if ~isfolder(desiredPath)
    mkdir(desiredPath)
end

command = ['cd ' folderPath ' ; ls'];
command_output = ssh2_simple_command(Hostname, Username, Password,command);

if ismember({folderName},command_output)
    % sometimes the transfer is fast, and the spectrum is transfered as
    % soon as it is saved, before the automatic phase proccessing is done
    % pause(0.1)
    % clc
    
    command = ['cd ' folderPath folderName ' ; ls'];
    command_output = ssh2_simple_command(Hostname, Username, Password,command);
    
    
    % from the main folder
    gg = command_output(~ismember(command_output,{'pdata'}))';
    ssh2_conn = scp_simple_get(Hostname, Username, Password,gg,desiredPath,[folderPath folderName]);
    
    % and the sub folders
    if ismember({'pdata'},command_output)
        command = ['cd ' folderPath folderName '/pdata ; ls'];
        command_output0 = ssh2_simple_command(Hostname, Username, Password,command);
        for pdt = 1:length(command_output0)
            if ~isfolder([desiredPath 'pdata\' command_output0{pdt}])
                mkdir([desiredPath 'pdata\' command_output0{pdt}])
            end
            Tr = transfer_folder_from_spectro500([folderPath folderName '/pdata/'],...
                command_output0{pdt},[desiredPath 'pdata\' command_output0{pdt} '\'],1);
        end
    else
        Tr = 1;
    end
    ssh2_close(ssh2_conn); %close connection when done
    if isempty(varargin)
        fprintf(['\n The folder <' folderPath folderName '> was transfered.\n'])
    end
else
%    clc
    Tr = 0;
end
end






