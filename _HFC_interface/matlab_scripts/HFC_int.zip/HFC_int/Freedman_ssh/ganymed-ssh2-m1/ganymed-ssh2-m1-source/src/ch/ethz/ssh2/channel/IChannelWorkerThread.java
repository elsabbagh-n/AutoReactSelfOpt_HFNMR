
package ch.ethz.ssh2.channel;

/**
 * IChannelWorkerThread.
 * 
 * @author Christian Plattner
 * @version 2.50, 03/15/10
 */
interface IChannelWorkerThread
{
	public void stopWorking();
}
